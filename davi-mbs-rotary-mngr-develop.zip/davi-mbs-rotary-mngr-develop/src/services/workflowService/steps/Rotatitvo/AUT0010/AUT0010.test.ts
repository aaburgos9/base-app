//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { PRODUCTO } from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { AUT0010 } from '~/services/workflowService/steps/Rotatitvo/AUT0010/AUT0010'

import axios from 'axios'

const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        loggerDevaService: 'http://logger/v1',
        parmsServiceUrl: 'http://catalogo/v1',
        procesoBiometriaInternaWorkflowServiceUrl:
          'http://probioiw/v1/workflow',
      },
    }
  }
}

const stepDataAtras: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: true,
    autorizacionAsegurabilidad: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: '01',
      tipoCuenta: 'Cuenta Corriente',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}
const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    autorizacionAsegurabilidad: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: '',
      tipoCuenta: '',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}

const stepDataAux: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    autorizacionAsegurabilidad: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: 'NA',
      tipoCuenta: 'Cuenta de Ahorros',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}

const stepDataAux2: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    autorizacionAsegurabilidad: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: 'NA',
      tipoCuenta: 'Cuenta de Ahorros',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}

const stepDataAux3: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    autorizacionAsegurabilidad: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: 'NA',
      tipoCuenta: 'Cuenta de Ahorros',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}

const stepDataAux4: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    autorizacionAsegurabilidad: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionContratoCredito: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionDebitoAuto: {
      check: false,
      fecha: '1234',
      version: '1',
    },
    autorizacionPagare: {
      check: true,
      fecha: '1234',
      version: '1',
    },
    cuentaDebitar: {
      numeroCuenta: 'NAaa',
      tipoCuenta: 'Cuenta de Ahorrooooos',
    },
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.AUT0010,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const valParmsResponse = {
  data: {
    data: {
      approvalReference: {
        documentName: 'Autorizacion datos personales',
        type: 'aceptacionTratamientoDatos',
      },
      biometriaInterna: {
        activityAmount: 'activityAmount',
        contingencia: 'contingencia',
        contingenciaValue: 'false',
        countryId: '57',
        genericData: {
          platformType: 'platformType',
          userType: 'userType',
        },
        ip: 'ip',
        partner: {
          callbackUrl: {
            denial: '',
            error: 'http://some-url/error',
            success: 'http://some-url/ok',
          },
          id: '',
        },
        payeeAccountType: 'payeeAccountType',
        payeeAccountTypeValue: 'CREDITO_ROTATIVO',
        tipoCanal: 'SUPERAPP_DAVPN',
        tipoOtp: 'SOL_CRED_ROTACL_APP_SUPERAPP_PN',
        tipoPlataforma: 'SUPERAPP_DAVPN',
        userAgent: 'userAgent',
      },
      cuentaAhorros: {
        codigo: 2,
        nombre: 'Cuenta de Ahorros',
      },
      cuentaCorriente: {
        codigo: 1,
        nombre: 'Cuenta Corriente',
      },
      esNumeroCuentaDebitar: 'NA',
      locale: 'CO',
      loggerJuridico: {
        asegurabilidad: {
          nombre: 'DocAseguriabilidad',
          tipo: 'aceptacionAsegurabilidad',
        },
        contratoCredito: {
          nombre: 'ContratoCredito',
          tipo: 'aceptacionContrCredito',
        },
        debitoAutomatico: {
          nombre: 'DebitoAutomatico',
          tipo: 'aceptacionDebitoAuto',
        },
        pagare: {
          nombre: 'AceptacionPagareDigital',
          tipo: 'aceptacionPagareDigital',
        },
      },
      sessionTimeout: '600000',
      tipoOtp: 'SOL_CRED_ROTACL_APP_SUPERAPP_PN',
      urlProcesoBiometriaInterna:
        'https://mbaas.lab.co.davivienda.com/probioi/indexv1.html#/process/accesstoken/',
      urlProducto: 'https://mbaas.lab.co.davivienda.com/crrt/proceso/token',
    },
    status: 200,
  },
}

const valParmsResponseAux = {
  data: {
    data: {
      approvalReference: {
        documentName: 'Autorizacion datos personales',
        type: 'aceptacionTratamientoDatos',
      },
      biometriaInterna: {
        activityAmount: 'activityAmount',
        contingencia: 'contingencia',
        contingenciaValue: 'false',
        countryId: '57',
        genericData: {
          platformType: 'platformType',
          userType: 'userType',
        },
        ip: 'ip',
        partner: {
          callbackUrl: {
            denial: '',
            error: 'http://some-url/error',
            success: 'http://some-url/ok',
          },
          id: '',
        },
        payeeAccountType: 'payeeAccountType',
        payeeAccountTypeValue: 'CREDITO_ROTATIVO',
        tipoCanal: 'SUPERAPP_DAVPN',
        tipoOtp: 'SOL_CRED_ROTACL_APP_SUPERAPP_PN',
        tipoPlataforma: 'SUPERAPP_DAVPN',
        userAgent: 'userAgent',
      },
      cuentaAhorros: {
        codigo: 2,
        nombre: 'Cuenta de Ahorros',
      },
      cuentaCorriente: {
        codigo: 1,
        nombre: 'Cuenta Corriente',
      },
      esNumeroCuentaDebitar: 'NA',
      locale: 'CO',
      loggerJuridico: {
        asegurabilidad: {
          nombre: 'DocAseguriabilidad',
          tipo: 'aceptacionAsegurabilidad',
        },
        contratoCredito: {
          nombre: 'ContratoCredito',
          tipo: 'aceptacionContrCredito',
        },
        debitoAutomatico: {
          nombre: 'DebitoAutomatico',
          tipo: 'aceptacionDebitoAuto',
        },
        pagare: {
          nombre: 'AceptacionPagareDigital',
          tipo: 'aceptacionPagareDigital',
        },
      },
      sessionTimeout: '',
      tipoOtp: 'SOL_CRED_ROTACL_APP_SUPERAPP_PN',
      urlProcesoBiometriaInterna:
        'https://mbaas.lab.co.davivienda.com/probioi/indexv1.html#/process/accesstoken/',
      urlProducto: 'https://mbaas.lab.co.davivienda.com/crrt/proceso/token',
    },
    status: 200,
  },
}

const valLoggerJuridicoResponse = {
  data: {
    data: {
      estatus: true,
    },
  },
  status: 200,
}

const valconsultarDataPROBIOINTResponse = {
  data: {
    data: true,
  },
  status: 200,
}

const valconsultarDataPROBIOINTSinDatosResponse = {
  data: {
    data: false,
  },
  status: 200,
}

const mockWfData = new WorkflowData(mockPresentacion)
const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)
const serviceUrls = {
  loggerJuridico: 'http://logger/v1/auditoria/juridico',
  parametros: `http://catalogo/v1/parms/services.workflow.AUT0010?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO.CRRT}`,
  probioInt: `http://probioiw/v1/workflow/proceso`,
}

let step: AUT0010
let nextStep: IStepData

describe('AUT0010', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para AUT0010
   *
   */

  test('Instancia correctamente del objeto AUT0010', () => {
    step = new AUT0010(stepData, mockWfData, config, logger)
    expect(step).toBeDefined()
  })

  test('Validación del objeto AUT0010 con payload correcto (no retorna mensaje de error)', () => {
    expect(step.isRequestValid()).toBeTruthy()
  })

  test('Validación del objeto AUT0010 con payload incorrecto (si retorna mensaje de error)', () => {
    const badStepData: IStepData = {
      clientId: 'abc123',
      payload: {
        bad: '',
      },
      stepId: STEP_ID.AUT0010,
    }
    const badStep = new AUT0010(badStepData, mockWfData, config, logger)
    expect(badStep.isRequestValid()).toBeFalsy()
    expect(badStep.getRequestValidationError().length).toBeGreaterThan(0)
  })

  /*
   *
   *  Verificacion del flujo para AUT0010
   *
   */
  test('Validación del getCurrentStep retorna valor del request', () => {
    expect(step.getCurrentStep()).toEqual(stepData.stepId)
  })

  test('AUT0010 => Flujo Atras', async (done) => {
    try {
      step = new AUT0010(stepDataAtras, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('AUT0010 => Presentación sin sessionTimeOut | consultaParametros | loggerJuridico | seteo Probio (false)', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.resolve(valLoggerJuridicoResponse)
      }
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTSinDatosResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('AUT0010 => Presentación con sessionTimeOut | consultaParametros | loggerJuridico | seteo Probio (true)', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.resolve(valLoggerJuridicoResponse)
      }
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepDataAux, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  /*
   *
   *  Verificación de errores al llamar servicios
   *
   */

  test('AUT0010 => Cliente con error al consultar parametros -> Error 500 | CRRT', async (done) => {
    const valParmsResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error en axios al consultar parametros -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error al consumir loggerJuridico -> Error 500 |autorizacionAsegurabilidad.check|  CRRT', async (done) => {
    const loggerJuridicoResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.resolve(loggerJuridicoResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error en axios al consumir loggerJuridico -> Error 500 |autorizacionContratoCredito.check|  ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepDataAux2, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error en axios al consumir loggerJuridico -> Error 500 |autorizacionPagare.check|  ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepDataAux3, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error en axios al consumir loggerJuridico -> Error 500 |autorizacionDebitoAuto.check|  ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepDataAux4, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error al consumir BiometriaInterna -> Error 500 | CRRT', async (done) => {
    const biometriaInternaResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.resolve(valLoggerJuridicoResponse)
      }
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(biometriaInternaResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('AUT0010 => Cliente con error en axios al consumir loggerJuridico -> Error 500 |autorizacionContratoCredito.check|  ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.loggerJuridico) {
        return Promise.resolve(valLoggerJuridicoResponse)
      }
      if (url === serviceUrls.probioInt) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new AUT0010(stepDataAux2, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })
})
