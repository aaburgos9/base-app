//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface ICryptoService {
  encryptJwe(encryptKey: string, payload: any): Promise<string>
  decryptJwe(jweToken: any): Promise<any>
}
