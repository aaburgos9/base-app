//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { BeneficiosCaracteristicasStep } from '@services/workflowService/steps/Rotatitvo/beneficiosCaracteristicasStep/beneficiosCaracteristicasStep'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'

const CANAL: string = '83'
const MODULO: string = 'rotativo'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'
const PRODUCTO: string = 'rotativo'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        parmsServiceUrl: 'http://catalogo/v1',
        rotativoServiceUrl: 'http://rotativo/v1',
        
      },
      generarToken: {
        clientSecretToken: 'TEST',
        clienteIdToken: 'TEST',
        grantTypeToken: 'TEST',
      },
    }
  }
}

const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    esDinamico: true,
    linkrotativo: '1234567890ABC90',
    llaveEncriptacion: 'llave',
    producto: {
      monto: '300000,00', // TODO: NOMBRE DE VALOR POR DEFINIR
      nombre: 'Zapatos', // TODO: NOMBRE DE VALOR POR DEFINIR
    },
  },
  stepId: STEP_ID.rotativo000,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      expeditionCity: '',
      expeditionDate: '',
      number: '',
      type: '',
    },
    email: '',
    name: '',
    phoneNumber: {
      countryId: '',
      number: '',
    },
  },
  consumer: {
    appConsumer: {
      appVersion: '',
      canalId: '',
      id: '',
      sessionId: '',
      soVersion: '',
      terminalId: '',
      transactionId: '',
    },
    deviceConsumer: {
      id: '',
      inactiveInterval: '',
      locale: '',
      phoneNumber: '',
      sessionTimeout: '',
      userAgent: '',
    },
    genericData: {},
  },
  linkrotativo: 'ABC1234568ZXCV',
  montoProducto: '300000,00',
  nombreProducto: 'Zapatos',
  partner: {
    callbackUrl: {
      error: '',
      success: '',
    },
    id: '',
  },
  product: {
    country: 'CO',
    id: 'rotativo',
  },
}

const valParmsResponse = {
  data: {
    data: {
      sessionTimeout: '900000',
      urlGenerarToken: 'generarToken',
    },
  },
  status: 200,
}

const valParmsResponseAux = {
  data: {
    data: {
      sessionTimeout: true,
      urlGenerarToken: 'generarToken',
    },
  },
  status: 200,
}

const mockResponseGenerarToken = {
  data: {
    data: {
      access_token: 'nC36fGwXP2EKGRRsrsZFA6u85zq',
      expires_in: 900,
      token_type: 'Bearer',
    },
  },
  status: 200,
}

const mockWfData = new WorkflowData(mockPresentacion, '', 0)
const config = new MockConfig()
const logger = new LoggerStub('info')
const serviceUrls = {
  generarKento: `http://rotativo/v1/${valParmsResponse.data.data.urlGenerarToken}`,
  parametros: `http://catalogo/v1/parms/services.workflow.rotativo000?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO}`,
}

let step: BeneficiosCaracteristicasStep

describe('BeneficiosCaracteristicasStep', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para rotativo000
   *
   */

  test('Instancia correctamente del objeto BeneficiosCaracteristicasStep', () => {
    step = new BeneficiosCaracteristicasStep(stepData, mockWfData, config, logger)
    expect(step).toBeDefined()
  })
})
