//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

// Registrar module loader con soporte de alias de paths
// tslint:disable-next-line: no-var-requires
require('module-alias/register')

// Permitir cargar variables de entorno desde .env para ambientes de development o testing
import dotenv = require('dotenv')
if (process.env.NODE_ENV !== 'production') {
  dotenv.load()
}
// Importar Reflect antes que Inversify
import 'reflect-metadata'

// Inicializar configuracion desde ambiente
import { ConfigService } from '@config/vars/configService'
const config = new ConfigService()
const configErr = config.load()
if (configErr) throw new Error(configErr)

// Obtener logger
import { Log4jsLogger } from '@services/loggerService/loggerLog4js'
const logger = new Log4jsLogger(config)
const expressLogger = logger.getExpressLogger()

// Importar dependencias de Express y de Inversify
import { container } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { errorHandler } from '@utils/errorHandlerMiddleware'
import { errorLoggerHandler } from '@utils/errorLoggerMiddleware'
import bodyParser from 'body-parser'
import cors from 'cors'
import helmet from 'helmet'
import { InversifyExpressServer } from 'inversify-express-utils'
import { createLightship } from 'lightship'

// Obtener variables de configuración desde entorno
const httpPort = config.getVars().server.port
const httpRootPath = config.getVars().server.rootPath
logger.info(
  `${config.getVars().podName} - ${
    config.getVars().server.rootPath
  } API is starting...`
)

// Cargar las entidades inyectables
// la anotación @provide() las registra automaticamente
import '@config/ioc/loader'

// registrar instancia de config en container de dependencias
container.bind<any>(TYPES.IConfig).toConstantValue(config)

// Configurar wrap de Express con Inversify para proveer inversión de control e inyección de dependencias
const server = new InversifyExpressServer(container, null, {
  rootPath: httpRootPath,
})

server.setConfig((expressApp) => {
  expressApp.use(expressLogger)
  expressApp.use(bodyParser.json())
  expressApp.use(helmet())
  expressApp.use(cors())
  expressApp.use(errorLoggerHandler(logger))
  expressApp.use(errorHandler)
})
const app = server.build()

// Configurar Swagger-UI en ambientes de development y testing
import swaggerUiExpress from 'swagger-ui-express'
import apiDocsJson from '~/api-docs.json'

if (process.env.NODE_ENV !== 'production') {
  app.use(
    '/api-docs',
    swaggerUiExpress.serve,
    swaggerUiExpress.setup(apiDocsJson)
  )
}

// Configuración del framework para health checks (readiness/ liveness checks & graceful shutdown )
const isECS = Boolean(process.env.ECS_CONTAINER_METADATA_URI)
const lightship = createLightship({ detectKubernetes: !isECS, port: 9000 })

lightship.registerShutdownHandler(() => {
  httpServer.close()
})

// Iniciar el servidor HTTP
const httpServer = app.listen(httpPort, () => {
  logger.info(
    `${
      config.getVars().podName
    } - HTTP server started at http://localhost:${httpPort}`
  )

  // agrego un tiempo de 10 segundos de warm up para enviar señal de readyness y recibir tráfico
  setTimeout(() => {
    lightship.signalReady()
  }, 10000)
})

exports = module.exports = app
