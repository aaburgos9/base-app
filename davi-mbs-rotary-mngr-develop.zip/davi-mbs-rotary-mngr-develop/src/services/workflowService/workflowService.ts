//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { ESTADO_SESION } from '@models/enums/estadoSesion.enum'
import { KIND } from '@models/enums/kind.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { TipoSesion } from '@models/sesion/sesion.model'
import { WorkflowData } from '@models/workflowData.model'
import { IAuthService } from '@services/auth'
import { ICryptoService } from '@services/crypto'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence'
import { IStepFactory } from '@services/workflowService/stepFactory'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { inject } from 'inversify'
import { IWorkflowService } from '.'

@provide(TYPES.IWorkflowService)
export class WorkflowService implements IWorkflowService {
  constructor(
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IPersistenceService)
    private persistence: IPersistenceService,
    @inject(TYPES.IStepFactory) private steps: IStepFactory,
    @inject(TYPES.ICrypto) private crypto: ICryptoService,
    @inject(TYPES.IAuthService) private auth: IAuthService
  ) {}

  public getNextStep = async (stepData: IStepData) => {
    this.logger.debug(
      `Workflow:getNextStep - Inicio con clientId: ${stepData.clientId} y paso: ${stepData.stepId}`
    )

    let wfData: WorkflowData

    // Inicialización de objeto presentación
    const presentacion: IPresentacionClientes = {
      client: {
        documentClient: {
          number: '',
          type: '',
        },
        email: '',
        name: '',
      },
      consumer: {
        appConsumer: {
          canalId: '',
          id: '',
          platformType: '',
          sessionId: '',
          transactionId: '',
        },
        deviceConsumer: {
          id: '',
          inactiveInterval: '',
          userAgent: '',
        },
        genericData: {},
      },
      module: {
        country: 'CO',
        id: 'rotativo',
      },
      partner: {
        callbackUrl: {
          error: '',
          success: '',
        },
        id: '',
      },
    }

    // Validar si existe el clienteId, sino generarlo
    if (stepData.clientId === '') {
      // Crear datos de sesión, ingreso sin clienId
      wfData = new WorkflowData(presentacion)
      wfData.sesion.workflow.pasoActual = STEP_ID.BYC0000
      wfData.sesion.tipo = TipoSesion.PRODUCTO

      this.logger.debug(
        `WorkflowService: rotativo > Inicio - clientId generado: ${wfData.sesion.clientId}`
      )
      this.logger.debug(
        `WorkflowService: rotativo > wfData: ${JSON.stringify(wfData)}`
      )

      // Persistir datos de la solicitud
      try {
        await this.persistence.setData(
          KIND.ROTATIVO,
          wfData.sesion.clientId,
          wfData
        )
      } catch (error) {
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
    }

    // Obtener data de sesion (wfData)
    try {
      wfData = await this.persistence.getData(KIND.ROTATIVO, stepData.clientId)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (!wfData) throw new ServiceError(MBAAS_ERRORS.invalid_client_id)
    this.logger.debug(`Workflow:wfData: ${JSON.stringify(wfData)}`)
    if (wfData instanceof Array) {
      wfData = wfData[0]
    }

    // Desencriptar payload de request
    let stepPayload
    stepPayload = await this.crypto.decryptJwe(stepData.payload)

    stepData.payload = stepPayload

    // Obtener paso a procesar
    const wfStep = this.steps.get(stepData, wfData)

    // Validar payload y emitir error de datos si es inválido
    if (!wfStep.isRequestValid()) {
      this.logger.debug(
        `Workflow:getNextStep - payload invalido: ${wfStep.getRequestValidationError()}`
      )
      throw new ServiceError(
        MBAAS_ERRORS.invalid_data_format,
        new Error(wfStep.getRequestValidationError())
      )
    }

    let nextStep: IStepData

    // Calcular si la sesión ha expirado
    const ahora = Date.now()
    const ahoraEnMilisegundos = new Date(ahora)
    const expiracionSesion = new Date()
    const ultimaAccionSesion = new Date(
      Date.parse(wfStep.sessionData.sesion.ultimaAccion)
    )

    // REVIEW: VALIDAR ESTA IMPLEMENTACIÓN
    const inactiveInterval = Number(
      wfStep.sessionData.sesion.presentacion.consumer?.deviceConsumer
        ?.inactiveInterval
    )
    this.logger.debug(`inactiveInterval: ${inactiveInterval}`)

    const ultimaAccionSesionExpira = new Date(
      ultimaAccionSesion.valueOf() + inactiveInterval
    )

    // Si la sesion ha expirado, actualizar estado y enviar error en proximo paso

    if (
      expiracionSesion < ahoraEnMilisegundos ||
      ultimaAccionSesionExpira < ahoraEnMilisegundos
    ) {
      wfStep.sessionData.sesion.estado = ESTADO_SESION.EXPIRADO
      nextStep = {
        clientId: stepData.clientId,
        module: stepData.module,
        payload: {
          message: STATUS_MSG.MSG_crrt_009,
        },
        status: STATUS_ID.MENSAJE_CALLBACK,
        stepId: STEP_ID.BYC0010,
      }
      await this.auth.endSession(stepData.clientId)
      this.logger.debug(
        `Workflow:getNextStep - Sesion ha expirado para ${stepData.clientId}`
      )
    }
    // Si la sesion no ha expirado, entonces obtener próximo paso
    else {
      try {
        nextStep = await wfStep.getNextStep()
      } catch (error) {
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
      this.logger.debug(
        `Workflow:getNextStep - proximo paso: ${nextStep.stepId} - Sesion: ${stepData.clientId}`
      )
    }

    // Obtener datos de sesión actualizados y mover paso
    const updWfData = wfStep.sessionData
    updWfData.sesion.workflow.pasoActual = nextStep.stepId
    updWfData.sesion.ultimaAccion = new Date(ahora).toISOString()

    // Persistir cambios en datos de sesión
    try {
      await this.persistence.setData(
        KIND.ROTATIVO,
        stepData.clientId,
        updWfData
      )
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    const payloadAux: string = JSON.stringify(nextStep.payload)
      .replace(/á/g, 'aacutembaas')
      .replace(/é/g, 'eacutembaas')
      .replace(/í/g, 'iacutembaas')
      .replace(/ó/g, 'oacutembaas')
      .replace(/ú/g, 'uacutembaas')
      .replace(/Á/g, 'Aacutembaas')
      .replace(/É/g, 'Eacutembaas')
      .replace(/Í/g, 'Iacutembaas')
      .replace(/Ó/g, 'Oacutembaas')
      .replace(/Ú/g, 'Uacutembaas')
      .replace(/ñ/g, 'nacutembaas')
      .replace(/Ñ/g, 'Nacutembaas')
    nextStep.payload = JSON.parse(payloadAux)

    // Encriptar payload de respuesta
    let encPayload = ''
    encPayload = await this.crypto.encryptJwe(
      updWfData.sesion.app.llaveEncriptacion,
      nextStep.payload
    )

    const responseData: IStepData = {
      clientId: stepData.clientId,
      module: stepData.module,
      payload: encPayload,
      status: nextStep.status,
      stepId: nextStep.stepId,
    }
    return responseData
  }
}
