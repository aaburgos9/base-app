//
// Copyright (C) 2022 - Banco Davivienda S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { KIND } from '@models/enums/kind.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { TipoSesion } from '@models/sesion/sesion.model'
import { WorkflowData } from '@models/workflowData.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { PresentacionService } from '@services/presentacion/presentacionService'

jest.mock('@services/auth/authService')
jest.mock('@services/crypto/cryptoService')
jest.mock('@services/persistence/persistenceService')

// Crear mock Config
const mockConfigVars = {
  back: {
    authServiceUrl: 'http://mbaas/auth',
    persistenceServiceUrl: 'http://mbaas/persistence',
  },
  front: {
    url: 'http://mbaas/rotativo#',
  },
}

class MockConfig implements IConfig {
  public getVars = () => {
    return mockConfigVars
  }
}

describe('PresentacionService', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('info')
  const persistence = new PersistenceService(config, logger)
  const auth = new AuthService(config)
  const crypto = new CryptoService(auth, logger)
  const cryptoAux = new CryptoService(auth, logger)
  let presentacion: PresentacionService

  const mockOtpToken =
    'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.aatVVSxuMmURQxfNfO_k6gz9PkW--htA2rZ5yDVauj-UKL6_gmzN2rzLlNM_cIPwLHocL4jJjs7Ne-Icc-O3AegpBO5QALE8HJPeebtSnkLCT42BiKrpF01dQW_1fdsI22UEmGqpXL0FFuHs0SyxWkRzR5n812VqeH1ZVsHdErsL_rG6OEThvDTcgy4pdXqmlE2clS2vGCnN-TkjZ7cxj12ioHmaxeWOh8pEGwUEXsFfdF5G0QnDQNjNsv6RahGO7nY51LXMwtj7Ce_yQHV-cbdaebtY5bi9bLVHQTSUnEcMrJiYvAibY_iWfhjeDikT6isRrowAZnZmJKkF5MG_GQ.5-eR-3JBsPzL_uZNH-MSUA.E0cjoWxxaesVJZhbebswoHaVAtLeF3sgiSrecSvHZVnbA9Px24zBgWeLh5BYohtTDN02hwKkGbgtMARgtASm6rE-U15qP9adh0j_Fl9nsG-UqBty4amijCsVLi2MrvJxE0dlpzCl7734F9DDbOadIJed9O7xL13_GM0XFERggKnZaTC70ec6BSVBKEaE_6Bo40sVeqxkDPjT839LmFFcoZw2GbCAKmrkHsDmR6ntE4v9OQkJt8tW9YUhDsrr1fs6WPFLUyLQxQtzLfhJ1yFYGFol9cvqtfdkMXkyDsTQoLNGLyXB5rwN9gjtjtSnDOn9Fq6s0XrErPeTCX0Nn3XXZOsNg_vxgjRR5xYFtpO-mqJVAMh_XJIDNuksyc_OmgQtkyQNnxYp02s0GX2ueHFdmvfFJCw8jArP2rQ4ktYspg2TqqkcUYNDq5csVNnzMG3_ZxoiqoRazWH8mkcncFGkrjPVnYljvUpJye4cYJfIbcCEsDVaaxxr2MRiwCwkX-_7i9_owzUdHSqyWAFsY31_7cv4lcetODdH_s1hHwpDLgUhHOfk1SkgbiSQcMbO0RgEF3iNmbJIeAoMA4qe8qeUzjly3QW88t-A15Vzfb8m1YQxoRvXOb3PfEH8G9crEOXvTOFCOy2--zf-GAxCHy1VmIbiRusWyxI8CUISMUSi6Cz-klfQEQM-XYTmA0FnH9R2rvSN8yq-vKGjsgBcW4jbUDKt0j7RhSOSEFR1s_Z2vaDjQuKjAo8cm5wtBadQQTQ-u9GYcKYZYArcSmrfkl6S1vPiLBx1PIQEdHwRXHuiaV--XPB0TDJG5y4HzHQPGm0oz2vL53CoHotptS-kMPlYtDhz_Ij_NNOdqw4dCbf-yy3Hd51V9eoleZ-HcCT4NCKY5Vv8rhwp2enP0rCv6qTUGlT9c7MrKvEkW0USfY2EkBVWBZWG6wvWg1TavYJBJ3VvoWugobbdT0_lmzQf5zb9uwfhEdAVY7MwUpvWt4iyTGDa80l2QbbRbmhv7R0zGC1C0mTrUNXkKvgdOXK92MF5S9BjD2cJtiHSR8av5cTAWTEIjvKtqBlu2egGBpcT0LRY9kNIwGA4m8nxj6hE7vSyUw.tBu06dR3GixUlFhqS5cztXI-jONhzwZAOq26Z8Xpnlo'
  // 'eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vdGVzdC5jbG91ZC5kYXYubmV0Ly53ZWxsLWtub3duL2p3a3MuanNvbiIsImtpZCI6IjE1NTE4MTc4MjkifQ.eyJhdWQiOiJEQVY6Q0xPVUQ6QVVUSCIsImV4cCI6IjE4Njg2Njc3NzkiLCJpYXQiOiIxNTUzMDkxNzc5IiwiaXNzIjoiREFWOkNMT1VEOkFVVEgiLCJzdWIiOiJhYmMxMjMiLCJ1c2UiOiJvIiwianRpIjoiYTlmODE5YzAtNGIxYi0xMWU5LThlYjItOTE1YTA0OTZlNTQ1In0.BiEUUmU8UMBJfWX5k6SXSW20zXC_P_HwLXf4UOVxIeLWPa4-1S6PCcSqjAFWOl5bgY5NdIDhUQWg4VCCY5tOLzwfun02QRqCX5sW8bmXg63p91MVKZwTL9-fkE2-Kb5ZM1cVqTSsKNfxhX3K0g_1zylPV53xvi_9nwoGtAsLszV_V6fZtydjAP9KtC_laBIiTL0ijx248W4LV7uYwGxjnBQTwK-mUoJKeoFp6IUXp75zlD0cBOu6KJGQgbnEFI6Igf71DSE-aE0_WUS7uVbHMhJ8uhyLfj3GJt9VjScKmHjeOptS6iOS1B7Zcri2D_mlcBIVj6fkqJQrFxyPMhkQmw'
  const mockJwe =
    'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.HJHe2BynHJMm0i5NPVbbiUBZSftXC5JdAeSnUYzxoBD0M2LfWi3IwEFvA0HQt67yYaX_R7ek_HUqSkBp_Ldiy-TzTOl2_aKvEP65X9vK1IydvzvQxu27akSA-RLE753EoRQSVC7RJl19r9mzRdDzT154BcK_aaYmS8bwPx9F7uUra3YzGvPSdVA21qgZcbVBq7032H0hQMtUcoqjGY55ekI-S6wrC6MWR99ZQFFmSYSMxfOIIPcZmwFiqrR-rOKBE2nuiX6cUPjNxdkSD7fBk1ecenU9jvsOTCPOCkJFtkHLzZCBaBJ61eX4okPYDQPWl9MbcxyLv2_BxHcG_Kcr9w.ovHhCRqfqNzJ8yJKdj068A.D5mHoPQKlPIX_OPD2JsyYuy7yDo3F2pg3ahZCofj9tTryykrOBV7ORD-hrnXOar-lealN6IXgJdmLkMHW4j7e7GDIZrTWjTPSzQyTIACZydjABvipVfSfrlnQOcNhdt0ynOxTK_ApH9sZCibWiZzq2_rai5YqoXr0nWE8PQsIH0xZwJlodgOUK2ZQedS_AcZuDsg1vJS1Ogx_IIuaStuQwRMI7Z-OxgqCC-JLH657cofkNXLTjbTIiHOoXT7bhaPdBz-pHzuxOqq0Y1USzFuC0pEsMDGySUbOQylTdQ56UGrdiJrzDTQoFFwqf_Uu1mcXW70ZfoJXPqKMM26S8iZRAb_XFiplAELLZAOFFdleRk4Bx1tUw47Q7A-FnTMDL4uelGG4diaZap-jpxdHPGct8Hm70Peq3HjruhnfbfwMVo3ItKNfXXlRNUPdtZ6p3r4YE7rUeTu1LkUaSL48f38vVrmxWSdX6AAeNRIr1TSmppXR6G9Z8yXPyZxkWEWpsM7yKjHxencbceN6ObBknNCXxkQBG4U7M0DqYMldataZjU_hrxuNTkqZ2b2q1ogoubNwPY9DnU9P0DzjcPP45kywpVvt_NzY-GNCgCMYsb13cueNpPe2ZNrnUTJ0wuk0h93f6bwcQ2b-T7OBtp30v_81TJc-d6ATLBagngk0lMSCvBOLp24IAe8ag3bkJx_xSu0BRIWHkXBgWyZTdONBYa39sNZsc_cnc2fxo5EpYrNjBCX0YyM7w_VN5Ro3nJIFhYW4A8YfwQKVuEHv1xs3XtCbZ63UFZwAXlXq6AbipOxHhrlIu6NzI_A-llejVPLhrIfQwUShnBTES6BefHufYOg7K-s-902ITUBN10llMhBEGDzwHDSXGl8TjoZMgHuaGwaLZjejUOlClFHV6Ev1Y574eays6T0ovQmKzlZn_6bHg5IuHFdFe2su60NxanAewgNuiw9MR8_QqlzhLCG_0OOA6QZtAv3qD3FLkuqreCqVHwn9zdE4WsOYPsUROZE3m4IKStFzTa3IEnoW-ub0TceOgVmOpIRjQJUqd_twyJYgHb4tLn_slSk2jfjSRkIenVnETfo3TUnruDfDjVoyQfkakCd19FHK3pkEgZEj7E8b_P0KJHVvmAAMVwJNIJ5aArNZdsprf4qMacgjNakZc-Aw-2tjDSJkqznRevXw3cFaDV7t4Vld7l3a18knJeld7nBoHs_rpou-8beO76DsbaAO0XsYtwzMip60HCf6qtRX0oIZThYCswCr61HGUds5iZJB2sTVSDqiROf9fMR5ovxz6p7uIlIShoyG40RLkj4lo4.Qu-t9b2Er3rrfVsCRtqwNN3tH1HXzjLDdVjSqlPmgZE'

  const mockStepPayload = {
    client: {
      documentClient: {
        number: '111222333',
        type: '01',
      },
      email: 'mariahelena@gmail.com',
      name: 'Maria del Carmen Helena',
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        platformType: "SUPERAPP",
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        inactiveInterval: "600000",
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
      },
      genericData: {
        dataItem: [
          { key: 'tokenFrontend', value: 'TEST' },
        ],
      },
    },
    module: {
      country: "CO",
      id: "CRRT"
    },
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      }
    }
  }

  const mockStepPayloadSinGenericData = {
    client: {
      documentClient: {
        number: '111222333',
        type: '01',
      },
      email: 'mariahelena@gmail.com',
      name: 'Maria del Carmen Helena',
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        platformType: "SUPERAPP",
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        inactiveInterval: "600000",
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
      },
    },
    module: {
      country: "CO",
      id: "CRRT"
    },
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      }
    }
  }

  const mockStepPayloadAux = {
    client: {
      documentClient: {
        number: '',
        type: '',
      },
      email: 'mariahelena@gmail.com',
      name: 'Maria del Carmen Helena',
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        platformType: "SUPERAPP",
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        inactiveInterval: "600000",
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
      },
      genericData: {
        dataItem: [
          {
            key: 'tokenFrontend',
            value: 'XXXXXXXXXXXX',
          },
        ],
      },
    },
    module: {
      country: "CO",
      id: "CRRTPrueba",
      id1: "CRRTPrueba"
    },
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      }
    }
  }

  const mockStepPayloadAux1 = {
    client: {
      documentClient: {
        number: '111222333',
        type: '01',
      },
      email: 'mariahelena@gmail.com',
      name: 'Maria del Carmen Helena',
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
      },
      genericData: {
        dataItem: [
          {
            key: 'tokenFrontend',
            value: 'XXXXXXXXXXXX',
          },
        ],
      },
    },
    module: {
      country: "CO",
      id: "CRRTPruebaFallida"
    },
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      }
    }
  }

  test('Presentacion instancia correctamente', () => {
    presentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )
    expect(presentacion).toBeDefined()
  })

  test('Presentacion de producto valido -> creo sesion ok', async (done) => {
    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockOtpToken)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: mockJwe })
      expect(sesion).toBeDefined()
      expect(sesion.otp).toBeTruthy()
      expect(sesion.appUrl).toEqual(
        `${mockConfigVars.front.url}/${mockOtpToken}`
      )
      expect(wfData.sesion.tipo).toEqual(TipoSesion.PRODUCTO)
      expect(persistence.setData).toHaveBeenCalledWith(
        KIND.ROTATIVO,
        sesion.clientId,
        jasmine.any(WorkflowData)
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('Datos de parametro con JWE invalido -> retorno error 422', async (done) => {
    // mock de tipo de documento a vacio para forzar error
    const jweConError =
      'FAKE-FAKElbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiMTU1MzEzMzAwNiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.MzTRQQXtL5-J_8BnaZHdrKRMohULqrQub3n6y_T3CZx4q5Gq-bA6cYMP-VRKpLhNeEkDjDSus25LbhxbxkNQa8BM_P0IqhcD4D4BePjEwOc9bz0mZsaSNMk8ag_ypqrjQgcGGKuq13xW1g8U_w343fHYjQxxh0RpLjUdHjqTxL4FfCMg_cHuiKA9BSY0h-W69aWGQnxM0kU7ryw3GGlElQNsAEwrFtGVNre9BjRDdfwYI-km_a58xjWuWFRMiVDhSChySnjDa3mmhFedTzpY5frKn_K9HRHUeUuw5l5sHe4abHXLpI7UvxEEAFlBWAbhhdoL7diTEGROTBE8vaZSgQ.DNV-89rCqr60QeS8L_qmkQ.X9DOnGKwkHg-GUetE-h3ENBGP8Oy18bt9BZ1MLzbXGvSLnhnLDFv1HdCiPeyQgM6d3-6YuvzxUw5uJcoZGQZECoNZb4J54n3uO8NpDkRMNhRE_JMYGT8Jyu47X1Z5Mg1o_yRExmjtDmzzFYyonFQvRFAnTAx0TLh5HIIAP_OA0V6PrufEeMnQC-JHwM2Xff0PZkD44-OUesp4ZvOMQ5NDGZNaF6vbNRNR3cTYXahQG9zyk2M6DnR97P1r9JzbPWFeah7LV-jBLDYN0ZorHphoA.nSjl1wXNd7Gso6WMoJovRBBNATW1Q4KAOKF9iSVXRSE'

    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockOtpToken)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.reject(new Error('upsss'))
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: jweConError })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  test('Presentacion con formato invalido -> retorno error 422', async (done) => {
    // mock de tipo de documento a vacio para forzar error
    const jweConError =
      'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.ASYrJZ2LumZTo4JpxTbvF9C--VVE5FKqXvliS7j4BbdLokbcpkXl1gG8CHZgeNqACdB344wwqUoVhd2Bzady5hT2vVqaSFPa4HIC6qz7eHkFDTqUwHlk3C6075mU5hWcX9ePAfki8bhIdVYesqZZrX0c4_sxIo3WMyA77mOZ_iUaG3xmtn3Vo6M8XBKD4LUOob5v6jtZYD_HN_ZbtJ7QUkJ4YyGBNIiJy7rgvFtuKoC09rJ5mM3C7JS2OVkHbIKZCTzP_V9XiV8lxLyf8k8my12JpejJ-V2eXwR7slGzK1rlMWPfyqX0NYWoZhPQNHwfS-q4PDwmUjkaQ6Yi9-UuOA.DN_KByhe3Nib4vfBR0UItQ.Nvto7EpylKqg8X288I8gFl4zXkmOf6R8ApSaDexC4H-OeOmrrO6WnEhygDDqcpIWwIbGaAWHCXtNdlXOM5kERdxE0YIIWNeRZgKOM3ryYcW8P-8rTi8_NxVo7hnzyXj75mOVZpDjwSZCAVI2F5rc4iTSdoSCrHutWx2YrpzqviDfgeYDopdLblTF5-qU5LWQ2HuoLM4axFVTnHnGUqwTlc26Ank5quvEGXyIzLnGSFDrkrUkv6rB0mcNTlkeidGP43YhfTlRQHie15hYRWz1gs-c17RcWPZ6CR4cn32JNNhBMnmqr2Oc6nMWepoTzKjRydobAoj0ksEVl24G4NViI4ZcpjxWeK1oaqzK9p4BuIElG5iWnuA6IYfsnB6ucKrupz1w8gIApYKzR4rGgX7qeFqtGd8Y8YRTKNnjtoC2mbcxUNfavjTF6L92grZ65RUTEerZai79KGrgNltU8eFNUS2CXCVSjzHrCJxQvc0zayjrjwZZkbm3FsIRCZJb_GGGL4655Xu3N9sPclyFIdhAHaAU3PHfyyloell8VyrMIA6DvrtkRkgDklCZiPT-opex1tzoOSREbQmxhCUuFT3SWnd5LqZPr8vOvtl78UstkX8MswOUktReKHhyk6FI3RItRkhePUIyU9h5Txrys8QEoC5FVqZga2NUJt7lx2N4FymmlKgnA2zk_R9o1fBUmHIAo0poL6mksengfOmKQaayZf7ucozxs_yK2RWwdECtOFnQboSkKbOXf-st5yAozwHIOHv5cyUTksOYPN0U_T-WOS0rNXMdX72ImssYO4RwzSroqHzDcN0dut7SUFpNRCJt-BZC2WT7U3D1lgylWdinhLJXvsooVNcz67dt4LqRscZTrA06ogyB73O09W8U2BkcbS-D00sY9z47ldWnAZqjsJvFU3j_0Sthf__86by6olYJhhqs26uEwUPtxomKTJMmgg_NPQNKLTIXYMfLTa5kfn1VY21jZQNcNjYvl7Q_FIh4N5TOSbLTXtXPJKuUIkKoWKf5pgcL5-Bd1sWGg8j0QSVf6v2nUHknASiYzvXOzaAhv9oZncbmsByNww9qreP_IuRWhzHJ-icdywXC18rn1TZRKPPhjKmEwvBEOcwECPfo3mnVlshL_v0pI1KRQ5GDkpI_0fybcokOaFZ1ddwEAgdV17Wrs3cdx-Bd0NJzI6fVbxOVIopa0Kx2Nf6q03afDpv5sHWRZXS3d9q_r68N4h5hkmcENha1UT5MHJ_KWAgBGkk9iVT-HJB1CsfdBnxSuK8DqBpWnjmA1I4RZqkgODglsyjobQ771iufohCKAJU.w-I8d3mv3c76-78WfZQsxY9bKOJ9NxEncfiMxwcBbTI'

    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockOtpToken)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    cryptoAux.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayloadAux)
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      cryptoAux
    )

    try {
      const sesion = await localPresentacion.crear({ data: jweConError })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  test('Presentacion de producto/pais invalido -> retorno error 422', async (done) => {
    // mock de producto = 'FAKE' forzar error
    // const jweConError = 'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.ASYrJZ2LumZTo4JpxTbvF9C--VVE5FKqXvliS7j4BbdLokbcpkXl1gG8CHZgeNqACdB344wwqUoVhd2Bzady5hT2vVqaSFPa4HIC6qz7eHkFDTqUwHlk3C6075mU5hWcX9ePAfki8bhIdVYesqZZrX0c4_sxIo3WMyA77mOZ_iUaG3xmtn3Vo6M8XBKD4LUOob5v6jtZYD_HN_ZbtJ7QUkJ4YyGBNIiJy7rgvFtuKoC09rJ5mM3C7JS2OVkHbIKZCTzP_V9XiV8lxLyf8k8my12JpejJ-V2eXwR7slGzK1rlMWPfyqX0NYWoZhPQNHwfS-q4PDwmUjkaQ6Yi9-UuOA.DN_KByhe3Nib4vfBR0UItQ.Nvto7EpylKqg8X288I8gFl4zXkmOf6R8ApSaDexC4H-OeOmrrO6WnEhygDDqcpIWwIbGaAWHCXtNdlXOM5kERdxE0YIIWNeRZgKOM3ryYcW8P-8rTi8_NxVo7hnzyXj75mOVZpDjwSZCAVI2F5rc4iTSdoSCrHutWx2YrpzqviDfgeYDopdLblTF5-qU5LWQ2HuoLM4axFVTnHnGUqwTlc26Ank5quvEGXyIzLnGSFDrkrUkv6rB0mcNTlkeidGP43YhfTlRQHie15hYRWz1gs-c17RcWPZ6CR4cn32JNNhBMnmqr2Oc6nMWepoTzKjRydobAoj0ksEVl24G4NViI4ZcpjxWeK1oaqzK9p4BuIElG5iWnuA6IYfsnB6ucKrupz1w8gIApYKzR4rGgX7qeFqtGd8Y8YRTKNnjtoC2mbcxUNfavjTF6L92grZ65RUTEerZai79KGrgNltU8eFNUS2CXCVSjzHrCJxQvc0zayjrjwZZkbm3FsIRCZJb_GGGL4655Xu3N9sPclyFIdhAHaAU3PHfyyloell8VyrMIA6DvrtkRkgDklCZiPT-opex1tzoOSREbQmxhCUuFT3SWnd5LqZPr8vOvtl78UstkX8MswOUktReKHhyk6FI3RItRkhePUIyU9h5Txrys8QEoC5FVqZga2NUJt7lx2N4FymmlKgnA2zk_R9o1fBUmHIAo0poL6mksengfOmKQaayZf7ucozxs_yK2RWwdECtOFnQboSkKbOXf-st5yAozwHIOHv5cyUTksOYPN0U_T-WOS0rNXMdX72ImssYO4RwzSroqHzDcN0dut7SUFpNRCJt-BZC2WT7U3D1lgylWdinhLJXvsooVNcz67dt4LqRscZTrA06ogyB73O09W8U2BkcbS-D00sY9z47ldWnAZqjsJvFU3j_0Sthf__86by6olYJhhqs26uEwUPtxomKTJMmgg_NPQNKLTIXYMfLTa5kfn1VY21jZQNcNjYvl7Q_FIh4N5TOSbLTXtXPJKuUIkKoWKf5pgcL5-Bd1sWGg8j0QSVf6v2nUHknASiYzvXOzaAhv9oZncbmsByNww9qreP_IuRWhzHJ-icdywXC18rn1TZRKPPhjKmEwvBEOcwECPfo3mnVlshL_v0pI1KRQ5GDkpI_0fybcokOaFZ1ddwEAgdV17Wrs3cdx-Bd0NJzI6fVbxOVIopa0Kx2Nf6q03afDpv5sHWRZXS3d9q_r68N4h5hkmcENha1UT5MHJ_KWAgBGkk9iVT-HJB1CsfdBnxSuK8DqBpWnjmA1I4RZqkgODglsyjobQ771iufohCKAJU.w-I8d3mv3c76-78WfZQsxY9bKOJ9NxEncfiMxwcBbTI'
    const jweConError =
      'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.QC4PUVFGquk9AK6kUgd6zw2p4gkyeUyFfX0u5sdPKwnIMlub9YvFVcCckpgcjOvUmSFf65d1XoGPHi4V7inkkUhlFn6Yn-Z8u3raIJVgrdSm57EqUqWOYXfHV6N8RfPD1XPxar85ZGdegW1kbKISEVj-stI4qOatX9sMQL29BJ4zfV9bCt7QgwTwdGywircQHaGpzTB2Jxu-t9NQ_nHuP3Oo1vrzZRCZDGCtslNXBORC7e3eqpxTa5mzAOE_x6nqdN7X--py-Ue5b5iD7xw1-EKHFrNg6cXCi-OMtxzTRaBQN9IsVYUcgkuRyJubYH_XOqEo-EOaVxsnUOCdr3dOcQ.21N9VqRD4aaQZIPSy2bV2A.mDmU01Loj_iO7Flh8ehAboLDr-UlHPqw6T-Pp6wQLK5MH9_36Sj68zWO7xavMbTNbmV39YQX988BEJxcnxF9Ufk7aek7iryXRAcrSCZUZuKxEQugH__Xtfg_OMvU8XZs3P6aB3LiHsHE3spSBQzroslZvDp9Ol4OmB4nylP8UeqmI3O6xIM2kNHj5G4HOtk4kiJ4PeszCqX0t3gNPtHIK_MYkpyKsb-YHLCwP2WAgBV0nxvhp_JKNer0JY-2eMCZWJJfKHKC_2NV2MN4In67qk7oXE_IQPerFWWXPgtisMs_5N37WFL3Pzz1atPN05aLVhD7l2HfTqd5ihiGD0SoJaN5DEPMYhmHdyav8DtYZiDME6c_g8Mw_SZSGbTCA3tkxpwgaBaNJfJ0mKY1JAokwTlxxpI2ommglR7O6Xiex9Va9t36EigROX9Eens7pukR6_9C8Ki6OwO-fqUbJSrndByK2geElzqnu-8gq8Xee45DTGmiLXpZt_p0_KGrEjJFmHLzHy_yIa2IN8UAYvOtzvteMdvo8AzL5E9vzZFqN40hMvXqZvK94-2Rcbg2lednOFyZOTttFN2IV_RH5_eWAMKNFPxefLFN4bGYbT5U7ebVq6Ma_9cVl9W6x2jn-v--OYkTkAmzdIe0-zgaJw67uXaImA01WjqbBV99xwBZdOO2DbGHpenonYViHRQa50xZWJl-aEBKzcXZbTit3Ev3bTHOyqRUy6g9r_XBlxtRCVsTTAvOGY3vzkDsU-bpvXqy-wnc2StiBasL7RGh2t0t1avxloa3w4SaBzFt6WARcDoGiNJ9YeUAIP5RHcEh_iOKKYtVcKJnuFY1QKabbGeK6oO0VrPEck0mwha1EG7tljHA-pabhRX8w4rYuiWTj1GI1bolt3oTFYF-CXuXFO4BR7odzI4ANnnlUKNTGwUUF99Xue5iQ6E4lVjL3mJ7V2tmQYlJ7r66Qw4OeIBdY-qtX_6wtazWzwV-8qe8FZrFCdp2UJJjZf8eHlZ9XEKxz7DYmx6H_UZ9wMevxFzjRvN99hkiyDaQ9a8S8N4xP22l6GBP-qNxTIg_lvKPKe-Qv-FclwfSm06JIomAnyWKX5TVxY_MdJUIkvFbDRcAJix37nM7ooMijN9CwAsKZrmwIUG8JKDkGvSZE0gNmckcCDjM93AEVx-WhOoXBeQor43S3HZIBoxxXjaKMBLSdDBkVHYQJ22fm5Yf0XxEhoXx8No3TJUn346qHZgAqaInzJ8gn7hBYH8XXVgolvfuEa-apiDs8lwhC_otEOD1lBL15zCKskBK_OPEZNUfex4wTvdVkzg.0KUMAJiVE4Zu8G6erbgNgTYwaDoIohEIEI7yNmZZwWM'

    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockOtpToken)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayloadAux1)
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: jweConError })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  test('Error en servicio de persistencia -> retorno error 500', async (done) => {
    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockOtpToken)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayloadSinGenericData)
    )

    // mock de persistencia
    persistence.setData = jest.fn((kind: string, k: string, d: any) =>
      Promise.reject(new Error('ups-en-persistencia'))
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: mockJwe })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('ups-en-persistencia')
      done()
    }
  })

  test('Error en servicio de autenticacion -> retorno error 500', async (done) => {
    // mock de persistencia
    persistence.setData = jest.fn((kind: string, k: string, d: any) =>
      Promise.resolve(true)
    )

    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.reject(new Error('ups-en-auth'))
    )

    try {
      const sesion = await presentacion.crear({ data: mockJwe })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('ups-en-auth')
      done()
    }
  })
})
