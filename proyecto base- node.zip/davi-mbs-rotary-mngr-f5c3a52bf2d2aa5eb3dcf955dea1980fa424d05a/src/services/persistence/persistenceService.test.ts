//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import axios from 'axios'

// Crear mock de Axios para llamadas HTTP
jest.mock('axios')

// Crear mock Config
class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        persistenceServiceUrl: 'http://test/api',
      },
    }
  }
}

describe('PersistenceService', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('info')
  const persistence = new PersistenceService(config, logger)

  /*********************************************************************************************
   *    t e s t i n g   d e   g e t D a t a
   **********************************************************************************************/
  test('getData con parametros correctos y jti existente no da error y retorna datos persistidos', async done => {
    // Preparar datos a usar en el test
    const mockData = {
      client_id: 'eb54bff0-1b59-11e9-8b39-4fc4ffc85d07',
      exp: 1548272862,
      jti: 'eb56bbc0-1b59-11e9-9073-871f99bd61dd',
    }
    const mockResponse = {
      data: {
        data: mockData,
      },
      status: 200,
    }
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'

    // Decirle a axios que responder para get
    axios.get = jest.fn().mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.getData(kind, jti)
    } catch (err) {
      expect(err).toBeFalsy()
    }

    // Verificar los resultados
    expect(returnedData).toEqual(mockData)
    expect(axios.get).toHaveBeenCalledTimes(1)
    expect(axios.get).toHaveBeenCalledWith(`http://test/api/data/${kind}/${jti}`)
    done()
  })

  test('getData con jti inexistente (404) retorna data vacio y no da error', async done => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: null,
      },
      status: 404,
    }
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'

    // Decirle a axios que responder para get
    axios.get = jest.fn().mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.getData(kind, jti)
    } catch (err) {
      expect(err).toBeFalsy()
    }

    // Verificar los resultados
    expect(returnedData).toBeNull()
    expect(axios.get).toHaveBeenCalledTimes(1)
    expect(axios.get).toHaveBeenCalledWith(`http://test/api/data/${kind}/${jti}`)
    done()
  })

  test('getData con problema de backend (500) devuelve error', async done => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: null,
        errors: ['internal_server_error'],
      },
      status: 500,
    }
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'

    // Decirle a axios que responder para get
    axios.get = jest.fn().mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.getData(kind, jti)
    } catch (err) {
      expect(err.message).toContain('internal_server_error')
      done()
    }

    // Verificar los resultados
    expect(returnedData).toBeFalsy()
    expect(axios.get).toHaveBeenCalledTimes(1)
    expect(axios.get).toHaveBeenCalledWith(`http://test/api/data/${kind}/${jti}`)
  })

  test('getData con problema de axios loggea y devuelve error', async done => {
    // Preparar datos a usar en el test
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'
    const errorMessage = 'some_error'
    logger.clearLogs()

    // Decirle a axios que responder para get
    axios.get = jest.fn().mockImplementationOnce(() => Promise.reject(errorMessage))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.getData(kind, jti)
    } catch (err) {
      expect(err).toBeTruthy()
      expect(err).toEqual(errorMessage)

      const logs = logger.dumpLogs()
      expect(logs[0].level).toEqual('ERROR')
      expect(logs[0].message).toContain(`PersistenceService:getData - kind: ${kind} - key: ${jti} - error: ${errorMessage}`)
      done()
    }

    // Verificar los resultados
    expect(returnedData).toBeFalsy()
    expect(axios.get).toHaveBeenCalledTimes(1)
    expect(axios.get).toHaveBeenCalledWith(`http://test/api/data/${kind}/${jti}`)
  })

  test('getData con problema de axios loggea y devuelve error (404)', async done => {
    // Preparar datos a usar en el test
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'
    const errorMessage = {
      response: {
        message: 'some_error',
        status: 404,
      },
    }

    // Decirle a axios que responder para get
    axios.get = jest.fn().mockImplementationOnce(() => Promise.reject(errorMessage))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.getData(kind, jti)
      expect(returnedData).toEqual(null)
    } catch (err) {
      expect(err).toBeTruthy()
    }
    done()
  })

  /*********************************************************************************************
   *    t e s t i n g   d e   s e t D a t a
   **********************************************************************************************/
  test('setData con parametros correctos y jti existente no da error', async done => {
    // Preparar datos a usar en el test
    const mockData = {
      client_id: 'eb54bff0-1b59-11e9-8b39-4fc4ffc85d07',
      exp: 1548272862,
      jti: 'eb56bbc0-1b59-11e9-9073-871f99bd61dd',
    }
    const mockResponse = {
      data: {
        data: mockData,
      },
      status: 200,
    }
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'

    // Decirle a axios que responder para get
    axios.put = jest.fn().mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.setData(kind, jti, mockData)
    } catch (err) {
      expect(err).toBeFalsy()
    }

    // Verificar los resultados
    expect(returnedData).toBe(true)
    expect(axios.put).toHaveBeenCalledTimes(1)
    expect(axios.put).toHaveBeenCalledWith(
      `http://test/api/data/${kind}/${jti}`,
      {
        kind,

        data: mockData,
        key: jti,
      }
    )
    done()
  })

  test('setData con problema de backend (500) loggea y devuelve error', async done => {
    // Preparar datos a usar en el test
    const mockData = {
      client_id: 'eb54bff0-1b59-11e9-8b39-4fc4ffc85d07',
      exp: 1548272862,
      jti: 'eb56bbc0-1b59-11e9-9073-871f99bd61dd',
    }
    const errorMessage = 'internal_server_error'
    const mockResponse = {
      data: {
        data: null,
        errors: [errorMessage],
      },
      status: 500,
    }
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'
    logger.clearLogs()

    // Decirle a axios que responder para get
    axios.put = jest.fn().mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.setData(kind, jti, mockData)
    } catch (err) {
      expect(err.message).toContain('internal_server_error')

      const logs = logger.dumpLogs()
      expect(logs[0].level).toEqual('ERROR')
      expect(logs[0].message).toContain(`PersistenceService:setData - kind: ${kind} - key: ${jti} - status: 500`)
      done()
    }

    // Verificar los resultados
    expect(returnedData).toBeFalsy()
    expect(axios.put).toHaveBeenCalledTimes(1)
    expect(axios.put).toHaveBeenCalledWith(
      `http://test/api/data/${kind}/${jti}`,
      {
        kind,

        data: mockData,
        key: jti,
      }
    )
  })

  test('setData con problema de axios loggea y devuelve error', async done => {
    // Preparar datos a usar en el test
    const mockData = {
      client_id: 'eb54bff0-1b59-11e9-8b39-4fc4ffc85d07',
      exp: 1548272862,
      jti: 'eb56bbc0-1b59-11e9-9073-871f99bd61dd',
    }
    const errorMessage = 'some_error'
    const jti = 'eb56bbc0-1b59-11e9-9073-871f99bd61dd'
    const kind = 'otpbl'
    logger.clearLogs()

    // Decirle a axios que responder para get
    axios.put = jest.fn().mockImplementationOnce(() => Promise.reject(errorMessage))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await persistence.setData(kind, jti, mockData)
    } catch (err) {
      expect(err).toBeTruthy()
      expect(err).toEqual(errorMessage)

      const logs = logger.dumpLogs()
      expect(logs[0].level).toEqual('ERROR')
      expect(logs[0].message).toContain(`PersistenceService:setData - kind: ${kind} - key: ${jti} - error: ${errorMessage}`)
      done()
    }

    // Verificar los resultados
    expect(returnedData).toBeFalsy()
    expect(axios.put).toHaveBeenCalledTimes(1)
    expect(axios.put).toHaveBeenCalledWith(
      `http://test/api/data/${kind}/${jti}`,
      {
        kind,

        data: mockData,
        key: jti,
      }
    )
  })
})
