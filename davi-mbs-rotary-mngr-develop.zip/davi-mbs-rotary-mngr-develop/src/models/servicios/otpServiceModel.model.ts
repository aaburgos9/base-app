export class OtpServiceData {
  /*
   * Atributos
   */
  public numeroIntentos: number = 0
  public otp: string = ''
  public valIdTokenOTP: string = ''
  public valTokenOTP: string = ''
  public fechaExpiracion: string = ''
  public fechaGeneracionOtp: string = ''
  public horaGeneracionOtp: string = ''

  /*
   * Metodo constructor (inicialización) de la clase OtpServiceData
   */
  constructor(
    numeroIntentos: number,
    otp: string,
    valIdTokenOTP: string,
    valTokenOTP: string,
    fechaExpiracion: string,
    fechaGeneracionOtp: string,
    horaGeneracionOtp: string
  ) {
    this.numeroIntentos = numeroIntentos
    this.otp = otp
    this.valIdTokenOTP = valIdTokenOTP
    this.valTokenOTP = valTokenOTP
    this.fechaExpiracion = fechaExpiracion
    this.fechaGeneracionOtp = fechaGeneracionOtp
    this.horaGeneracionOtp = horaGeneracionOtp
  }
}
