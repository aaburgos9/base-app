//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence'
import {
  consumoResponseB,
  consumoResponseM,
} from '@services/workflowService/steps/Rotatitvo/INFO0010/INFO0010MockData'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi from 'joi'
import moment from 'moment'
import { KIND } from '~/models/enums/kind.enum'
import { GrabarInformacionSolicitudesModel } from '~/models/servicios/grabarInformacionSolicitudes'
import { UTILITIES } from '~/utils/utilities'

const STEP: string = 'INFO0010'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    // tslint:disable: object-literal-sort-keys
    atras: joi.boolean().required(),
    actividadEconomica: joi.string().optional().allow(''),
    direccionPrincipal: joi.string().optional().allow(''),
    ciudadResidencia: joi.string().optional().allow(''),
    actividadLaboral: joi.object().optional(),
    tipoContrato: joi.object().optional(),
    ingresosMensuales: joi.string().optional().allow(''),
    autorizacion: joi.object().optional(),
    nombreEmpresa: joi.string().optional().allow(''),
    codigoAsesor: joi.string().optional().allow(''),
  })
  .optional()

export class INFO0010 extends Step {
  private parmsData: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger,
    private persistence: IPersistenceService
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData

    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )
    if (reqPayload.atras === true) {
      // Flujo: exitoso
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,
          lenguaje: this.sessionData.dataProducto.codIdioma,
          message: '',
          modulo: this.parmsData.kind,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.BYC0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > INFO0010 - Flujo Atras hacia BYC0010`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }

    // se persiste en sesion los datos de formulario
    this.sessionData.sesion.datosFormulario.actividadEconomica =
      reqPayload.actividadEconomica ? reqPayload.actividadEconomica : ''
    this.sessionData.sesion.datosFormulario.actividadLaboral =
      reqPayload.actividadLaboral ? reqPayload.actividadLaboral : ''
    this.sessionData.sesion.datosFormulario.autorizacion =
      reqPayload.autorizacion ? reqPayload.autorizacion : ''
    this.sessionData.sesion.datosFormulario.ciudadResidencia =
      reqPayload.ciudadResidencia ? reqPayload.ciudadResidencia : ''
    this.sessionData.sesion.datosFormulario.codigoAsesor =
      reqPayload.codigoAsesor ? reqPayload.codigoAsesor : ''
    this.sessionData.sesion.datosFormulario.direccionPrincipal =
      reqPayload.direccionPrincipal ? reqPayload.direccionPrincipal : ''
    this.sessionData.sesion.datosFormulario.ingresosMensuales =
      reqPayload.ingresosMensuales ? reqPayload.ingresosMensuales : '0'
    this.sessionData.sesion.datosFormulario.nombreEmpresa =
      reqPayload.nombreEmpresa ? reqPayload.nombreEmpresa : ''
    this.sessionData.sesion.datosFormulario.tipoContrato =
      reqPayload.tipoContrato
        ? reqPayload.tipoContrato
        : { tipoContrato: { codigo: '', descripcion: '' } }

    // this.sessionData.sesion.evaluadorPCO.valor

    // Lógica de obtención de parametros del step (INFO0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.INFO0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()

    // Lógica del step

    // Crear Consultar Tasas Y Simulador Primera Cuota

    try {
      const result = await this.ConsultarTasasYSimuladorPrimeraCuota()

      this.logger.debug(
        `${STEP}:getNextStep - ConsultarTasasYSimuladorPrimeraCuota Response:
          ${JSON.stringify(result)}`,
        this.sessionData.sesion.clientId
      )
      this.sessionData.sesion.evaluadorPCO.valorCobroSeguroVida =
        result.Data?.seguroVidaITPXMillon
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir ConsultarTasasYSimuladorPrimeraCuota
          ${JSON.stringify(error)} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    // Crear actualizar cliente
    try {
      const result = await this.crearActualizarCliente(reqPayload)

      this.logger.debug(
        `${STEP}:getNextStep - crearActualizarCliente ${JSON.stringify(
          result
        )}`,
        this.sessionData.sesion.clientId
      )

      if (result.data === '1') {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.INFO0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > no se pudo crear cliente: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )
        return nextStep
      }
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir crearActualizarCliente ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    // Consumo srvScnGenercionReporte
    let resultGenerarReporte: any

    try {
      resultGenerarReporte = await this.srvScnGenercionReporte()

      this.logger.debug(
        `${STEP}:getNextStep - srvScnGenercionReporte ${JSON.stringify(
          resultGenerarReporte
        )}`,
        this.sessionData.sesion.clientId
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir srvScnGenercionReporte ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGenerarReporte.data.contextoRespuesta.resultadoTransaccion
        .valCaracterAceptacion ===
      this.parmsData.generacionReporte.valCaracterAceptacionM
    ) {
      // Flujo: caracter de aceptacion M srvScnGenercionReporte
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,
          lenguaje: this.sessionData.dataProducto.codIdioma,
          message: STATUS_MSG.MSG_crrt_004,
          modulo: this.sessionData.dataProducto.moduloId,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.INFO0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > INFO0010 - caracter de aceptacion M srvScnGenercionReporte`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }

    // consumo evaluador
    let valorAprobadoF = 0
    let valorCobroSeguroVidaF = 0
    let decisionCategoryF = ''
    let codigoCausalDecisionSolicitudf = ''
    let causalDecisionSolicitudf = ''
    try {
      const result = await this.consumoEvaluador(reqPayload)

      this.logger.debug(
        `${STEP}:getNextStep - consumoEvaluador ${JSON.stringify(result)}`,
        this.sessionData.sesion.clientId
      )

      valorAprobadoF = result.data.ValorAprobado
      valorCobroSeguroVidaF = result.data.ValorCobroSeguroVida
      decisionCategoryF = result.data.DecisionCategory
      codigoCausalDecisionSolicitudf = result.data.CodigoCausalDecisionSolicitud
      causalDecisionSolicitudf =
        result.data.CausalDecisionSolicitud?.causalDecisionSolicitud1
      // persistir en sesion los datos de consumo evaluador
      this.sessionData.sesion.evaluadorPCO.causalDecisionSolicitud =
        result.data.CausalDecisionSolicitud
      this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud =
        result.data.CodigoCausalDecisionSolicitud
      this.sessionData.sesion.evaluadorPCO.decisionCategory =
        result.data.DecisionCategory
      this.sessionData.sesion.evaluadorPCO.valorAprobado =
        result.data.ValorAprobado
      this.sessionData.sesionRetoma.evaluadorPCO.valorAprobado =
        result.data.ValorAprobado

      if (result.data.CaracterAceptacion === 'M') {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.INFO0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > Error consumoEvaluador, caracter de aceptacion M: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )
        return nextStep
      }

      if (this.sessionData.sesion.evaluadorPCO.decisionCategory === 'NEG') {
        let popUp = STATUS_MSG.MSG_crrt_010
        if (
          this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud ===
            this.parmsData.consumoEvaluador.NegadoCapacidadPago ||
          this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud ===
            this.parmsData.consumoEvaluador.NegadoCapacidadPago2
        ) {
          popUp = STATUS_MSG.MSG_crrt_014
        }
        if (
          this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud ===
          this.parmsData.consumoEvaluador.NegadoClienteNoCupo
        ) {
          popUp = STATUS_MSG.MSG_crrt_015
        }
        if (
          this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud ===
          this.parmsData.consumoEvaluador.NegadoIngresoMínimo
        ) {
          popUp = STATUS_MSG.MSG_crrt_016
        }
        if (
          this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud ===
          this.parmsData.consumoEvaluador.NegadoMora
        ) {
          popUp = STATUS_MSG.MSG_crrt_017
        }
        this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
          this.parmsData.grabarInformacionSolicitudes.estadoNegado
        this.sessionData.sesion.evaluadorPCO.valorAprobado = valorAprobadoF
        this.sessionData.sesion.grabarInfoSol.nroProceso =
          this.parmsData.grabarInformacionSolicitudes.numeroProcesoEvaluacion

        try {
          const resultGrabarInfo = await this.grabarInformacionSolicitudes()

          this.logger.debug(
            `${STEP}:getNextStep - Credito negado - grabarInformacionSolicitudes ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep -  Credito negado - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: popUp,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.INFO0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > Credito Negado: ${JSON.stringify(nextStep)}`,
          this.sessionData.sesion.clientId
        )
        return nextStep
      }
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir consumoEvaluador ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    this.logger.debug(
      `${STEP}:getNextStep > Credito Aprobado`,
      this.sessionData.sesion.clientId
    )
    // desactivar la retoma parcial
    this.sessionData.retomaParcial.status = false
    // Persistir fecha de la retoma
    this.sessionData.flujo.fechaRetoma = new Date().toISOString()
    // control de flujo
    this.sessionData.flujo.stepINFO0010 = true
    this.sessionData.flujo.clienteEnRetoma = true
    // Persistir datos de la retoma
    const key = `${this.sessionData.dataProducto.tipoDocumento}-${this.sessionData.dataProducto.numeroDocumento}`
    try {
      await this.persistence.setData(KIND.RETOMA, key, this.sessionData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    /// GrabarInformacionSolicitudes
    this.sessionData.sesion.evaluadorPCO.valorAprobado = valorAprobadoF
    this.sessionData.sesion.grabarInfoSol.nroProceso =
      this.parmsData.grabarInformacionSolicitudes.numeroProcesoEvaluacion
    this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
      this.parmsData.grabarInformacionSolicitudes.estadoAprobado

    try {
      const resultGrabarInfo = await this.grabarInformacionSolicitudes()

      this.logger.debug(
        `${STEP}:getNextStep - Credito aprobado - grabarInformacionSolicitudes ${JSON.stringify(
          resultGrabarInfo
        )}`,
        this.sessionData.sesion.clientId
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    // Flujo: exitoso
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        canal: this.sessionData.dataProducto.canalId,
        kind: this.sessionData.dataProducto.moduloId,
        lenguaje: this.sessionData.dataProducto.codIdioma,
        message: '',
        modulo: this.parmsData.kind,
        pais: this.sessionData.dataProducto.country,
        redirectPostMessage: '',
        tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
        valorAprobado: valorAprobadoF,
        valorCobroSeguroVida: this.sessionData.sesion.evaluadorPCO
          .valorCobroSeguroVida
          ? this.sessionData.sesion.evaluadorPCO.valorCobroSeguroVida
          : valorCobroSeguroVidaF,
        decisionCategory: decisionCategoryF,
        codigoCausalDecisionSolicitud: codigoCausalDecisionSolicitudf,
        causalDecisionSolicitud: causalDecisionSolicitudf,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.FELI0010,
    }
    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > INFO0010 - Flujo Exitoso`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

  private crearActualizarCliente = async (reqPayload: any) => {
    this.logger.debug(
      'crearActualizarCliente',
      this.sessionData.sesion.clientId
    )

    let crearActualizarRest: any

    const endpointUrl = `${
      this.config.getVars().back.crearActualizarCliente
    }/crear-actualizar-clientepn`

    const payload = {
      payload: {
        auditoriaJuridico: false, // obtener de objeto para mas micros
        auditoriaOperaciones: 'true',
        datapower: {
          codCanal: this.sessionData.dataProducto.canalId,
          codPais: this.sessionData.dataProducto.country.toLowerCase(),
        },
        juridico: null,
        operaciones: {
          consumer: {
            appConsumer: {
              canalId: this.sessionData.dataProducto.canalId,
              id: this.sessionData.dataProducto.moduloId,
              sessionId: this.sessionData.sesion.clientId,
            },
            deviceConsumer: {
              id: this.sessionData.dataProducto.deviceConsumerId,
              ip: this.sessionData.sesion.ip,
              locale: 'CO',
              terminalId: this.sessionData.dataProducto.terminalId,
              userAgent: this.sessionData.dataProducto.userAgent,
            },
          },
          documento: {
            numero: this.sessionData.dataProducto.numeroDocumento,
            tipo: this.sessionData.dataProducto.tipoDocumento,
          },
          messages: {
            idService: this.parmsData.crearActualizarCliente.idService,
            requestService: '',
            responseService: '',
          },
          operation: {
            operationDate: new Date().toISOString(),
            statusResponse: {
              status:
                this.parmsData.crearActualizarCliente.operaciones.operation
                  .statusResponse.status,
            },
            type: this.parmsData.crearActualizarCliente.operaciones.operation
              .type,
          },
        },
        service: {
          request: {
            data: {
              contact: [
                {
                  descTipoIdentificacionCLI:
                    this.sessionData.dataProducto.tipoDocumento,
                  listOfDAVIngresos: {
                    davIngresos: [
                      {
                        actividadEconomicaIN: reqPayload.actividadEconomica
                          ? reqPayload.actividadEconomica
                          : '',
                        valActividadEconomicaIN: reqPayload.actividadEconomica,
                        // tslint:disable-next-line: object-literal-sort-keys
                        // formato MES/DIA/Año
                        fechaInicioIN: new Intl.DateTimeFormat('en-US').format(
                          new Date()
                        ),
                        isPrimaryMVG:
                          this.parmsData.crearActualizarCliente.service
                            .listOfDAVIngresos.isPrimaryMVG,
                        tipoActLaboralIN: reqPayload.actividadLaboral.codigo,
                        tipoContratoIN:
                          reqPayload.actividadLaboral.codigo === 'E'
                            ? reqPayload.tipoContrato.codigo
                            : '',
                        nombreEmpresaIN:
                          reqPayload.actividadLaboral.codigo === 'E'
                            ? reqPayload.nombreEmpresa
                            : '',
                        valorIN: reqPayload.ingresosMensuales,
                        tipoIN:
                          reqPayload.actividadLaboral.codigo === 'E'
                            ? 1
                            : reqPayload.actividadLaboral.codigo === 'I'
                            ? 2
                            : reqPayload.actividadLaboral.codigo === 'P'
                            ? 3
                            : 1,
                      },
                    ],
                  },
                  nroIdentificacionCLI:
                    this.sessionData.dataProducto.numeroDocumento,
                },
              ],
            },
            dataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: moment().unix(),
              jornada:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .jornada,
              modoDeOperacion:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .modoDeOperacion,
              nombreOperacion:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .nombreOperacion,
              perfil:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .perfil,
              total: '',
              usuario:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .usuario,
              versionServicio:
                this.parmsData.crearActualizarCliente.service.request.dataHeader
                  .versionServicio,
            },
          },
        },
        // tokenDatapower: "vj7M3+1J8d7HDb3ekQSYcsqpDJ827DX8xm986WmaGQ=" // muy posiblemente no sea necesario
      },
    }
    this.logger.debug(
      `${STEP}:crearActualizarCliente - payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )
    try {
      crearActualizarRest = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      crearActualizarRest.data.codError ||
      parseInt(crearActualizarRest.data.status, 10) === 500
    ) {
      {
        throw new ServiceError(
          MBAAS_ERRORS.internal_server_error,
          new Error(JSON.stringify(crearActualizarRest.data.errors))
        )
      }
    }

    const crearActualizarSalida = {
      codMsgRespuesta:
        crearActualizarRest.data.response.response.dataHeader.codMsgRespuesta,
    }

    this.logger.debug(
      `${STEP}:crearActualizarCliente - Response: ${JSON.stringify(
        crearActualizarRest.data
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: crearActualizarRest.data.response.response.dataHeader
        .codMsgRespuesta,
    }
  }

  private srvScnGenercionReporte = async () => {
    this.logger.debug(
      'srvScnGenercionReporte',
      this.sessionData.sesion.clientId
    )

    let resultGenerarReporte: any
    const endpointUrl = `${
      this.config.getVars().back.srvScnGenercionReporte
    }/generarReporte`

    const transaccionID = moment().unix()

    const opera = {
      sessionId: this.sessionData.sesion.clientId,
      // tslint:disable-next-line: object-literal-sort-keys
      canalId: this.sessionData.dataProducto.canalId,
      id: this.sessionData.dataProducto.moduloId,
      ip: this.sessionData.sesion.ip,
      moduleId: this.sessionData.dataProducto.moduloId,
      client: {
        documentClient: {
          number: this.sessionData.dataProducto.numeroDocumento,
          type: this.sessionData.dataProducto.tipoDocumento,
        },
        userId: this.sessionData.sesion.clientId,
      },
    }
    Object.assign(opera, { logger: this.parmsData.loggerVersion })
    const payload = {
      payload: {
        msjSolOpGeneracionReporte: {
          contextoSolicitud: {
            servicio: {
              idServicio: this.parmsData.generacionReporte.idServicio,
            },
            // tslint:disable-next-line: object-literal-sort-keys
            operacionCanal: {
              idSesion: this.sessionData.dataProducto.sesionIdCanal,
              idTransaccion: transaccionID.toString(),
              // tslint:disable-next-line: object-literal-sort-keys
              fecOperacion: UTILITIES.fechaYYYYMMDDTHHMMSS(),
              valJornada: this.parmsData.valJornada,
              codMoneda: this.parmsData.codMoneda,
              codPais: this.parmsData.codPais,
              codIdioma: this.parmsData.codIdioma,
            },
            consumidor: {
              idConsumidor: this.parmsData.generacionReporte.idConsumidor,
              // tslint:disable-next-line: object-literal-sort-keys
              aplicacion: {
                idAplicacion: this.parmsData.generacionReporte.idAplicacion,
              },
              canal: {
                idCanal: this.sessionData.dataProducto.canalId,
                idHost: this.sessionData.sesion.ip,
              },
              terminal: {
                idTerminal: this.sessionData.dataProducto.terminalId,
                valOrigenPeticion: this.sessionData.sesion.ip,
                // tslint:disable-next-line: object-literal-sort-keys
                codUsuario: this.parmsData.codUsuario,
                valPerfil: this.parmsData.valPerfil,
              },
            },
          },
          // tslint:disable-next-line: object-literal-sort-keys
          cliente: {
            nombres: this.sessionData.sesion.consultaClientePN.nombres,
            primerApellido:
              this.sessionData.sesion.consultaClientePN.primerApellido,
            segundoApellido:
              this.sessionData.sesion.consultaClientePN.segundoApellido,
            tipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
            // tslint:disable-next-line: object-literal-sort-keys
            numeroIdentificacion: this.sessionData.dataProducto.numeroDocumento,
            ciudadExpedicionDocumento:
              this.sessionData.sesion.consultaClientePN.lugarExpedicion,
            valMail: this.sessionData.sesion.consultaClientePN.email,
          },
          valIdPlantilla: this.parmsData.generacionReporte.idPlantilla,
          valVersionPlantilla:
            this.parmsData.generacionReporte.valVersionPlantilla,
          listaParametros: {
            valParametro: [
              {
                id: this.parmsData.generacionReporte.valParametro[0],
                valor: this.sessionData.sesion.consultaClientePN.nombres,
              },
              {
                id: this.parmsData.generacionReporte.valParametro[1],
                valor:
                  this.sessionData.dataProducto.tipoDocumento === '01'
                    ? 'CC'
                    : 'CC',
              },
              {
                id: this.parmsData.generacionReporte.valParametro[2],
                valor: this.sessionData.sesion.consultaClientePN.primerApellido,
              },
              {
                id: this.parmsData.generacionReporte.valParametro[3],
                valor:
                  this.sessionData.sesion.consultaClientePN.segundoApellido,
              },
              {
                id: this.parmsData.generacionReporte.valParametro[4],
                valor: this.sessionData.dataProducto.numeroDocumento,
              },
              {
                id: this.parmsData.generacionReporte.valParametro[5],
                valor:
                  this.sessionData.dataProducto.canalId === '37'
                    ? 'APP'
                    : 'APP',
              },
              {
                id: this.parmsData.generacionReporte.valParametro[6],
                valor: this.sessionData.sesion.ip,
              },
              {
                id: this.parmsData.generacionReporte.valParametro[7],
                valor: UTILITIES.fechaYYYYMMDDSeparadores('-'),
              },
              {
                id: this.parmsData.generacionReporte.valParametro[8],
                valor: UTILITIES.horaHHMMSSSeparador(),
              },
            ],
          },
          retornaDocumento: this.parmsData.generacionReporte.retornaDocumento,
          enviarFileNet: this.parmsData.generacionReporte.enviarFileNet,
        },
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          // tslint:disable-next-line: object-literal-sort-keys
          canalId: this.sessionData.dataProducto.canalId,
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          moduleId: this.sessionData.dataProducto.moduloId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          logger: this.parmsData.loggerVersion,
        },
      },
    }
    this.logger.debug(
      `${STEP}:srvScnGenercionReporte - payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGenerarReporte = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGenerarReporte.data.errors &&
      resultGenerarReporte.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGenerarReporte.data.errors))
      )
    }

    const generarReporteRes = resultGenerarReporte.data
    this.logger.debug(
      `${STEP}:srvScnGenercionReporte - Response: ${JSON.stringify(
        generarReporteRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: generarReporteRes,
    }
  }

  private consumoEvaluador = async (reqPayload: any) => {
    // tslint:disable: object-literal-sort-keys
    this.logger.debug('consumoEvaluador', this.sessionData.sesion.clientId)

    let consumoEvaluadorRest: any

    const endpointUrl = `${
      this.config.getVars().back.consumoEvaluador
    }/evaluador`
    // tslint:disable: variable-name
    let IngresosEmpleado = 0
    let IngresosIndependiente = 0
    let IngresosPensionado = 0
    if (reqPayload.actividadLaboral.codigo === 'E') {
      IngresosEmpleado = reqPayload.ingresosMensuales
    }
    if (reqPayload.actividadLaboral.codigo === 'I') {
      IngresosIndependiente = reqPayload.ingresosMensuales
    }
    if (reqPayload.actividadLaboral.codigo === 'P') {
      IngresosPensionado = reqPayload.ingresosMensuales
    }

    const payload = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: moment().unix(),
              total:
                this.parmsData.consumoEvaluador.service.Request.DataHeader
                  .total,
            },
            DVSolicitud: {
              NumeroSolicitud:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              NumeroSolicitantes:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .NumeroSolicitantes,
              NumeroProductosSolicitados:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .NumeroProductosSolicitados,
              FechaSolicitud: new Date().toISOString().slice(0, 10),
              Agente: reqPayload.codigoAsesor ? reqPayload.codigoAsesor : '0',
              Canal:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .Canal,
              FlagCampanaFirme:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagCampanaFirme, // check valor
              EstadoOportunidad:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .EstadoOportunidad,
              GrupoProductoRPRBuro:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .GrupoProductoRPRBuro,
              GrupoSubproductoRPRBuro:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .GrupoSubproductoRPRBuro,
              FlagFraudeVendedor:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagFraudeVendedor, // check valor
              FlagFraudeCentroNegocio:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagFraudeCentroNegocio, // check valor
            },
            DVSolicitante: {
              Solicitante: {
                CiudadResidencia:
                  this.sessionData.sesion.consultaClientePN.ciudadDI,
                DeptoResidencia:
                  this.sessionData.sesion.consultaClientePN.departamentoDI,
                EsFuncionarioBanco:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.EsFuncionarioBanco,
                FechaExpCedula:
                  this.sessionData.sesion.consultaClientePN.fechaExpedicionCLI,
                NumeroIdentificacion:
                  this.sessionData.dataProducto.numeroDocumento,
                PrimerApellido:
                  this.sessionData.sesion.consultaClientePN.primerApellido,
                TipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
                TipoPersona:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.TipoPersona,
                TipoSolicitante:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.TipoSolicitante,
                FlagFraudeCliente:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.FlagFraudeCliente,
                FechaNacimiento:
                  this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI,
                Declarado: {
                  // asignado segun logica
                  IngresosEmpleado,
                  IngresosIndependiente,
                  IngresosPensionado,
                },
                Analitica: {
                  Ingreso:
                    this.sessionData.sesion.consultaClientePN
                      .valIngresoEspecialistaCLI,
                },
                ActividadLaboral: {
                  ActividadLaboral: reqPayload.actividadLaboral.codigo,
                  FlagPrincipal:
                    this.parmsData.consumoEvaluador.service.Request
                      .DVSolicitante.Solicitante.ActividadLaboral.FlagPrincipal,
                  TipoContrato: this.sessionData.sesion.consultaClientePN
                    .tipoContratoAL
                    ? this.sessionData.sesion.consultaClientePN.tipoContratoAL
                    : '0', // check
                  FlagFraudeEmpresa:
                    this.parmsData.consumoEvaluador.service.Request
                      .DVSolicitante.Solicitante.FlagFraudeEmpresa,
                },
              },
            },
            DVProductos: {
              Producto: {
                CodIdProducto:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.CodIdProducto,
                Tipo: this.parmsData.consumoEvaluador.service.Request
                  .DVProductos.Producto.Tipo,
                Amortizacion:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Amortizacion,
                Moneda:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Moneda,
                TipoTasa:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.TipoTasa,
                PlazoSolicitado:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.PlazoSolicitado,
                MontoSolicitado:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.MontoSolicitado,

                Catalogo: {
                  PlazoMinimo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.PlazoMinimo,
                  PlazoMaximo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.PlazoMaximo,
                  MontoMinimo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.MontoMinimo,
                  MontoMaximo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.MontoMaximo,
                },
                Familia:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Familia,
                N1: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N1,
                N2: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N2,
                N3: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N3,
                N4: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N4,
                N5: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N5,
              },
            },
          },
        },
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          canalId: this.sessionData.dataProducto.canalId,
          id: this.parmsData.consumoEvaluador.operation.id,
          ip: this.sessionData.sesion.ip,
          moduleId: this.parmsData.consumoEvaluador.operation.moduleId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.parmsData.consumoEvaluador.operation.client.userId,
          },
        },
      },
    }
    this.logger.debug(
      `${STEP}:Consumo Evaluador - request: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    try {
      consumoEvaluadorRest = this.parmsData.mockingData.consumoEvaluador
        ? reqPayload.ingresosMensuales > 5000000
          ? consumoResponseB
          : consumoResponseM
        : await axios.post(endpointUrl, payload)
      // consumoEvaluadorRest = await axios.post(endpointUrl, payload)
      // consumoEvaluadorRest = reqPayload.ingresosMensuales > 5000000 ? consumoResponseB: consumoResponseM
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    /*
    if (
      consumoEvaluadorRest.data.codError || consumoEvaluadorRest.data.messageError.statusCode === 500
    ) {
      {
        throw new ServiceError(
          MBAAS_ERRORS.internal_server_error,
          new Error(JSON.stringify(consumoEvaluadorRest.data.errors))
        )
      }
    } */

    const consumoEvaluadorSalida =
      consumoEvaluadorRest.data.payload.service.Response.DataHeader
        .caracterAceptacion === 'M'
        ? {
            CaracterAceptacion:
              consumoEvaluadorRest.data.payload.service.Response.DataHeader
                .caracterAceptacion,
          }
        : {
            CaracterAceptacion:
              consumoEvaluadorRest.data.payload.service.Response.DataHeader
                .caracterAceptacion,
            DecisionCategory:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.DecisionSolicitud.DecisionCategory,
            ValorAprobado:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.DecisionSolicitud.DecisionCategory === 'APR'
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].Aprobacion
                    .MontoAprobado
                : 0,
            ValorCobroSeguroVida:
              this.parmsData.consumoEvaluador.valorCobroSeguroVida,
            CodigoCausalDecisionSolicitud:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.Producto[0].PoliticasProd.SortedReasonCodeTable.I1,
            CausalDecisionSolicitud: {
              causalDecisionSolicitud1:
                consumoEvaluadorRest.data.payload.service.Response
                  .WorkingStorage.PNOutputPCO.DecisionSolicitud
                  .DecisionCategory === 'NEG'
                  ? consumoEvaluadorRest.data.payload.service.Response
                      .WorkingStorage.PNOutputPCO.DecisionSolicitud
                      .SortedReasonCodeTable.I1
                  : '',
              causalDecisionSolicitud2: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I2
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I2
                : '',
              causalDecisionSolicitud3: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I3
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I3
                : '',
              causalDecisionSolicitud4: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I4
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I4
                : '',
              causalDecisionSolicitud5: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I5
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I5
                : '',
            },
          }
    // tally
    this.logger.debug(
      `${STEP}:Consumo Evaluador - Response: ${JSON.stringify(
        consumoEvaluadorSalida
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: consumoEvaluadorSalida,
    }
  }

  private grabarInformacionSolicitudes = async () => {
    this.logger.debug(
      'grabarInformacionSolicitudes',
      this.sessionData.sesion.clientId
    )
    let resultGrabarRest: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/grabar`

    // prueba modelo GrabarInformacionSolicitudesModel
    const payload = new GrabarInformacionSolicitudesModel()
    await payload.setObject(this.sessionData, this.parmsData)
    await payload.getObject()
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - request: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGrabarRest = await axios.post(endpointUrl, payload.getObject())
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGrabarRest.data.errors &&
      resultGrabarRest.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGrabarRest.data.errors))
      )
    }

    const grabarRes = resultGrabarRest.data
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - Response: ${JSON.stringify(
        grabarRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: grabarRes,
    }
  }

  private ConsultarTasasYSimuladorPrimeraCuota = async () => {
    this.logger.debug(
      'ConsultarTasasYSimuladorPrimeraCuota',
      this.sessionData.sesion.clientId
    )

    let resulConsultarTasasYSimulador: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/consultaTasas`

    const payload = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              total: this.sessionData.sesion.total,
              canal: this.sessionData.dataProducto.canalId,
            },
            Data: {
              aplicacionOrigen: this.sessionData.dataProducto.canalId,
              ipOrigen: this.sessionData.sesion.ip,
              numeroSolicitudSiebel:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              lineaCreditoSiebel:
                this.parmsData.consultarTasas.lineaCreditoSiebel,
              destinoCreditoSiebel:
                this.parmsData.consultarTasas.destinoCreditoSiebel,
              tipoCreditoSiebel:
                this.parmsData.consultarTasas.tipoCreditoSiebel,
              productoSiebel: this.parmsData.consultarTasas.productoSiebel,
              tipoGarantiaSiebel:
                this.parmsData.consultarTasas.tipoGarantiaSiebel,
              estadoGarantiaHipotecarioSiebel:
                this.parmsData.consultarTasas.estadoGarantiaHipotecarioSiebel,
              usoGarantiaSiebel:
                this.parmsData.consultarTasas.usoGarantiaSiebel,
              rangoColocacionSiebel:
                this.parmsData.consultarTasas.rangoColocacionSiebel,
              valorSolicitado: this.parmsData.consultarTasas.valorSolicitado, // TODO: PENDIENTE DE DEFINICION
              plazo: this.parmsData.consultarTasas.plazo,
              moneda: this.parmsData.moneda,
              tipoTasaSiebel: this.parmsData.consultarTasas.tipoTasaSiebel,
              canalVentas: this.parmsData.consultarTasas.canalVentas,
              actividadLaboral:
                this.sessionData.sesion.datosFormulario.actividadLaboral.codigo,
              edadDeudor1: UTILITIES.obtenerEdad(
                this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI
              ),
              generoSol1: this.sessionData.sesion.consultaClientePN.sexoCLI,
              indSeguroDesempleoDeudor1:
                this.parmsData.consultarTasas.indSeguroDesempleoDeudor1,
              indicadorFinancia4xMilCheque:
                this.parmsData.consultarTasas.indicadorFinancia4xMilCheque,
              indicadorFinanciaCola4xMilLibranza:
                this.parmsData.consultarTasas
                  .indicadorFinanciaCola4xMilLibranza,
              indCobroSeguroGarantia:
                this.parmsData.consultarTasas.indCobroSeguroGarantia,
              acierta: this.parmsData.consultarTasas.acierta,
              scorePrecioCliente:
                this.parmsData.consultarTasas.scorePrecioCliente,
              codigoPromocion: this.parmsData.consultarTasas.codigoPromocion,
            },
          },
        },
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          canalId: this.sessionData.dataProducto.canalId,
          id: this.sessionData.sesion.clientId,
          ip: this.sessionData.sesion.ip,
          moduleId: this.sessionData.dataProducto.moduloId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          logger: this.parmsData.logger,
        },
      },
    }

    this.logger.debug(
      `${STEP}:ConsultarTasasYSimuladorPrimeraCuota - Request: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )

    try {
      resulConsultarTasasYSimulador = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resulConsultarTasasYSimulador.data.errors &&
      resulConsultarTasasYSimulador.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resulConsultarTasasYSimulador.data.errors))
      )
    }

    const tasasYSimuladorRes = resulConsultarTasasYSimulador.data.Response
    this.logger.debug(
      `${STEP}:ConsultarTasasYSimuladorPrimeraCuota - Response: ${JSON.stringify(
        tasasYSimuladorRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return tasasYSimuladorRes
  }
}
