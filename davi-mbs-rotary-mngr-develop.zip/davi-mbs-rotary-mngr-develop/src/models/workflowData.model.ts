//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { OtpServiceData } from '@models/servicios/otpServiceModel.model'
import { BiometriaData } from '@models/sesion/biometria/biometria.model'
import { DocumentoData } from '@models/sesion/documento/documento.model'
import { FlujoData } from '@models/sesion/flujo/flujo.model'
import { OtpData } from '@models/sesion/otp/otp.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { ProductoData } from '@models/sesion/producto/producto.model'
import { SesionData } from '@models/sesion/sesion.model'
import { RetomaParcial } from './sesion/retomaParcial.model'

export class WorkflowData {
  /*
   * Atributos
   */
  public documento: DocumentoData
  public dataProducto: ProductoData
  public otp: OtpData
  public flujo: FlujoData
  public retomaParcial: RetomaParcial
  public retomaService?: any
  public sesion: SesionData
  public sesionRetoma: SesionData
  public biometria: BiometriaData
  public otpServiceData: OtpServiceData

  /*
   * Metodo constructor (inicialización) de la clase WorkflowData
   */
  constructor(presentacionCliente: IPresentacionClientes) {
    this.documento = new DocumentoData('', '')
    this.otpServiceData = new OtpServiceData(0, '', '', '', '', '', '')
    this.otp = new OtpData('', 0, '', false, '', false)
    this.flujo = new FlujoData(
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      ''
    )
    this.retomaParcial = new RetomaParcial(false, '')
    this.sesion = new SesionData(presentacionCliente, '', '', '', false, '', '')
    this.sesionRetoma = new SesionData(
      presentacionCliente,
      '',
      '',
      '',
      false,
      '',
      ''
    )
    ;(this.dataProducto = new ProductoData(
      '',
      '',
      '',
      '',
      0,
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      '',
      ''
    )),
      (this.biometria = new BiometriaData(
        false,
        false,
        '',
        '',
        '',
        '',
        '',
        '',
        '',
        false
      ))
  }
}
