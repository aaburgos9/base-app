//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { JWK } from 'node-jose'

export interface IKey {
  exp: number
  jwk: JWK.Key
}
