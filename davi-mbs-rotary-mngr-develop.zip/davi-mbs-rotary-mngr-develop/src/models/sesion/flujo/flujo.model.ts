//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { boolean } from 'joi'

export class FlujoData {
  /*
   * Atributos
   */
  public stepATRN0010: boolean = false
  public stepBYC0000: boolean = false
  public stepBYC0010: boolean = false
  public stepBYC0020: boolean = false
  public stepDAT0010: boolean = false
  public stepFELI0010: boolean = false
  public stepINFO0010: boolean = false
  public stepVIN0010: boolean = false
  public clienteEnRetoma: boolean = false
  public fechaRetoma: any = ''

  /*
   * Metodo constructor (inicialización) de la clase FlujoData
   */
  constructor(
    stepATRN0010: boolean,
    stepBYC0000: boolean,
    stepBYC0010: boolean,
    stepBYC0020: boolean,
    stepDAT0010: boolean,
    stepFELI0010: boolean,
    stepINFO0010: boolean,
    stepVIN0010: boolean,
    clienteEnRetoma: boolean,
    fechaRetoma: string
  ) {
    this.stepATRN0010 = stepATRN0010
    this.stepBYC0000 = stepBYC0000
    this.stepBYC0010 = stepBYC0010
    this.stepBYC0020 = stepBYC0020
    this.stepDAT0010 = stepDAT0010
    this.stepFELI0010 = stepFELI0010
    this.stepINFO0010 = stepINFO0010
    this.stepVIN0010 = stepVIN0010
    this.clienteEnRetoma = clienteEnRetoma
    this.fechaRetoma = fechaRetoma
  }
}
