//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum MBAAS_ERRORS {
  invalid_data_format,
  internal_server_error,
  invalid_client_id,
  data_not_found,
}

const ERRORS: { [index: string]: any } = {
  [MBAAS_ERRORS.internal_server_error]: {
    message: 'internal_server_error',
    statusCode: 500,
  },
  [MBAAS_ERRORS.invalid_client_id]: {
    message: 'invalid_client_id',
    statusCode: 404,
  },
  [MBAAS_ERRORS.invalid_data_format]: {
    message: 'invalid_data_format',
    statusCode: 422,
  },
  [MBAAS_ERRORS.data_not_found]: {
    message: 'data_not_found',
    statusCode: 404,
  },
}

export class ServiceError extends Error {
  /*
   * Atributos
   */
  public statusCode: number
  public internalError: any
  public code: MBAAS_ERRORS

  /*
   * Metodo constructor (inicialización) de la clase ServiceError
   */
  constructor(errorType: MBAAS_ERRORS, error?: Error) {
    super(ERRORS[errorType].message)

    this.statusCode = ERRORS[errorType].statusCode
    this.internalError = error ? error : null
    this.code = errorType

    // Set the prototype explicitly.
    Object.setPrototypeOf(this, ServiceError.prototype)
  }
}
