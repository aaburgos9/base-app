//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum STEP_ID {
  /**
   * MBaaS Boot
   */
  BYC0000 = 'BYC0000',

  /**
   * Pantalla:
   *
   * Autorizaciones
   */
  BYC0010 = 'BYC0010',

  /**
   * Pantalla:
   *
   * Autorizaciones
   */

  AUT0010 = 'AUT0010',
  INFO0010 = 'INFO0010',
  FELI0010 = 'FELI0010',
  VIN0010 = 'VIN0010',
  DAT0010 = 'DAT0010',
  OTP0010 = 'OTP0010',
  PROD0010 = 'PROD0010',
  RESULT0010 = 'RESULT0010',
  rotativo020 = 'rotativo020',
  rotativo00001 = 'rotativo00001',
  PENDIENTE = 'PENDIENTE',
}
