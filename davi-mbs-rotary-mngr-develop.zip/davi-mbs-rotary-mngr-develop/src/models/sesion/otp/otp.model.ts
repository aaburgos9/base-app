//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class OtpData {
  /*
   * Atributos
   */

  public numero: string = ''
  public intentos: number = 0
  public otp: string = ''
  public esValido: boolean = false // TODO: PENDIENTE ACLARACION POR PARTE DEL BANCO
  public idSesion: string = ''
  public conIntentos: boolean = false

  /*
   * Metodo constructor (inicialización) de la clase OtpData
   */
  constructor(
    numero: string,
    intentos: number,
    otp: string,
    esValido: boolean,
    idSesion: string,
    conIntentos: boolean
  ) {
    this.numero = numero
    this.intentos = intentos
    this.otp = otp
    this.esValido = esValido
    this.idSesion = idSesion
    this.conIntentos = conIntentos
  }
}
