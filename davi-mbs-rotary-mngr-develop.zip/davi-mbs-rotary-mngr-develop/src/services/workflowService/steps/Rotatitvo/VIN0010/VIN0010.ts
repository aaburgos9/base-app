//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi from 'joi'
import { GrabarInformacionSolicitudesModel } from '~/models/servicios/grabarInformacionSolicitudes'

const STEP: string = 'VIN0010'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    // tslint:disable: object-literal-sort-keys
    atras: joi.boolean().required(),
    numeroCuentaVincular: joi.string().optional().allow(''),
    tipoCuentaVincular: joi.string().optional().allow(''),
  })
  .optional()

export class VIN0010 extends Step {
  private parmsData: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de obtención de parametros del step (VIN0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.VIN0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()

    if (reqPayload.atras === true) {
      // Flujo: Regresar pantalla de resultado evaluación
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,
          lenguaje: this.sessionData.dataProducto.codIdioma,
          message: '',
          modulo: this.parmsData.kind,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          valorAprobado: this.sessionData.sesion.evaluadorPCO.valorAprobado,
          valorCobroSeguroVida:
            this.sessionData.sesion.evaluadorPCO.valorCobroSeguroVida,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.FELI0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > INFO0010 - Flujo Atras hacia FELI0010`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }
    this.sessionData.sesion.cuentaRotativo.numeroCuentaConfirmada =
      reqPayload.numeroCuentaVincular
    if (reqPayload.tipoCuentaVincular === this.parmsData.cuentaAhorros.nombre) {
      this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmada =
        this.parmsData.cuentaAhorros.codigo
      this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmadaNombre =
        this.parmsData.cuentaAhorros.nombre
    }
    if (
      reqPayload.tipoCuentaVincular === this.parmsData.cuentaCorriente.nombre
    ) {
      this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmada =
        this.parmsData.cuentaCorriente.codigo
      this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmadaNombre =
        this.parmsData.cuentaCorriente.nombre
    }
    /// GrabarInformacionSolicitudes
    try {
      const resultGrabarInfo = await this.grabarInformacionSolicitudes()

      this.logger.debug(
        `${STEP}:getNextStep - Cuenta seleccionada - grabarInformacionSolicitudes ${JSON.stringify(
          resultGrabarInfo
        )}`,
        this.sessionData.sesion.clientId
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        numeroCuentaConfirmada: reqPayload.numeroCuentaVincular,
        tipoCuentaConfirmada: reqPayload.tipoCuentaVincular,
        valorConfirmando: this.sessionData.sesion.datosFormulario.valorAceptado,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.DAT0010,
    }
    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > VIN0010 - Flujo Exitoso`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }
  private grabarInformacionSolicitudes = async () => {
    this.logger.debug(
      'grabarInformacionSolicitudes',
      this.sessionData.sesion.clientId
    )

    let resultGrabarRest: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/grabar`

    // prueba modelo GrabarInformacionSolicitudesModel
    const payload = new GrabarInformacionSolicitudesModel()
    await payload.setObject(this.sessionData, this.parmsData)
    await payload.getObject()
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - request: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGrabarRest = await axios.post(endpointUrl, payload.getObject())
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGrabarRest.data.errors &&
      resultGrabarRest.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGrabarRest.data.errors))
      )
    }

    const grabarRes = resultGrabarRest.data
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - Response: ${JSON.stringify(
        grabarRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: grabarRes,
    }
  }
}
