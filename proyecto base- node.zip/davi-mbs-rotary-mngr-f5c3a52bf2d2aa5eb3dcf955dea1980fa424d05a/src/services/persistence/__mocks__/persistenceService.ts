//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class PersistenceService {
  public getData = jest.fn((kind: string, key: string) => Promise.resolve({}))
  public setData = jest.fn((kind: string, key: string, data: any) => Promise.resolve(true))
}
