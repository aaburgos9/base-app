//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IPresentacionClientes } from '../../../models/sesion/presentacionClientes.model'

export class PresentacionService {
  public crear = jest.fn((presentacion: IPresentacionClientes) => {
    return Promise.resolve({})
  })
}
