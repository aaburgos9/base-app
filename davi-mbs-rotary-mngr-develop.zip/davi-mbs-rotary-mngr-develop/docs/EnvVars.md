# Variables de entorno del microservicio

Estas son las variables de entorno que se pueden configurar para este microservicio:

Requeridas:

- **NODE_ENV**: Ambiente en el cual está corriendo el servicio. Requerido. Valores posibles: development, testing, production
- **ROOT_PATH**: Prefijo de las rutas de este microservicio. Requerido. Ejemplo: /pgprntngw/v1
- **PERSISTENCE_SERVICE_URL**: URL del microservicio de persistencia. Ejemplo: 'http://persistence-service/persistence/v1'.
- **AUTH_SERVICE_URL**: URL del microservicio de autenticacion . Ejemplo: 'http://auth-service/auth/v1'.
- **PARMS_SERVICE_URL**: URL del microservicio de Catalogo para el uso de parametros de workflow . Ejemplo: 'http://catalogo-service/catalogo/v1'.
- **GENERADOR_FILE_SERVICE_URL**: URL del microservicio de generador file . Ejemplo: 'http://generador-file-service/generatorFileService/v1'.
- **AUTORIZACION_BEARER**: Bearer del Token para servicios.
- **CLIENT_ID_TOKEN**: ID de cliente del Token para servicios.
- **CLIENT_SECRET_TOKEN**: Secreto de cliente del Token para servicios.
- **GENERATE_TYPE_TOKEN**: Tipo de generacion del Token para servicios.
- **GRANT_TYPE_TOKEN**: Tipo de grant del Token para servicios.
- **ROTATIVO_FRONT_URL**: URL base del app web de frontend de producto  rotativo. Ejemplo: 'https://microapp.desa.co.daviplata.com/rotativo/index.html#/checkout?paymentlink=1234&idSesion=8907' o 'https://microapp.desa.co.daviplata.com/rotativo/index.html#/checkout?paymentlink=1234'


Opcionales:

- **PORT**: Puerto HTTP que utiliza el servidor para exponer los endpoints REST. Predeterminado: 8080.
- **LOGGER_LEVEL**: Nivel de detalle a mostrar en logs. Valores posibles: error, warn, info, verbose, debug, silly. Predeterminado: info
