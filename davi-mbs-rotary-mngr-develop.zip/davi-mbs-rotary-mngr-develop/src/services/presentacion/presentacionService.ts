//
// Copyright (C) 2022 - Banco Davivienda S.A. y sus filiales.
//

import { provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { KIND } from '@models/enums/kind.enum'
import {
  PAIS,
  PRODUCTO,
  PRODUCTO_PAIS_CANAL,
} from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { TipoSesion } from '@models/sesion/sesion.model'
import { WorkflowData } from '@models/workflowData.model'
import { IAuthService } from '@services/auth'
import { ICryptoService } from '@services/crypto'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence/'
import {
  INuevaSesion,
  IPresentacionRequest,
  presentacionRequestSchema,
} from '@services/presentacion/presentacion.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { inject } from 'inversify'
import joi from 'joi'
import { IPresentacionService } from '.'

@provide(TYPES.IPresentacionService)
export class PresentacionService implements IPresentacionService {
  constructor(
    @inject(TYPES.IConfig) private config: IConfig,
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IPersistenceService) private persistence: IPersistenceService,
    @inject(TYPES.IAuthService) private auth: IAuthService,
    @inject(TYPES.ICrypto) private crypto: ICryptoService
  ) { }

  public crear = async (presentacionEncriptada: IPresentacionRequest) => {
    this.logger.debug(
      `Presentacion: PROCESOPRODUCTO-TRANSFERENCIA > Inicio - presentacion data: ${presentacionEncriptada.data}`
    )

    // desencriptar parametro y extraer datos de presentacion de cliente
    let presentacion
    try {
      presentacion = await this.crypto.decryptJwe(presentacionEncriptada.data)
    } catch (error) {
      this.logger.debug(error)
      throw new ServiceError(MBAAS_ERRORS.invalid_data_format, error)
    }
    // tslint:disable-next-line: no-console
    this.logger.debug(`Payload cifrado ${presentacion}`)
    // Validar formato de payload desencriptado
    const validationResult = joi.validate(
      presentacion,
      presentacionRequestSchema
    )
    if (validationResult.error) {
      throw new ServiceError(
        MBAAS_ERRORS.invalid_data_format,
        new Error(validationResult.error.message)
      )
    }

    // Validar producto y país
    let producto = `${presentacion.module.id}_${presentacion.module.country}`
    if (
      !(
        presentacion.module.id in PRODUCTO &&
        presentacion.module.country in PAIS &&
        producto in PRODUCTO_PAIS_CANAL
      )
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.invalid_data_format,
        // tslint:disable-next-line: prefer-template
        new Error('Combinacion Producto, Pais  y Canal invalidos')
      )
    }

    // Crear datos de sesión
    const wfData = new WorkflowData(presentacion)
    wfData.sesion.workflow.pasoActual = STEP_ID.BYC0010
    wfData.sesion.tipo = TipoSesion.PRODUCTO
    wfData.dataProducto.userId = presentacion.client.userId
    wfData.dataProducto.sesionIdCanal =
      presentacion.consumer.appConsumer.sessionId
    wfData.dataProducto.canalId = presentacion.consumer.appConsumer.canalId
    wfData.dataProducto.appConsumerId = presentacion.consumer.appConsumer.id
    wfData.dataProducto.transactionId =
      presentacion.consumer.appConsumer.transactionId
    wfData.dataProducto.terminalId =
      presentacion.consumer.appConsumer.terminalId
    wfData.dataProducto.deviceConsumerId =
      presentacion.consumer.deviceConsumer.id
    wfData.dataProducto.inactiveInterval =
      presentacion.consumer.deviceConsumer.inactiveInterval
    wfData.dataProducto.userAgent =
      presentacion.consumer.deviceConsumer.userAgent
    wfData.dataProducto.moduloId = presentacion.module.id
    wfData.dataProducto.country = presentacion.module.country
    wfData.dataProducto.tipoDocumento = presentacion.client.documentClient.type
    wfData.dataProducto.numeroDocumento =
      presentacion.client.documentClient.number
    wfData.dataProducto.email = presentacion.client.email
    wfData.dataProducto.nombreCompleto = presentacion.client.name
    wfData.dataProducto.tokenFrontend =
      presentacion.consumer.genericData?.dataItem.find(
        (element: any) => element.key === 'tokenFrontend'
      )?.value

    this.logger.debug(
      `Presentacion: PROCESOPRODUCTO-TRANSFERENCIA > Inicio - clientId generado: ${wfData.sesion.clientId}`
    )
    this.logger.debug(
      `Presentacion: PROCESOPRODUCTO-TRANSFERENCIA > wfData: ${JSON.stringify(
        wfData
      )}`
    )

    // Persistir datos de la solicitud
    try {
      await this.persistence.setData(
        KIND.ROTATIVO,
        wfData.sesion.clientId,
        wfData
      )
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    const documentNumber = wfData.dataProducto.numeroDocumento
    const documentType = wfData.dataProducto.tipoDocumento
    const canal = wfData.dataProducto.canalId

    // Generar OTP para la sesión
    let otpAux = ''
    try {
      producto = `${producto}_${presentacion.consumer.appConsumer.canalId}`
      otpAux = await this.auth.createOtp(wfData.sesion.clientId, producto)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    // determinar URL del producto a lanzar
    const appUrlAux: string = `${this.config.getVars().front.url}/${otpAux}`
    const respuesta: INuevaSesion = {
      appUrl: appUrlAux,
      clientId: wfData.sesion.clientId,
      otp: otpAux,
    }

    return respuesta
  }
}
