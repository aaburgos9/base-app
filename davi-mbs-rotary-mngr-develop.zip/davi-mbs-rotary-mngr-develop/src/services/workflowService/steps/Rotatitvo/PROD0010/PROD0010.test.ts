//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { PRODUCTO } from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { PROD0010 } from '@services/workflowService/steps/Rotatitvo/PROD0010/PROD0010'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'

import axios from 'axios'

const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        credito2NegocioService: 'http://localhost:5050/api/v1',
        gestionDocumentosService: 'http://localhost:5081/api',
        parmsServiceUrl: 'http://catalogo/v1',
        soapWebService: 'http://localhost:6044/v1',
      },
    }
  }
}

const stepDataFalse: IStepData = {
  clientId: 'abc123',
  payload: {
    crearProducto: false,
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.PROD0010,
}

const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    crearProducto: true,
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.PROD0010,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const valParmsResponse = {
  data: {
    data: {
      agenteVendedor: 405070,
      codMoneda: 'COP',
      crearPagare: {
        caracterAceptacionSvc: 'B',
        codigoDepositante: '51',
        documentoPagareServiceTipo: {
          creditoReembolsableEn: '2',
          idClaseDefinicionDocumento: '10283',
          idDocumentoPagare: '10283',
          nitEmisor: '8600343137',
          otorganteNumId: '1019141191',
          otorganteTipoId: '01',
          tipoPagare: '2',
          valorPesosDesembolso: '0',
        },
        infoCertificadoFirmaTipo: {
          clave: '42663136',
          idRolFirmante: '5',
          numeroDocumento: '1019141191',
          tipoDocumento: '01',
        },
        listaCrearGirador: {
          fkIdClasePersona: '1',
          fkIdTipoDocumento: '01',
          giradorNaturalTipo: {
            fkIdCiudadDomicilio_Nat: '73001',
            fkIdCiudadExpedicion_Nat: '73001',
            fkIdDepartamentoDomicilio_Nat: '73',
            fkIdDepartamentoExpedicion_Nat: '73',
            fkIdPaisDomicilio_Nat: '169',
          },
          identificacionEmisor: '8600343137',
        },
        oTPProcedimiento: '0',
        terminal: {
          codUsuario: '86003431371',
          valPerfil: '0',
        },
      },
      crearSolicitudes: {
        AdquiereSeguroDesempleo1erSol: 'N',
        CodPais: 'CO',
        agenteVendedor: 405070,
        bancoCuentaADebitar: '51',
        calificacionOriginacion: '0',
        canalVentaCredito: 'APP',
        caracterAceptacionSvc: 'B',
        ciudadDiligenciamiento: 16911001,
        codigoOficinaRadicacion: '4789',
        companiaDeSegurosVar1180: '998',
        companiaDeSegurosVar41: '998',
        cuotaConSeguroSinCobertura: 269000,
        cuotaSinSeguroSinCobertura: 250000,
        destinoCreditoSiebel: '7',
        diaDeCorte: 2,
        estGarantiaHipotecario: 'NA',
        indEmplDav1erSol: 'N',
        lineaCreditoSiebel: 'CREDIEXPRESS ROTATIV',
        moneda: '2',
        naturalezaJuridica1erSol: 'N',
        numeroCuentaDebitoAutomatico: '',
        numeroSolicitantes: 1,
        oficinaEspecialParaSolicitudes: '4789',
        planVehiculo: '0',
        plazoCreditoEnPeriodos: 60,
        productoSiebel: 0,
        rangoColocacionSiebel: '0',
        realizoListasRestrictivas: 'S',
        scorePrecioCliente: '0',
        segmentoClienteSiebel: '1',
        sucursalCredito: '0',
        tasaTipoSiebel: '1',
        tipoCreditoSiebel: '40',
        tipoCuenta: '',
        tipoGarantiaSiebel: '0',
        usoFuturoNum2: '1',
        usoGarantiaSiebel: '99',
        valorSolicitado: '',
        valorTasaEA: 2578,
        valorTasaInteresSinCobertura: 2578,
      },
      factorSeguroVida: 1188.33,
      generarPaqueteDocumental: {
        aliado: '37 - SUPERAPP DAVIVIVENDA',
        autoriza_asegurabilidad: 'Radio_2.jpg',
        autoriza_condiciones: 'Radio_2.jpg',
        autoriza_pagare: 'Radio_2.jpg',
        autoriza_solicitud: 'Radio_2.jpg',
        canal: '37 - SUPERAPP DAVIVIVENDA',
        caracterAceptacionSvc: 'B',
        codUsuario: '86003431371',
        cual: '',
        enviarCopiaCorreo: false,
        genero_f: 'Radio_2.jpg',
        genero_m: 'Radio_2.jpg',
        idAplicacion: 'MBAAS',
        idService: 'SrvScnGeneracionPaqueteDocumentos',
        keyService: 'ehV124',
        logger: 'v1',
        metodo_firma: 'OTP',
        paqueteDocId: 'CREDITO_ROTATIVO_MOVIL_V1',
        requiereClave: false,
        tipo_producto: 'CREDITO ROTATIVO',
        urlServiceOption: '1',
        valParametro: [
          'nombres',
          'primer_apellido',
          'segundo_apellido',
          'tipo_id',
          'num_id',
          'Canal',
          'ip',
          'fecha',
          'hora',
          'autoriza_pagare',
          'autoriza_asegurabilidad',
          'autoriza_asegurabilidad',
          'autoriza_condiciones',
          'autoriza_solicitud',
          'id_solicitud',
          'metodo_firma',
          'ciudad',
          'tipo_producto',
          'cupo',
          'oficina',
          'cuenta_debito',
          'cual',
          'fecha_expedicion_id',
          'ciudad_expedicion_id',
          'genero_m',
          'genero_f',
          'ciudad_nacimiento',
          'fecha_nacimiento',
          'residencia_direccion',
          'residencia_ciudad',
          'residencia_departamento',
          'celular',
          'correo',
          'actividad_laboral',
          'contrato',
          'actividad_economica',
          'ingresos',
          'canal',
        ],
      },
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        estadoAprobado: '2',
        estadoNegado: '5',
        estadoNoUtilizado: '3',
        estadoPendiente: '1',
        indicadorConSeguro: '1',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '1',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      kind: 'ROTATIVO',
      loggerVersion: 'v1',
      sessionTimeout: '600000',
      valJornada: '0',
      valPerfil: '0',
    },
    status: 200,
  },
}

const valParmsResponseAux = {
  data: {
    data: {
      agenteVendedor: 405070,
      codMoneda: 'COP',
      crearPagare: {
        caracterAceptacionSvc: 'B',
        codigoDepositante: '51',
        documentoPagareServiceTipo: {
          creditoReembolsableEn: '2',
          idClaseDefinicionDocumento: '10283',
          idDocumentoPagare: '10283',
          nitEmisor: '8600343137',
          otorganteNumId: '1019141191',
          otorganteTipoId: '01',
          tipoPagare: '2',
          valorPesosDesembolso: '0',
        },
        infoCertificadoFirmaTipo: {
          clave: '42663136',
          idRolFirmante: '5',
          numeroDocumento: '1019141191',
          tipoDocumento: '01',
        },
        listaCrearGirador: {
          fkIdClasePersona: '1',
          fkIdTipoDocumento: '01',
          giradorNaturalTipo: {
            fkIdCiudadDomicilio_Nat: '73001',
            fkIdCiudadExpedicion_Nat: '73001',
            fkIdDepartamentoDomicilio_Nat: '73',
            fkIdDepartamentoExpedicion_Nat: '73',
            fkIdPaisDomicilio_Nat: '169',
          },
          identificacionEmisor: '8600343137',
        },
        oTPProcedimiento: '0',
        terminal: {
          codUsuario: '86003431371',
          valPerfil: '0',
        },
      },
      crearSolicitudes: {
        AdquiereSeguroDesempleo1erSol: 'N',
        CodPais: 'CO',
        agenteVendedor: 405070,
        bancoCuentaADebitar: '51',
        calificacionOriginacion: '0',
        canalVentaCredito: 'APP',
        caracterAceptacionSvc: 'B',
        ciudadDiligenciamiento: 16911001,
        codigoOficinaRadicacion: '4789',
        companiaDeSegurosVar1180: '998',
        companiaDeSegurosVar41: '998',
        cuotaConSeguroSinCobertura: 269000,
        cuotaSinSeguroSinCobertura: 250000,
        destinoCreditoSiebel: '7',
        diaDeCorte: 2,
        estGarantiaHipotecario: 'NA',
        indEmplDav1erSol: 'N',
        lineaCreditoSiebel: 'CREDIEXPRESS ROTATIV',
        moneda: '2',
        naturalezaJuridica1erSol: 'N',
        numeroCuentaDebitoAutomatico: '',
        numeroSolicitantes: 1,
        oficinaEspecialParaSolicitudes: '4789',
        planVehiculo: '0',
        plazoCreditoEnPeriodos: 60,
        productoSiebel: 0,
        rangoColocacionSiebel: '0',
        realizoListasRestrictivas: 'S',
        scorePrecioCliente: '0',
        segmentoClienteSiebel: '1',
        sucursalCredito: '0',
        tasaTipoSiebel: '1',
        tipoCreditoSiebel: '40',
        tipoCuenta: '',
        tipoGarantiaSiebel: '0',
        usoFuturoNum2: '1',
        usoGarantiaSiebel: '99',
        valorSolicitado: '',
        valorTasaEA: 2578,
        valorTasaInteresSinCobertura: 2578,
      },
      factorSeguroVida: 1188.33,
      generarPaqueteDocumental: {
        aliado: '37 - SUPERAPP DAVIVIVENDA',
        autoriza_asegurabilidad: 'Radio_2.jpg',
        autoriza_condiciones: 'Radio_2.jpg',
        autoriza_pagare: 'Radio_2.jpg',
        autoriza_solicitud: 'Radio_2.jpg',
        canal: '37 - SUPERAPP DAVIVIVENDA',
        caracterAceptacionSvc: 'B',
        codUsuario: '86003431371',
        cual: '',
        enviarCopiaCorreo: false,
        genero_f: 'Radio_2.jpg',
        genero_m: 'Radio_2.jpg',
        idAplicacion: 'MBAAS',
        idService: 'SrvScnGeneracionPaqueteDocumentos',
        keyService: 'ehV124',
        logger: 'v1',
        metodo_firma: 'OTP',
        paqueteDocId: 'CREDITO_ROTATIVO_MOVIL_V1',
        requiereClave: true,
        tipo_producto: 'CREDITO ROTATIVO',
        urlServiceOption: '1',
        valParametro: [
          'nombres',
          'primer_apellido',
          'segundo_apellido',
          'tipo_id',
          'num_id',
          'Canal',
          'ip',
          'fecha',
          'hora',
          'autoriza_pagare',
          'autoriza_asegurabilidad',
          'autoriza_asegurabilidad',
          'autoriza_condiciones',
          'autoriza_solicitud',
          'id_solicitud',
          'metodo_firma',
          'ciudad',
          'tipo_producto',
          'cupo',
          'oficina',
          'cuenta_debito',
          'cual',
          'fecha_expedicion_id',
          'ciudad_expedicion_id',
          'genero_m',
          'genero_f',
          'ciudad_nacimiento',
          'fecha_nacimiento',
          'residencia_direccion',
          'residencia_ciudad',
          'residencia_departamento',
          'celular',
          'correo',
          'actividad_laboral',
          'contrato',
          'actividad_economica',
          'ingresos',
          'canal',
        ],
      },
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        estadoAprobado: '2',
        estadoNegado: '5',
        estadoNoUtilizado: '3',
        estadoPendiente: '1',
        indicadorConSeguro: '1',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '1',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      kind: 'ROTATIVO',
      loggerVersion: 'v1',
      sessionTimeout: '',
      valJornada: '0',
      valPerfil: '0',
    },
    status: 200,
  },
}

const mockGrabarInfoSolicitudesResponse = {
  data: {
    data: {
      Data: {
        nroSolicitud: 155249,
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: 0,
        idTransaccion: '2306141743',
        nombreOperacion: 'GrabacionInformacionSolicitudes',
        total: 370070,
        ultimoMensaje: 1,
      },
    },
  },
}

const crearPagareResponse = {
  data: {
    contextoRespuesta: {
      resultadoTransaccion: {
        fecOperacion: '2023-11-21T18:29:32.000Z',
        idTransaccion: '1700609372',
        valCaracterAceptacion: 'B',
        valNumeroAprobacion: '0',
      },
    },
    respuestaCrearGiradorDaneServiceTipo: {
      codigoError: 'SDL.SE.0000',
      descripcion: 'Todos los giradores se procesaron correctamente.',
      exitoso: true,
    },
    respuestaDocumentoPagareDaneServiceTipo: {
      codigoError: 'SDL.SE.0000',
      descripcion:
        'SDL.SE.0000: Exitoso. - Todos los pagare se crearon exitosamente.',
      exitoso: true,
      listaRespuesta: [
        {
          idDocumentoPagare: 3076731,
        },
      ],
    },
    respuestaFirmarPagaresTipo: {
      descripcion:
        'SDL.SE.0000: El proceso de firma de pagaré se encuentra en ejecución asíncrona.',
    },
  },
}

const crearPagareResponseFallido = {
  data: {
    contextoRespuesta: {
      resultadoTransaccion: {
        fecOperacion: '2023-11-21T18:29:32.000Z',
        idTransaccion: '1700609372',
        valCaracterAceptacion: 'M',
        valNumeroAprobacion: '0',
      },
    },
    respuestaCrearGiradorDaneServiceTipo: {
      codigoError: 'SDL.SE.0000',
      descripcion: 'Todos los giradores se procesaron correctamente.',
      exitoso: true,
    },
    respuestaDocumentoPagareDaneServiceTipo: {
      codigoError: 'SDL.SE.0000',
      descripcion:
        'SDL.SE.0000: Exitoso. - Todos los pagare se crearon exitosamente.',
      exitoso: true,
      listaRespuesta: [
        {
          idDocumentoPagare: 3076731,
        },
      ],
    },
    respuestaFirmarPagaresTipo: {
      descripcion:
        'SDL.SE.0000: El proceso de firma de pagaré se encuentra en ejecución asíncrona.',
    },
  },
}

const crearSolicitudesResponse = {
  data: {
    Response: {
      Data: {
        desembolsado: 'N',
        liquidado: 'S',
        numValorCuota: 0,
        numValorSeguroProtecionPagos: 0,
        numeroOfertaSiebel: '178592',
        numeroPrestamoFM: '06103692100045688',
        numeroScoringFM: 10044553,
        numeroSolicitudFM: 10074838,
        numeroSolicitudSiebel: '178592',
        scoringCerrado: 'S',
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: 0,
        nombreOperacion: 'crearSolicitudes',
        total: 37000,
        ultimoMensaje: 1,
      },
    },
  },
}

const crearSolicitudesResponseFallido = {
  data: {
    Response: {
      Data: {
        desembolsado: 'N',
        liquidado: 'S',
        numValorCuota: 0,
        numValorSeguroProtecionPagos: 0,
        numeroOfertaSiebel: '178592',
        numeroPrestamoFM: '06103692100045688',
        numeroScoringFM: 10044553,
        numeroSolicitudFM: 10074838,
        numeroSolicitudSiebel: '178592',
        scoringCerrado: 'S',
      },
      DataHeader: {
        caracterAceptacion: 'M',
        codMsgRespuesta: 0,
        nombreOperacion: 'crearSolicitudes',
        total: 37000,
        ultimoMensaje: 1,
      },
    },
  },
}

const generarPaqueteDocResponse = {
  data: {
    res: {
      contextoRespuesta: {
        resultadoTransaccion: {
          fecOperacion: '2023-11-21T20:05:28.000Z',
          idTransaccion: '1700615128',
          valCaracterAceptacion: 'B',
          valNumeroAprobacion: '0',
        },
      },
    },
  },
}

const generarPaqueteDocResponseFallido = {
  data: {
    res: {
      contextoRespuesta: {
        resultadoTransaccion: {
          fecOperacion: '2023-11-21T20:05:28.000Z',
          idTransaccion: '1700615128',
          valCaracterAceptacion: 'M',
          valNumeroAprobacion: '0',
        },
      },
    },
  },
}

const mockWfData = new WorkflowData(mockPresentacion)
const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)
const serviceUrls = {
  crearPagare: 'http://localhost:5081/api/crearPagareDigital',
  crearSolicitudes: 'http://localhost:5050/api/v1/crearSolicitud',
  generarPaqueteDocumental: 'http://localhost:6044/v1/soap-service',
  grabarInformacionSolicitudes: 'http://localhost:5050/api/v1/grabar',
  parametros: `http://catalogo/v1/parms/services.workflow.PROD0010?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO.CRRT}`,
}

let step: PROD0010
let nextStep: IStepData

describe('PROD0010', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para BYC0010
   *
   */

  test('Instancia correctamente del objeto PROD0010', () => {
    step = new PROD0010(stepData, mockWfData, config, logger)
    expect(step).toBeDefined()
  })

  test('Validación del objeto PROD0010 con payload correcto (no retorna mensaje de error)', () => {
    expect(step.isRequestValid()).toBeTruthy()
  })

  test('Validación del objeto PROD0010 con payload incorrecto (si retorna mensaje de error)', () => {
    const badStepData: IStepData = {
      clientId: 'abc123',
      payload: {
        bad: '',
      },
      stepId: STEP_ID.PROD0010,
    }
    const badStep = new PROD0010(badStepData, mockWfData, config, logger)
    expect(badStep.isRequestValid()).toBeFalsy()
    expect(badStep.getRequestValidationError().length).toBeGreaterThan(0)
  })

  /*
   *
   *  Verificacion del flujo para PROD0010
   *
   */
  test('Validación del getCurrentStep retorna valor del request', () => {
    expect(step.getCurrentStep()).toEqual(stepData.stepId)
  })

  test('PROD0010 => Presentación sin sessionTimeOut | crearProducto = false', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })
  test('PROD0010 => Presentación con sessionTimeOut | crearProducto = false', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('PROD0010 => Presentación sin sessionTimeOut | crearProducto = true', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(crearSolicitudesResponse)
      }
      if (url === serviceUrls.generarPaqueteDocumental) {
        return Promise.resolve(generarPaqueteDocResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      mockWfData.sesion.consultaClientePN.sexoCLI = 'F'
      mockWfData.sesion.datosFormulario.actividadLaboral.codigo = 'I'
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('PROD0010 => Presentación sin sessionTimeOut | crearProducto = true | resultCrearPagare caracterAceptacion M', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponseFallido)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('PROD0010 => Presentación sin sessionTimeOut | crearProducto = true | resultCrearSolicitudes caracterAceptacion M', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(crearSolicitudesResponseFallido)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      mockWfData.sesion.cuentaDebito.numeroCuentaDebitar = '1234567890'
      mockWfData.sesion.datosFormulario.codigoAsesor = '04'
      mockWfData.sesion.cuentaDebito.tipoCuentaDebitar = '01'
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('PROD0010 => Presentación sin sessionTimeOut | crearProducto = true | resultGenerarPaqueteDoc caracterAceptacion M', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(crearSolicitudesResponse)
      }
      if (url === serviceUrls.generarPaqueteDocumental) {
        return Promise.resolve(generarPaqueteDocResponseFallido)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      mockWfData.dataProducto.tipoDocumento = '01'
      mockWfData.dataProducto.canalId = '37'
      mockWfData.sesion.autorizacionDebitoAuto = true
      mockWfData.sesion.consultaClientePN.sexoCLI = 'M'
      mockWfData.sesion.datosFormulario.actividadLaboral.codigo = 'E'
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  /*
   *
   *  Verificación de errores al llamar servicios
   *
   */

  test('PROD0010 => Cliente con error al consultar parametros -> Error 500 | CRRT', async (done) => {
    const valParmsResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consultar parametros -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error al consumir grabarInformacionSolicitudes -> Error 500 | CRRT', async (done) => {
    const valGrabarInfoResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(valGrabarInfoResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consumir grabarInformacionSolicitudes -> Error 500 |  ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepDataFalse, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error al consumir crearPagare -> Error 500 | CRRT', async (done) => {
    const valCrearPagareResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(valCrearPagareResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consumir crearPagare -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error al consumir grabarInformacionSolicitudes dentro del consumo de crearPagare -> Error 500 | CRRT', async (done) => {
    const valGrabarInfoResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(valGrabarInfoResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consumir grabarInformacionSolicitudes dentro del consumo de crearPagare -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error al consumir crearSolicitudes -> Error 500 | CRRT', async (done) => {
    const valCrearSolicitudesResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(valCrearSolicitudesResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consumir crearSolicitudes -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error al consumir generarPaqueteDocumental -> Error 500 | CRRT', async (done) => {
    const valgenerarPaqueteDocumentalResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(crearSolicitudesResponse)
      }
      if (url === serviceUrls.generarPaqueteDocumental) {
        return Promise.resolve(valgenerarPaqueteDocumentalResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('PROD0010 => Cliente con error en axios al consumir generarPaqueteDocumental -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.crearPagare) {
        return Promise.resolve(crearPagareResponse)
      }
      if (url === serviceUrls.crearSolicitudes) {
        return Promise.resolve(crearSolicitudesResponse)
      }
      if (url === serviceUrls.generarPaqueteDocumental) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new PROD0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })
})
