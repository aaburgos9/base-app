//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { STATUS_ID } from '@services/workflowService/steps/stepData.model'

export class EstadoWorkflowData {
  /*
   * Atributos
   */
  public pasoActual: string = ''

  /*
   * Metodo constructor (inicialización) de la clase EstadoWorkflowData
   */
  constructor(
    pasoActual: string,
    pasoRetoma: string,
    fechaRetoma: string,
    fechaRechazo: string
  ) {
    this.pasoActual = pasoActual
  }
}
