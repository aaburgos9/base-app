//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '../../../../config/vars'
import { WorkflowData } from '../../../../models/workflowData.model'
import { ILogger } from '../../../loggerService'
import { IStep } from '../../steps/step'
import { IStepData } from '../../steps/stepData.model'
import { STEP_ID } from '../../steps/stepId.enum'

export class MockStep implements IStep {
  public config: IConfig
  public logger: ILogger
  public sessionData: WorkflowData

  public getNextStep = jest.fn(() => Promise.resolve(this.requestData))
  public getClientId = jest.fn(() => '')
  public getCurrentStep = jest.fn(() => STEP_ID.PENDIENTE)
  public getRequestPayload = jest.fn(() => '')
  public isRequestValid = jest.fn(() => true)
  public getRequestValidationError = jest.fn(() => 'fake-error-message')

  private requestData: IStepData

  constructor(
    stepData: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
  ) {
    this.config = config
    this.logger = logger
    this.sessionData = sessionData
    this.requestData = stepData
  }
}
