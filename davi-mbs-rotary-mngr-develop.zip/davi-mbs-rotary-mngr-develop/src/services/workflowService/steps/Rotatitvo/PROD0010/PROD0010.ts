//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi from 'joi'
import moment from 'moment'
import { GrabarInformacionSolicitudesModel } from '~/models/servicios/grabarInformacionSolicitudes'
import { UTILITIES } from '~/utils/utilities'

const STEP: string = 'PROD0010'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    crearProducto: joi.boolean().optional().allow(''),
  })
  .optional()

export class PROD0010 extends Step {
  private parmsData: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de obtención de parametros del step (PROD0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.PROD0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()

    if (reqPayload.crearProducto === true) {
      // Flujo: creacion pagare
      try {
        const resultCrearPagare = await this.crearPagare()

        this.logger.debug(
          `${STEP}:getNextStep - CrearPagare: ${JSON.stringify(
            resultCrearPagare
          )}`,
          this.sessionData.sesion.clientId
        )

        if (!resultCrearPagare) {
          // Flujo: Error

          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_004,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > CrearPagare: Error en el consumo del servicio ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}: getNextStep - Fallo al consumir crearPagare: ${JSON.stringify(
            error
          )}`,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      /// GrabarInformacionSolicitudes
      this.sessionData.sesion.grabarInfoSol.nroProceso =
        this.parmsData.grabarInformacionSolicitudes.numeroProcesoDeceval
      try {
        const resultGrabarInfo = await this.grabarInformacionSolicitudes()

        this.logger.debug(
          `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
            resultGrabarInfo
          )}`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      // Flujo: creacion solicitud
      try {
        const resultCrearSolicitudes = await this.crearSolicitudes()
        this.logger.debug(
          `${STEP}:getNextStep - CrearSolicitudes: ${JSON.stringify(
            resultCrearSolicitudes
          )}`,
          this.sessionData.sesion.clientId
        )

        if (!resultCrearSolicitudes) {
          // Flujo: Error

          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_004,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > CrearSolicitudes: Error en el consumo del servicio ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}: getNextStep - Fallo al consumir crearSolicitudes: ${JSON.stringify(
            error
          )}`,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      // Flujo: creacion pagare documental
      try {
        const resultGenerarPaqueteDoc = await this.generarPaqueteDocumental()

        this.logger.debug(
          `${STEP}:getNextStep - GenerarPaqueteDocumental: ${JSON.stringify(
            resultGenerarPaqueteDoc
          )}`,
          this.sessionData.sesion.clientId
        )
        if (!resultGenerarPaqueteDoc) {
          // Flujo: Error

          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_004,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > GenerarPaqueteDocumental: Error en el consumo del servicio ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}: getNextStep - Fallo al consumir GenerarPaqueteDocumental: ${JSON.stringify(
            error
          )}`,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      nextStep = {
        clientId: this.getClientId(),
        payload: {
          activacionRotativo: true,
          canal: this.sessionData.dataProducto.canalId,
          fechaActual: `${UTILITIES.fechaDDDMMYYYY()}, ${UTILITIES.horaDatehmma(
            new Date()
          )}`,
          lenguaje: this.sessionData.dataProducto.codIdioma,
          message: '',
          modulo: this.parmsData.kind,
          nombreTipoCuenta:
            this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmadaNombre,
          numeroCredito: this.sessionData.sesion.crearSolicitud.numeroCredito,
          numeroCuentaConfirmada:
            this.sessionData.sesion.cuentaRotativo.numeroCuentaConfirmada,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          valorConfirmado:
            this.sessionData.sesion.datosFormulario.valorAceptado,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.RESULT0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > PROD0010 - Flujo Atras hacia PROD0010`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }

    /// GrabarInformacionSolicitudes
    try {
      const resultGrabarInfo = await this.grabarInformacionSolicitudes()

      this.logger.debug(
        `${STEP}:getNextStep - Cuenta seleccionada - grabarInformacionSolicitudes ${JSON.stringify(
          resultGrabarInfo
        )}`,
        this.sessionData.sesion.clientId
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        numeroCuentaConfirmada: reqPayload.numeroCuentaVincular,
        tipoCuentaConfirmada: reqPayload.tipoCuentaVincular,
        valorConfirmando: this.sessionData.sesion.datosFormulario.valorAceptado,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.RESULT0010,
    }
    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > PROD0010 - Flujo Exitoso`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

  private grabarInformacionSolicitudes = async () => {
    this.logger.debug(
      'grabarInformacionSolicitudes',
      this.sessionData.sesion.clientId
    )

    let resultGrabarRest: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/grabar`

    const payload = new GrabarInformacionSolicitudesModel()
    await payload.setObject(this.sessionData, this.parmsData)
    await payload.getObject()
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - request: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGrabarRest = await axios.post(endpointUrl, payload.getObject())
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGrabarRest.data.errors &&
      resultGrabarRest.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGrabarRest.data.errors))
      )
    }

    const grabarRes = resultGrabarRest.data
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - Response: ${JSON.stringify(
        grabarRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: grabarRes,
    }
  }

  private crearPagare = async () => {
    const endpointUrl = `${
      this.config.getVars().back.gestionDocumentosService
    }/crearPagareDigital`
    const transaccionID = moment().unix()
    const payload = {
      payload: {
        msjSolOpCrearPagareDigital: {
          contextoSolicitud: {
            consumidor: {
              canal: {
                idCanal: this.sessionData.dataProducto.canalId,
                idHost: this.sessionData.sesion.ip,
              },
              terminal: {
                codUsuario: this.parmsData.crearPagare.terminal.codUsuario,
                idTerminal: this.sessionData.dataProducto.terminalId,
                valOrigenPeticion: this.sessionData.sesion.ip,
                valPerfil: this.parmsData.crearPagare.terminal.valPerfil,
              },
            },
            operacionCanal: {
              fecOperacion: UTILITIES.fechaYYYYMMDDTHHMMSS(),
              idSesion: this.sessionData.sesion.clientId,
              idTransaccion: transaccionID.toString(),
            },
          },
          data: {
            codigoDepositante: {
              codigoDepositante: this.parmsData.crearPagare.codigoDepositante,
            },
            documentoPagareServiceTipo: {
              creditoReembolsableEn:
                this.parmsData.crearPagare.documentoPagareServiceTipo
                  .creditoReembolsableEn,
              idClaseDefinicionDocumento:
                this.parmsData.crearPagare.documentoPagareServiceTipo
                  .idClaseDefinicionDocumento,
              idDocumentoPagare:
                this.parmsData.crearPagare.documentoPagareServiceTipo
                  .idDocumentoPagare,
              nitEmisor:
                this.parmsData.crearPagare.documentoPagareServiceTipo.nitEmisor,
              otorganteNumId: this.sessionData.dataProducto.numeroDocumento,
              otorganteTipoId: this.sessionData.dataProducto.tipoDocumento,
              tipoPagare:
                this.parmsData.crearPagare.documentoPagareServiceTipo
                  .tipoPagare,
              valorPesosDesembolso:
                this.parmsData.crearPagare.documentoPagareServiceTipo
                  .valorPesosDesembolso,
            },
            informacionFirmarPagareTipo: {
              infoCertificadoFirmaTipo: {
                clave: this.sessionData.biometria.retoOtp.tokenOTP,
                idRolFirmante:
                  this.parmsData.crearPagare.infoCertificadoFirmaTipo
                    .idRolFirmante,
                numeroDocumento: this.sessionData.dataProducto.numeroDocumento,
                tipoDocumento: this.sessionData.dataProducto.tipoDocumento,
              },
              oTPProcedimiento: this.parmsData.crearPagare.oTPProcedimiento,
            },
            listaCrearGirador: {
              correoElectronico:
                this.sessionData.sesion.consultaClientePN.email,
              direccion1PersonaGrupo_PGP:
                this.sessionData.sesion.consultaClientePN.direccionDI,
              fkIdClasePersona:
                this.parmsData.crearPagare.listaCrearGirador.fkIdClasePersona,
              fkIdTipoDocumento:
                this.parmsData.crearPagare.listaCrearGirador.fkIdTipoDocumento,
              giradorNaturalTipo: {
                fkIdCiudadDomicilio_Nat:
                  this.parmsData.crearPagare.listaCrearGirador
                    .giradorNaturalTipo.fkIdCiudadDomicilio_Nat,
                fkIdCiudadExpedicion_Nat:
                  this.parmsData.crearPagare.listaCrearGirador
                    .giradorNaturalTipo.fkIdCiudadExpedicion_Nat,
                fkIdDepartamentoDomicilio_Nat:
                  this.parmsData.crearPagare.listaCrearGirador
                    .giradorNaturalTipo.fkIdDepartamentoDomicilio_Nat,
                fkIdDepartamentoExpedicion_Nat:
                  this.parmsData.crearPagare.listaCrearGirador
                    .giradorNaturalTipo.fkIdDepartamentoExpedicion_Nat,
                fkIdPaisDomicilio_Nat:
                  this.parmsData.crearPagare.listaCrearGirador
                    .giradorNaturalTipo.fkIdPaisDomicilio_Nat,
                nombresNat_Nat:
                  this.sessionData.sesion.consultaClientePN.nombres,
                numeroCelular:
                  this.sessionData.sesion.consultaClientePN.numeroCel,
                primerApellido_Nat:
                  this.sessionData.sesion.consultaClientePN.primerApellido,
                segundoApellido_Nat:
                  this.sessionData.sesion.consultaClientePN.segundoApellido,
              },
              identificacionEmisor:
                this.parmsData.crearPagare.listaCrearGirador
                  .identificacionEmisor,
              numeroDocumento: this.sessionData.dataProducto.numeroDocumento,
            },
          },
        },
        operation: {
          canalId: this.sessionData.dataProducto.canalId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          logger: this.parmsData.loggerVersion,
          moduleId: this.sessionData.dataProducto.moduloId,
          sessionId: this.sessionData.sesion.clientId,
        },
      },
    }

    this.logger.debug(
      `${STEP}:crearPagare - Payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any
    try {
      serviceData = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valCrearPagare = serviceData.data
    this.logger.debug(
      `${STEP}:crearPagare -  Response: ${JSON.stringify(valCrearPagare)}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio =
      valCrearPagare.contextoRespuesta.resultadoTransaccion
        .valCaracterAceptacion
    if (estadoServicio === this.parmsData.crearPagare.caracterAceptacionSvc) {
      estatus = true
      this.sessionData.sesion.crearPagareDigital.idPagareDigital =
        valCrearPagare.respuestaDocumentoPagareDaneServiceTipo?.listaRespuesta[0]?.idDocumentoPagare
    }
    return estatus
  }

  private crearSolicitudes = async () => {
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/crearSolicitud`

    const transaccionID = moment().unix()
    const payload = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              total: this.sessionData.sesion.total,
              // tslint:disable-next-line: object-literal-sort-keys
              canal: this.sessionData.dataProducto.canalId,
            },
            // tslint:disable-next-line: object-literal-sort-keys
            Data: {
              IdTransaccion: transaccionID.toString(),
              idSesion: this.sessionData.dataProducto.sesionIdCanal,
              // tslint:disable-next-line: object-literal-sort-keys
              CodIdioma: this.sessionData.dataProducto.codIdioma,
              ValOrigen: this.sessionData.sesion.ip,
              CodPais: this.parmsData.crearSolicitudes.CodPais,
              aplicacionOrigen: this.sessionData.dataProducto.canalId,
              ipOrigen: this.sessionData.sesion.ip,
              numeroSolicitudSiebel:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              numeroOfertaSiebel:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              lineaCreditoSiebel:
                this.parmsData.crearSolicitudes.lineaCreditoSiebel,
              destinoCreditoSiebel:
                this.parmsData.crearSolicitudes.destinoCreditoSiebel,
              tipoCreditoSiebel:
                this.parmsData.crearSolicitudes.tipoCreditoSiebel,
              tipoGarantiaSiebel:
                this.parmsData.crearSolicitudes.tipoGarantiaSiebel,
              estGarantiaHipotecario:
                this.parmsData.crearSolicitudes.estGarantiaHipotecario,
              actividadLaboral:
                this.sessionData.sesion.datosFormulario.actividadLaboral.codigo,
              edad: UTILITIES.obtenerEdad(
                this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI
              ),
              moneda: this.parmsData.crearSolicitudes.moneda,
              rangoColocacionSiebel:
                this.parmsData.crearSolicitudes.rangoColocacionSiebel,
              productoSiebel: this.parmsData.crearSolicitudes.productoSiebel,
              usoGarantiaSiebel:
                this.parmsData.crearSolicitudes.usoGarantiaSiebel,
              numeroSolicitantes:
                this.parmsData.crearSolicitudes.numeroSolicitantes,
              tipoIdentificacion1erSol:
                this.sessionData.dataProducto.tipoDocumento,
              numeroIdentificacion1erSol:
                this.sessionData.dataProducto.numeroDocumento,
              naturalezaJuridica1erSol:
                this.parmsData.crearSolicitudes.naturalezaJuridica1erSol,
              edad1erSolicitante: UTILITIES.obtenerEdad(
                this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI
              ),
              indEmplDav1erSol:
                this.parmsData.crearSolicitudes.indEmplDav1erSol,
              AdquiereSeguroDesempleo1erSol:
                this.parmsData.crearSolicitudes.AdquiereSeguroDesempleo1erSol,
              plazoCreditoEnPeriodos:
                this.parmsData.crearSolicitudes.plazoCreditoEnPeriodos,
              canalVentaCredito:
                this.parmsData.crearSolicitudes.canalVentaCredito,
              valorSolicitado:
                this.sessionData.sesion.datosFormulario.valorAceptado,
              numeroCuentaDebitoAutomatico: this.sessionData.sesion.cuentaDebito
                .numeroCuentaDebitar
                ? this.sessionData.sesion.cuentaDebito.numeroCuentaDebitar
                : this.parmsData.crearSolicitudes.numeroCuentaDebitoAutomatico,
              agenteVendedor: this.sessionData.sesion.datosFormulario
                .codigoAsesor
                ? this.sessionData.sesion.datosFormulario.codigoAsesor
                : this.parmsData.agenteVendedor,
              sucursalCredito: this.parmsData.crearSolicitudes.sucursalCredito,
              oficinaEspecialParaSolicitudes:
                this.parmsData.crearSolicitudes.oficinaEspecialParaSolicitudes,
              valorTasaInteresSinCobertura:
                this.parmsData.crearSolicitudes.valorTasaInteresSinCobertura,
              cuotaSinSeguroSinCobertura:
                this.parmsData.crearSolicitudes.cuotaSinSeguroSinCobertura,
              cuotaConSeguroSinCobertura:
                this.parmsData.crearSolicitudes.cuotaConSeguroSinCobertura,
              codigoOficinaRadicacion:
                this.parmsData.crearSolicitudes.codigoOficinaRadicacion,
              fechaDiligenciamientoDeSolicitud: UTILITIES.fechaYYYYMMDD(),
              diaDeCorte: this.parmsData.crearSolicitudes.diaDeCorte, // TODO: PENDIENTE DEFINICION
              companiaDeSegurosVar41:
                this.parmsData.crearSolicitudes.companiaDeSegurosVar41,
              companiaDeSegurosVar1180:
                this.parmsData.crearSolicitudes.companiaDeSegurosVar1180,
              bancoCuentaADebitar:
                this.parmsData.crearSolicitudes.bancoCuentaADebitar,
              tipoCuenta: this.sessionData.sesion.cuentaDebito.tipoCuentaDebitar
                ? this.sessionData.sesion.cuentaDebito.tipoCuentaDebitar
                : this.parmsData.crearSolicitudes.tipoCuenta,
              ingresos: this.sessionData.sesion.consultaClientePN.ingresos,
              tasaTipoSiebel: this.parmsData.crearSolicitudes.tasaTipoSiebel,
              segmentoClienteSiebel:
                this.parmsData.crearSolicitudes.segmentoClienteSiebel,
              valorTasaEA: this.parmsData.crearSolicitudes.valorTasaEA,
              planVehiculo: this.parmsData.crearSolicitudes.planVehiculo,
              calificacionOriginacion:
                this.parmsData.crearSolicitudes.calificacionOriginacion,
              ciudadDiligenciamiento:
                this.parmsData.crearSolicitudes.ciudadDiligenciamiento,
              fechaDesicion: UTILITIES.fechaYYYYMMDD(),
              usoFuturoNum2: this.parmsData.crearSolicitudes.usoFuturoNum2,
              realizoListasRestrictivas:
                this.parmsData.crearSolicitudes.realizoListasRestrictivas,
              scorePrecioCliente:
                this.parmsData.crearSolicitudes.scorePrecioCliente,
            },
          },
        },
        // tslint:disable-next-line: object-literal-sort-keys
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          // tslint:disable-next-line: object-literal-sort-keys
          canalId: this.sessionData.dataProducto.canalId,
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          moduleId: this.sessionData.dataProducto.moduloId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          logger: this.parmsData.loggerVersion,
        },
      },
    }

    this.logger.debug(
      `${STEP}:crearSolicitudes - Payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any
    try {
      serviceData = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valCrearSolicitudes = serviceData.data.Response
    this.logger.debug(
      `${STEP}:crearSolicitudes -  Response: ${JSON.stringify(
        valCrearSolicitudes
      )}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio = valCrearSolicitudes.DataHeader.caracterAceptacion
    if (
      estadoServicio === this.parmsData.crearSolicitudes.caracterAceptacionSvc
    ) {
      estatus = true
      this.sessionData.sesion.crearSolicitud.numeroCredito =
        valCrearSolicitudes.Data.numeroPrestamoFM
    }
    return estatus
  }

  private generarPaqueteDocumental = async () => {
    this.logger.debug(
      'generarPaqueteDocumental',
      this.sessionData.sesion.clientId
    )
    let diaActual = new Date().getDate().toString()
    let mesActual = (new Date().getMonth() + 1).toString()
    const anioActual = new Date().getFullYear()

    if (diaActual.length === 1) {
      diaActual = `0${diaActual}`
    }
    if (mesActual.length === 1) {
      mesActual = `0${mesActual}`
    }
    const fechaNacimiento = this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI.split(
      ' '
    )[0]
    let resultGenerarPaqueteDoc: any
    const endpointUrl = `${
      this.config.getVars().back.soapWebService
    }/soap-service`
    const transaccionID = moment().unix()
    const payloadData = {
      payload: {
        idService: this.parmsData.generarPaqueteDocumental.idService,
        keyService: this.parmsData.generarPaqueteDocumental.keyService,
        operation: {
          canalId: this.sessionData.dataProducto.canalId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          id: this.sessionData.sesion.clientId,
          ip: this.sessionData.sesion.ip,
          logger: this.parmsData.generarPaqueteDocumental.logger,
          moduleId: this.sessionData.dataProducto.moduloId,
          sessionId: this.sessionData.sesion.clientId,
        },
        service: {
          msjSolOpGenerarPaquete: {
            cliente: {
              valMail: this.sessionData.sesion.consultaClientePN.email,
              valNumeroIdentificacion:
                this.sessionData.dataProducto.numeroDocumento,
              valTipoIdentificacion:
                this.sessionData.dataProducto.tipoDocumento,
            },
            contextoSolicitud: {
              consumidor: {
                aplicacion: {
                  idAplicacion:
                    this.parmsData.generarPaqueteDocumental.idAplicacion,
                },
                canal: {
                  idCanal: this.sessionData.dataProducto.canalId,
                  idHost: this.sessionData.sesion.ip,
                },
                idConsumidor:
                  this.parmsData.generarPaqueteDocumental.idAplicacion,
                terminal: {
                  codUsuario:
                    this.parmsData.generarPaqueteDocumental.codUsuario,
                  idTerminal: this.sessionData.dataProducto.terminalId,
                  valOrigenPeticion: this.sessionData.sesion.ip,
                  valPerfil: this.parmsData.valPerfil,
                },
              },
              operacionCanal: {
                codIdioma: this.sessionData.dataProducto.codIdioma,
                codMoneda: this.parmsData.codMoneda,
                codPais: this.sessionData.dataProducto.country,
                fecOperacion: UTILITIES.fechaYYYYMMDDTHHMMSS(),
                idSesion: this.sessionData.sesion.clientId,
                idTransaccion: transaccionID.toString(),
                valJornada: this.parmsData.valJornada,
              },
              servicio: {
                idServicio: this.parmsData.generarPaqueteDocumental.idService,
              },
            },
            enviarCopiaCorreo:
              this.parmsData.generarPaqueteDocumental.enviarCopiaCorreo,
            listaParametros: {
              valParametro: [
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[0],
                  valor: this.sessionData.sesion.consultaClientePN.nombres,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[1],
                  valor:
                    this.sessionData.sesion.consultaClientePN.primerApellido,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[2],
                  valor:
                    this.sessionData.sesion.consultaClientePN.segundoApellido,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[3],
                  valor:
                    this.sessionData.dataProducto.tipoDocumento === '01'
                      ? 'CC'
                      : 'CC',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[4],
                  valor: this.sessionData.dataProducto.numeroDocumento,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[5],
                  valor:
                    this.sessionData.dataProducto.canalId === '37'
                      ? this.parmsData.generarPaqueteDocumental.canal
                      : this.parmsData.generarPaqueteDocumental.aliado,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[6],
                  valor: this.sessionData.sesion.ip,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[7],
                  valor: UTILITIES.fechaYYYYMMDDSeparadores('-'),
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[8],
                  valor: UTILITIES.horaHHMMSSSeparador(),
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[9],
                  valor:
                    this.parmsData.generarPaqueteDocumental.autoriza_pagare,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[10],
                  valor:
                    this.parmsData.generarPaqueteDocumental
                      .autoriza_asegurabilidad,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[11],
                  valor:
                    this.parmsData.generarPaqueteDocumental
                      .autoriza_asegurabilidad,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[12],
                  valor:
                    this.parmsData.generarPaqueteDocumental
                      .autoriza_condiciones,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[13],
                  valor:
                    this.parmsData.generarPaqueteDocumental.autoriza_solicitud,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[14],
                  valor:
                    this.sessionData.sesion.consultaPersistencia.nroSolicitud,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[15],
                  valor: this.parmsData.generarPaqueteDocumental.metodo_firma,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[16],
                  valor: this.sessionData.sesion.consultaClientePN.ciudad,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[17],
                  valor: this.parmsData.generarPaqueteDocumental.tipo_producto,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[18],
                  valor: this.sessionData.sesion.datosFormulario.valorAceptado,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[19],
                  valor:
                    this.sessionData.sesion.consultaClientePN
                      .oficinaRadicacionCLI,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[20],
                  valor: this.sessionData.sesion.autorizacionDebitoAuto
                    ? this.sessionData.sesion.cuentaRotativo
                        .numeroCuentaConfirmada
                    : '',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[21],
                  valor: this.parmsData.generarPaqueteDocumental.cual,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[22],
                  valor:
                    this.sessionData.sesion.consultaClientePN.fechaExpedicionCLI.split(
                      ' '
                    )[0],
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[23],
                  valor:
                    this.sessionData.sesion.consultaClientePN.ciudadExpedicion,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[24],
                  valor:
                    this.sessionData.sesion.consultaClientePN.sexoCLI === 'M'
                      ? this.parmsData.generarPaqueteDocumental.genero_m
                      : '',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[25],
                  valor:
                    this.sessionData.sesion.consultaClientePN.sexoCLI === 'F'
                      ? this.parmsData.generarPaqueteDocumental.genero_f
                      : '',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[26],
                  valor: this.sessionData.sesion.consultaClientePN.ciudad,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[27],
                  valor:
                    this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI.split(
                      ' '
                    )[0],
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[28],
                  valor: this.sessionData.sesion.consultaClientePN.direccionDI,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[29],
                  valor: this.sessionData.sesion.consultaClientePN.ciudad,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[30],
                  valor: this.sessionData.sesion.consultaClientePN.departamento,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[31],
                  valor: this.sessionData.sesion.consultaClientePN.numeroCel,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[32],
                  valor: this.sessionData.sesion.consultaClientePN.email,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[33],
                  valor:
                    this.sessionData.sesion.datosFormulario.actividadLaboral
                      .descripcion,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[34],
                  valor:
                    this.sessionData.sesion.datosFormulario.actividadLaboral
                      .codigo === 'E'
                      ? this.sessionData.sesion.datosFormulario.tipoContrato
                          .descripcion
                      : '',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[35],
                  valor:
                    this.sessionData.sesion.datosFormulario.actividadLaboral
                      .codigo === 'I'
                      ? this.sessionData.sesion.datosFormulario
                          .actividadEconomica
                      : '',
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[36],
                  valor:
                    this.sessionData.sesion.datosFormulario.ingresosMensuales,
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[37],
                  valor:
                    this.sessionData.dataProducto.canalId === '37'
                      ? this.parmsData.generarPaqueteDocumental.canal
                      : this.parmsData.generarPaqueteDocumental.aliado,
                },
                // Nuevos campos asegurabilidad
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[38],
                  valor: diaActual
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[39],
                  valor: mesActual
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[40],
                  valor: anioActual
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[41],
                  valor:fechaNacimiento.slice(8,10)
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[42],
                  valor:fechaNacimiento.slice(5,7)
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[43],
                  valor:fechaNacimiento.slice(0,4)
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[44],
                  valor:this.parmsData.generarPaqueteDocumental.comprobante
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[45],
                  valor: this.sessionData.dataProducto.tipoDocumento === '01'
                  ? this.parmsData.generarPaqueteDocumental.tipoCC
                  : this.parmsData.generarPaqueteDocumental.notipoCC,
                  
                },
                {
                  id: this.parmsData.generarPaqueteDocumental.valParametro[46],
                  valor: this.sessionData.dataProducto.tipoDocumento === '02'
                  ? this.parmsData.generarPaqueteDocumental.tipoCE
                  : this.parmsData.generarPaqueteDocumental.notipoCE,
                },
              ],
            },
            paqueteDocId: this.parmsData.generarPaqueteDocumental.paqueteDocId,
            requiereClave:
              this.parmsData.generarPaqueteDocumental.requiereClave,
            valClaveDocumento: this.parmsData.generarPaqueteDocumental
              .requiereClave
              ? this.sessionData.dataProducto.tipoDocumento
              : '',
          },
        },
        urlServiceOption:
          this.parmsData.generarPaqueteDocumental.urlServiceOption,
      },
    }

    this.logger.debug(
      `${STEP}:generarPaqueteDocumental - request: ${JSON.stringify(
        payloadData
      )}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGenerarPaqueteDoc = await axios.post(endpointUrl, payloadData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGenerarPaqueteDoc.data.errors &&
      resultGenerarPaqueteDoc.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGenerarPaqueteDoc.data.errors))
      )
    }

    const generarPaqueteDocRes =
      resultGenerarPaqueteDoc.data.res.contextoRespuesta
    this.logger.debug(
      `${STEP}:generarPaqueteDocumental - Response: ${JSON.stringify(
        generarPaqueteDocRes
      )}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio =
      generarPaqueteDocRes.resultadoTransaccion.valCaracterAceptacion
    if (
      estadoServicio ===
      this.parmsData.generarPaqueteDocumental.caracterAceptacionSvc
    ) {
      estatus = true
    }
    return estatus
  }
}
