//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class DocumentoData {
  /*
   * Atributos
   */
  public tipo: string = ''
  public numero: string = ''

  /*
   * Metodo constructor (inicialización) de la clase DocumentoData
   */
  constructor(tipo: string, numero: string) {
    this.tipo = tipo
    this.numero = numero
  }
}
