//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars';
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model';
import { WorkflowData } from '@models/workflowData.model';
import { ILogger } from '@services/loggerService';
import { Step } from '@services/workflowService/steps/step';
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model';
import { STEP_ID } from '@services/workflowService/steps/stepId.enum';
import axios from 'axios';
import joi from 'joi';
import moment from 'moment';

const STEP: string = 'AUT0010';
const IDIOMA: string = 'ES';
const PRODUCTO: string = 'CRRT';

const inputSchema = joi
  .object()
  .keys({
    atras: joi.boolean().required(),
    autorizacionAsegurabilidad: joi
      .object()
      .keys({
        check: joi.boolean().optional().allow(''),
        fecha: joi.string().optional().allow(''),
        version: joi.string().optional().allow(''),
      })
      .optional(),
    autorizacionContratoCredito: joi
      .object()
      .keys({
        check: joi.boolean().optional().allow(''),
        fecha: joi.string().optional().allow(''),
        version: joi.string().optional().allow(''),
      })
      .optional(),
    autorizacionDebitoAuto: joi
      .object()
      .keys({
        check: joi.boolean().optional().allow(''),
        fecha: joi.string().optional().allow(''),
        version: joi.string().optional().allow(''),
      })
      .optional(),
    autorizacionPagare: joi
      .object()
      .keys({
        check: joi.boolean().optional().allow(''),
        fecha: joi.string().optional().allow(''),
        version: joi.string().optional().allow(''),
      })
      .optional(),
    cuentaDebitar: joi
      .object()
      .keys({
        numeroCuenta: joi.string().optional().allow(''),
        tipoCuenta: joi.string().optional().allow(''),
      })
      .optional(),
  })
  .optional();

export class AUT0010 extends Step {
  private parmsData: any = {};

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
  ) {
    super(currentStep, sessionData, config, logger, inputSchema);
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload();
    let nextStep: IStepData;
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    );

    if (reqPayload.atras === true) {
      // Flujo: Regreso pantalla de confirmación
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          numeroCuentaConfirmada:
            this.sessionData.sesion.cuentaRotativo.numeroCuentaConfirmada,
          tipoCuentaConfirmada:
            this.sessionData.sesion.cuentaRotativo.tipoCuentaConfirmada,
          valorConfirmando:
            this.sessionData.sesion.datosFormulario.valorAceptado,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.DAT0010,
      };
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      );
      this.logger.debug(
        `${STEP}:getNextStep > INFO0010 - Flujo Atras hacia DAT0010`,
        this.sessionData.sesion.clientId
      );

      return nextStep;
    }
    // Lógica de obtención de parametros del step (ATRN0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.AUT0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      );
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      );
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    );

    this.sessionData.sesion.autorizacionDebitoAuto =
      reqPayload.autorizacionDebitoAuto.check ? reqPayload.autorizacionDebitoAuto.check : false
    this.sessionData.sesion.cuentaDebito.numeroCuentaDebitar = reqPayload
      .cuentaDebitar.numeroCuenta
      ? reqPayload.cuentaDebitar.numeroCuenta ===
        this.parmsData.esNumeroCuentaDebitar
        ? ''
        : reqPayload.cuentaDebitar.numeroCuenta
      : '';

    this.sessionData.sesion.cuentaDebito.tipoCuentaDebitar = reqPayload
      .cuentaDebitar.tipoCuenta
      ? reqPayload.cuentaDebitar.tipoCuenta ===
        this.parmsData.cuentaAhorros.nombre
        ? this.parmsData.cuentaAhorros.codigo
        : this.parmsData.cuentaCorriente.codigo
      : '';

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout);

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15; // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString();

    // flujo: consumo Log Juridicos
    if (reqPayload.autorizacionAsegurabilidad.check) {
      let documentNameCheck: '';
      let typeCheck: '';
      documentNameCheck = this.parmsData.loggerJuridico.asegurabilidad.nombre;
      typeCheck = this.parmsData.loggerJuridico.asegurabilidad.tipo;
      let resultLogJuridico: any;
      try {
        resultLogJuridico = await this.logJuridico(documentNameCheck, typeCheck);
        this.logger.debug(
          `${STEP}:getNextStep - logJuridico ${JSON.stringify(
            resultLogJuridico
          )}`,
          this.sessionData.sesion.clientId
        );
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir logJuridico ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        );
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
      }
    }
    if (reqPayload.autorizacionContratoCredito.check) {
      let documentNameCheck: '';
      let typeCheck: '';
      documentNameCheck = this.parmsData.loggerJuridico.contratoCredito.nombre;
      typeCheck = this.parmsData.loggerJuridico.contratoCredito.tipo;
      let resultLogJuridico: any;
      try {
        resultLogJuridico = await this.logJuridico(documentNameCheck, typeCheck);
        this.logger.debug(
          `${STEP}:getNextStep - logJuridico ${JSON.stringify(
            resultLogJuridico
          )}`,
          this.sessionData.sesion.clientId
        );
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir logJuridico ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        );
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
      }
    }
    if (reqPayload.autorizacionPagare.check) {
      let documentNameCheck: '';
      let typeCheck: '';
      documentNameCheck = this.parmsData.loggerJuridico.pagare.nombre;
      typeCheck = this.parmsData.loggerJuridico.pagare.tipo;
      let resultLogJuridico: any;
      try {
        resultLogJuridico = await this.logJuridico(documentNameCheck, typeCheck);
        this.logger.debug(
          `${STEP}:getNextStep - logJuridico ${JSON.stringify(
            resultLogJuridico
          )}`,
          this.sessionData.sesion.clientId
        );
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir logJuridico ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        );
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
      }
    }
    if (reqPayload.autorizacionDebitoAuto.check) {
      let documentNameCheck: '';
      let typeCheck: '';
      documentNameCheck = this.parmsData.loggerJuridico.debitoAutomatico.nombre;
      typeCheck = this.parmsData.loggerJuridico.debitoAutomatico.tipo;
      let resultLogJuridico: any;
      try {
        resultLogJuridico = await this.logJuridico(documentNameCheck, typeCheck);
        this.logger.debug(
          `${STEP}:getNextStep - logJuridico ${JSON.stringify(
            resultLogJuridico
          )}`,
          this.sessionData.sesion.clientId
        );
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir logJuridico ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        );
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
      }
    }

    // Flujo: proceso de biometria interna PROBIOINT
    let dataProceso: boolean = false;
    try {
      dataProceso = await this.enviarDataProcesoPROBIOINT();
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
    }
    this.logger.debug(
      `${STEP}:getNextStep - seteo de datos al proceso de biometria interna (MBaaS 2.0): ${dataProceso} `,
      this.sessionData.sesion.clientId
    );

    this.logger.debug(
      `${STEP}:getNextStep - Invocación al proceso de biometria interna (MBaaS 2.0)`,
      this.sessionData.sesion.clientId
    );

    // Flujo 1: Fallo en el Envio de datos al proceso de biometria interna
    if (!dataProceso) {
      this.logger.error(
        `${STEP}:getNextStep - seteo fallido de datos al proceso de biometria intera (MBaaS 2.0)`
      );
    }

    nextStep = {
      clientId: this.getClientId(),
      payload: {
        urlProceso: this.parmsData.urlProcesoBiometriaInterna,
      },
      status: STATUS_ID.MENSAJE_BIOMETRIA,
      stepId: STEP_ID.AUT0010,
    };
    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    );
    this.logger.debug(
      `${STEP}:getNextStep > AUT0010 - Flujo Exitoso`,
      this.sessionData.sesion.clientId
    );

    return nextStep;
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${this.config.getVars().back.parmsServiceUrl
      }/parms/${nodo}?${filtros}`;

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    );

    let serviceData: any;

    try {
      serviceData = await axios.get(endpointUrl);
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      );
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      );
    }

    const valParmsSvc = serviceData.data.data;

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    );

    return valParmsSvc;
  }

  private logJuridico = async (documentName: string, typeCheck: string) => {
    this.logger.debug('logJuridico', this.sessionData.sesion.clientId);

    let resultLogJuridico: any;
    const endpointUrl = `${this.config.getVars().back.loggerDevaService
      }/auditoria/juridico`;

    const transaccionID = moment().unix();
    const payloadData = {
      approvalReference: {
        documentName,
        type: typeCheck,
      },
      operation: {
        canalId: this.sessionData.dataProducto.canalId,
        client: {
          documentClient: {
            number: this.sessionData.dataProducto.numeroDocumento,
            type: this.sessionData.dataProducto.tipoDocumento,
          },
          userId: this.sessionData.sesion.clientId,
        },
        id: this.sessionData.dataProducto.moduloId,
        ip: this.sessionData.sesion.ip,
        moduleId: this.sessionData.dataProducto.moduloId,
        sessionId: this.sessionData.sesion.clientId,
      },
    };
    this.logger.debug(
      `${STEP}:Consumo Log Juridico - request: ${JSON.stringify(payloadData)}`,
      this.sessionData.sesion.clientId
    );
    try {
      resultLogJuridico = await axios.post(endpointUrl, payloadData);
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
    }

    if (
      resultLogJuridico.data.errors &&
      resultLogJuridico.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultLogJuridico.data.errors))
      );
    }

    const logJuridicoRes = resultLogJuridico.data.data.estatus;
    this.logger.debug(
      `${STEP}:logJuridico - Response: ${JSON.stringify(logJuridicoRes)}`,
      this.sessionData.sesion.clientId
    );

    return {
      codMessageError: '',
      data: logJuridicoRes,
    };
  }

  private enviarDataProcesoPROBIOINT = async () => {
    const endpointUrl = `${this.config.getVars().back.procesoBiometriaInternaWorkflowServiceUrl
      }/proceso`;

    const payload = {
      clientId: this.getClientId(),
      payload: {
        client: {
          documentClient: {
            number: this.sessionData.dataProducto.numeroDocumento,
            type: this.sessionData.dataProducto.tipoDocumento,
          },
          email: this.sessionData.sesion.consultaClientePN.email,
          name: `${this.sessionData.sesion.consultaClientePN.nombres} ${this.sessionData.sesion.consultaClientePN.primerApellido} ${this.sessionData.sesion.consultaClientePN.segundoApellido}`,
          phoneNumber: {
            countryId: this.parmsData.biometriaInterna.countryId,
            number: this.sessionData.sesion.consultaClientePN.numeroCel,
          },
        },
        consumer: {
          appConsumer: {
            canalId: this.sessionData.dataProducto.canalId,
            id: this.sessionData.dataProducto.moduloId,
            sessionId:
              this.sessionData.sesion.presentacion.consumer?.appConsumer
                ?.sessionId,
            terminalId: this.sessionData.dataProducto.terminalId,
            total: this.sessionData.sesion.total,
            transactionId: this.sessionData.dataProducto.transactionId,
          },
          deviceConsumer: {
            id: this.sessionData.dataProducto.deviceConsumerId,
            inactiveInterval: this.sessionData.dataProducto.inactiveInterval,
            locale: this.parmsData.locale,
            sessionTimeout: this.parmsData.sessionTimeout,
            userAgent: this.sessionData.dataProducto.userAgent,
          },
          genericData: {
            dataItem: [
              {
                key: this.parmsData.biometriaInterna.genericData.platformType,
                value:
                  this.sessionData.sesion.presentacion.consumer?.appConsumer
                    ?.platformType,
              },
              {
                key: this.parmsData.biometriaInterna.genericData.userType,
                value:
                  this.sessionData.sesion.presentacion.client
                    ?.authenticationType,
              },
              {
                key: this.parmsData.biometriaInterna.activityAmount,
                value: `${this.sessionData.sesion.datosFormulario.valorAceptado}.00`
              },
              {
                key: this.parmsData.biometriaInterna.payeeAccountType,
                value: this.parmsData.biometriaInterna.payeeAccountTypeValue,
              },
              {
                key: this.parmsData.biometriaInterna.contingencia,
                value: this.parmsData.biometriaInterna.contingenciaValue,
              },
              {
                key: this.parmsData.biometriaInterna.ip,
                value: this.sessionData.sesion.ip,
              },
              {
                key: this.parmsData.biometriaInterna.userAgent,
                value: this.sessionData.dataProducto.userAgent,
              }
            ],
          },
        },
        partner: {
          callbackUrl: {
            denial: this.parmsData.biometriaInterna.partner.callbackUrl.denial,
            error: this.parmsData.biometriaInterna.partner.callbackUrl.error,
            success:
              this.parmsData.biometriaInterna.partner.callbackUrl.success,
          },
          id: this.parmsData.biometriaInterna.partner.id,
        },
        product: {
          country: this.sessionData.dataProducto.country,
          id: this.sessionData.dataProducto.moduloId,
        },
        sesionIdCanal: this.sessionData.sesion.presentacion.consumer?.appConsumer
          ?.sessionId,
        tipoCanal: this.parmsData.biometriaInterna.tipoCanal,
        tipoOtp: this.parmsData.biometriaInterna.tipoOtp,
        tipoPlataforma: this.parmsData.biometriaInterna.tipoPlataforma,
        token: this.sessionData.dataProducto.tokenFrontend,
      },
      urlProducto: this.parmsData.urlProducto,
    };

    this.logger.debug(
      `${STEP}:enviarDataProcesoPROBIOINT - Payload: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    );
    let serviceData: any;
    try {
      serviceData = await axios.post(endpointUrl, payload);
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error);
    }
    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      );
    }

    const valProcesoBiometriaInternaWfSvc: boolean = serviceData.data.data;

    this.logger.debug(
      `${STEP}:enviarDataProcesoPROBIOINT -  Response: ${JSON.stringify(
        valProcesoBiometriaInternaWfSvc
      )}`,
      this.sessionData.sesion.clientId
    );

    return valProcesoBiometriaInternaWfSvc;
  }
}
