//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { buildProviderModule, container } from '@config/ioc/inversify.config'

/* REST Controllers */
import '@routes/v1/presentacion-cliente/presentacion.controller'
import '@routes/v1/workflow/workflow.controller'

/* Services */
import '@services/auth/authService'
import '@services/crypto/cryptoService'
import '@services/loggerService/loggerLog4js'
import '@services/persistence/persistenceService'
import '@services/presentacion/presentacionService'
import '@services/workflowService/stepFactory/stepFactory'
import '@services/workflowService/workflowService'

container.load(buildProviderModule())
