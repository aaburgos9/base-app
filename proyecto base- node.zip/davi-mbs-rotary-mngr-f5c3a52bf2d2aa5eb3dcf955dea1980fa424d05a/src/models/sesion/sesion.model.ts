//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { ESTADO_SESION } from '@models/enums/estadoSesion.enum'
import { EstadoAppData } from '@models/sesion/estadoApp.model'
import { EstadoWorkflowData } from '@models/sesion/estadoWorkflow.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import uuid = require('uuid')

export enum TipoSesion {
  PRODUCTO,
}

export class SesionData {
  /*
   * Atributos
   */
  public clientId: string = ''
  public tipo: TipoSesion
  public presentacion: IPresentacionClientes
  public workflow: EstadoWorkflowData
  public app: EstadoAppData
  public estado: ESTADO_SESION
  public fechaExpiracion: string = ''
  public expiracionSesion: string = ''
  public ultimaAccion: string = ''

  /*
   * Metodo constructor (inicialización) de la clase SesionData
   */
  constructor(presentacionCliente: IPresentacionClientes, fechaExpiracion: string, expiracionSesion: string, ultimaAccion: string) {
    this.clientId = uuid.v1()
    this.tipo = TipoSesion.PRODUCTO
    this.workflow = new EstadoWorkflowData('', '', '', '')
    this.app = new EstadoAppData()
    this.presentacion = presentacionCliente
    this.estado = ESTADO_SESION.NUEVO
    this.fechaExpiracion = fechaExpiracion
    this.expiracionSesion = expiracionSesion
    this.ultimaAccion = ultimaAccion
  }
}
