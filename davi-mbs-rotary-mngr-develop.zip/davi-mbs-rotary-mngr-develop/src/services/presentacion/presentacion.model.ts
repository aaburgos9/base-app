//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import joi from 'joi'

export interface INuevaSesion {
  clientId: string
  otp: string
  appUrl: string
}

export interface IPresentacionRequest {
  data: string
}

// Esquema de validación para requests de Presentacion de Clientes
export const presentacionRequestSchema = joi
  .object()
  .keys({
    client: joi
      .object()
      .keys({
        authenticationType: joi.string().allow('').optional(),
        documentClient: joi
          .object()
          .keys({
            number: joi.string().allow('').optional(),
            type: joi.string().allow('').optional(),
          })
          .optional(),
        email: joi.string().allow('').optional(),
        name: joi.string().allow('').optional(),        
        userId:joi.string().allow('').optional()        
      })
      .optional(),
    consumer: joi
      .object()
      .keys({
        appConsumer: joi
          .object()
          .keys({            
            canalId: joi.string().allow('').optional(),
            id: joi.string().allow('').optional(),
            platformType: joi.string().allow('').optional(),
            sessionId: joi.string().allow('').optional(),
            transactionId: joi.string().allow('').optional(),
          })
          .optional(),
        deviceConsumer: joi
          .object()
          .keys({
            id: joi.string().allow('').optional(),
            inactiveInterval: joi.string().allow('').optional(),
            userAgent: joi.string().allow('').optional(),
          })
          .optional(),
        genericData: joi
          .object()
          .keys({
            dataItem: joi.array().items(
              joi
                .object()
                .keys({
                  key: joi.string().allow('').optional(),
                  value: joi.string().allow('').optional(),
                })
                .optional()
            ),
          })
          .optional(),
      })
      .optional(),
    module: joi 
      .object()
      .keys({
        country: joi.string().allow('').optional(),
        id: joi.string().allow('').optional()
        }).optional(),
    partner: joi
      .object()
      .keys({
        callbackUrl: joi
          .object()
          .keys({
            denial: joi.string().allow('').optional(),
            error: joi.string().allow('').optional(),
            success: joi.string().allow('').optional(),
          })
          .optional()
      })
      .optional(),
  })
  .optional()