//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { inject, provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence'
import { IStep } from '@services/workflowService/steps/step'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { IStepFactory } from '.'

// Importar Pasos
import { AUT0010 } from '@services/workflowService/steps/Rotatitvo/AUT0010/AUT0010'
import { BYC0000 } from '@services/workflowService/steps/Rotatitvo/BYC0000/BYC0000'
import { BYC0010 } from '@services/workflowService/steps/Rotatitvo/BYC0010/BYC0010'
import { DAT0010 } from '@services/workflowService/steps/Rotatitvo/DAT0010/DAT0010'
import { FELI0010 } from '@services/workflowService/steps/Rotatitvo/FELI0010/FELI0010'
import { INFO0010 } from '@services/workflowService/steps/Rotatitvo/INFO0010/INFO0010'
import { OTP0010 } from '@services/workflowService/steps/Rotatitvo/OTP0010/OTP0010'
import { PROD0010 } from '@services/workflowService/steps/Rotatitvo/PROD0010/PROD0010'
import { RESULT0010 } from '@services/workflowService/steps/Rotatitvo/RESULT0010/RESULT0010'
import { VIN0010 } from '@services/workflowService/steps/Rotatitvo/VIN0010/VIN0010'

// Final importar Pasos

@provide(TYPES.IStepFactory, true)
export class StepFactory implements IStepFactory {
  constructor(
    @inject(TYPES.IConfig) private config: IConfig,
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IPersistenceService) private persistence: IPersistenceService
  ) {}

  public get(stepData: IStepData, sessionData: WorkflowData): IStep {
    switch (stepData.stepId) {
      case STEP_ID.BYC0000:
        return new BYC0000(
          stepData,
          sessionData,
          this.config,
          this.logger,
          this.persistence
        )
      case STEP_ID.BYC0010:
        return new BYC0010(
          stepData,
          sessionData,
          this.config,
          this.logger,
          this.persistence
        )
      case STEP_ID.INFO0010:
        return new INFO0010(
          stepData,
          sessionData,
          this.config,
          this.logger,
          this.persistence
        )
      case STEP_ID.FELI0010:
        return new FELI0010(
          stepData,
          sessionData,
          this.config,
          this.logger,
          this.persistence
        )
      case STEP_ID.VIN0010:
        return new VIN0010(stepData, sessionData, this.config, this.logger)
      case STEP_ID.DAT0010:
        return new DAT0010(stepData, sessionData, this.config, this.logger)
      case STEP_ID.AUT0010:
        return new AUT0010(stepData, sessionData, this.config, this.logger)
      case STEP_ID.OTP0010:
        return new OTP0010(stepData, sessionData, this.config, this.logger) // this.persistence)
      case STEP_ID.PROD0010:
        return new PROD0010(stepData, sessionData, this.config, this.logger)
      case STEP_ID.RESULT0010:
        return new RESULT0010(stepData, sessionData, this.config, this.logger)
      default:
        return new BYC0000(
          stepData,
          sessionData,
          this.config,
          this.logger,
          this.persistence
        )
    }
  }
}
