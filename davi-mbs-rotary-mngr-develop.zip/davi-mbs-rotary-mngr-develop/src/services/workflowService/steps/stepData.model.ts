//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { PRODUCTO } from '~/models/enums/productoPais.enum'

export enum STATUS_ID {
  FINAL_PROCESO = 0, // NO SE USA EN DAVIPLATA
  NORMAL = 1,
  MENSAJE_CALLBACK = 2,
  MENSAJE = 3,
  RETOMA = 4,
  MENSAJE_POST = 5,
  MENSAJE_CANGURO = 6, // NO SE USA EN DAVIPLATA (ejemplo pop up de seguro)
  MENSAJE_BIOMETRIA = 7, // REDIRECCION BIOMETRIA INTERNA
  MENSAJE_CLAVE_CREADA = 8, // CLAVE CREADA
}

export enum STATUS_MSG {
  MSG_crrt_001 = 'catCRRT_MSG_VALIDACION_CUENTA', // no tiene Cuenta Ahorros ó Corriente
  MSG_crrt_002 = 'catCRRT_MSG_ASEGURABILIDAD', // Listas restrictivas lsita asegurabilidad
  MSG_crrt_003 = 'catCRRT_MSG_ACTUALIZACION_DATOS', // es necesario que actualice su información personal
  MSG_crrt_004 = 'catCRRT_MSG_DEF_ERROR', // Error generico
  MSG_crrt_005 = 'catCRRT_MSG_LISTAS_RESTRICTIVAS', // Error listas restrictivas
  MSG_crrt_006 = 'catCRRT_MSG_ERROR_LIMITE_INGRESOS', // Simulación no exitosa // TODO: VALIDA ERROR
  MSG_crrt_007 = 'catCRRT_MSG_PRODUCTO_MORA', // productos en Mora
  MSG_crrt_008 = 'catCRRT_MSG_AMOUNT_CREDITO_ROTATIVO', // Usted ya tiene este producto
  MSG_crrt_009 = 'catCRRT_MSG_ESTADO_SESION.EXPIRADO', // sesion expirada
  MSG_crrt_010 = 'catCRRT_MSG_SOLNEG', // Credito negado
  MSG_crrt_011 = 'catCRRT_MSG_VALIDACION_CUENTA', // Cliente sin productos validos
  MSG_crrt_012 = 'catCRRT_MSG_RETOMA', // retoma
  MSG_crrt_013 = 'catCRRT_MSG_MAX_NEGACIONES', // maximo negaciones
  MSG_crrt_014 = 'catCRRT_MSG_SIN_CAPACIDAD_PAGO_CANAL', // Negado, por capacidad de pago
  MSG_crrt_015 = 'catCRRT_MSG_ACERQUESE_OFICINA_CANAL', // Negado. Cliente No Tiene Cupo Disponible por Canal Digital
  MSG_crrt_016 = 'catCRRT_MSG_SOLICITUD_NO_APROBADA_CANAL', // Negado, no cumple con ingreso mínimo para producto
  MSG_crrt_017 = 'catCRRT_MSG_PRODUCTO_MORA_CANAL', // Productos Davivienda en Mora

  MSG_crrt_018 = 'catCRRT_MSG_OTP_SUPERO_INTENTOS', // Supera 3 intentos de otp
  MSG_crrt_019 = 'catCRRT_MSG_OTP_CODIGO_CADUCADO', // OTP caducado
  MSG_crrt_020 = 'catCRRT_MSG_OTP_INCORRECTO', // OTP incorrecto
}

export interface IStepData {
  clientId: string
  module?: PRODUCTO
  stepId: STEP_ID
  payload: any
  status?: STATUS_ID
}
