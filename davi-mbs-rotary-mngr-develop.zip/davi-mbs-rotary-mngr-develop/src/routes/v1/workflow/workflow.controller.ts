//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { TYPES } from '@config/ioc/types'
import { IResponse } from '@models/response.model'
import { ILogger } from '@services/loggerService'
import { IWorkflowService } from '@services/workflowService'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import * as express from 'express'
import { inject } from 'inversify'
import {
  controller,
  httpGet,
  httpPost,
  interfaces,
  next,
  request,
  response,
} from 'inversify-express-utils'
import joi from 'joi'
import { workflowRequestSchema } from './workflow.model'

@controller('/workflow')
export class WorkflowController implements interfaces.Controller {
  constructor(
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IWorkflowService) private workflow: IWorkflowService
  ) {}

  @httpPost('/')
  public async create(
    @request() req: express.Request,
    @response() res: express.Response,
    @next() nextFunc: express.NextFunction
  ) {
    this.logger.debug(
      'workflow rotativo: create REQUEST => ',
      JSON.stringify(req.body)
    )
    // Validación del formato del body
    const validationRequest = joi.validate(req.body, workflowRequestSchema)

    // Si la validación de los datos de la solicitud falla, entonces retornar error 422
    if (validationRequest.error) {
      this.logger.error(
        `POST /v1/workflow - Formato de request invalido: ${
          validationRequest.error
        } ${JSON.stringify(req.body)}`
      )
      const httpResponse: IResponse = {
        data: {},
        errors: ['invalid_data_on_request'],
      }
      res.status(422).json(httpResponse)
      nextFunc()
      return
    }

    const stepData: IStepData = {
      clientId: validationRequest.value.clientId,
      module: validationRequest.value.module,
      payload: validationRequest.value.payload,
      stepId: validationRequest.value.stepId,
    }

    let nextStep: IStepData

    try {
      nextStep = await this.workflow.getNextStep(stepData)
    } catch (error) {
      const statusCode = error.statusCode ? error.statusCode : 500
      const errorMessage = error.statusCode
        ? error.message
        : 'internal_server_error'

      this.logger.error(
        `POST /v1/workflow - getNextStep error: ${
          error.message
        } - internalError: ${
          error.internalError ? error.internalError.message : '--'
        }`
      )
      res.status(statusCode).json({
        data: {},
        errors: [errorMessage],
      })
      nextFunc()
      return
    }
    res.json({ data: nextStep, errors: [] })
    nextFunc()
  }

  @httpGet('/')
  public async ping(
    @request() req: express.Request,
    @response() res: express.Response,
    @next() nextFunc: express.NextFunction
  ) {
    res.json({ data: 'ok ping', errors: [] })
    nextFunc()
  }
}
