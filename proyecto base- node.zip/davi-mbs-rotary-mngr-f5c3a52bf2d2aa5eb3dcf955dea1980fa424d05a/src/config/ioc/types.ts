//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export const TYPES = {
  IAuthService: Symbol.for('IAuthService'),
  IConfig: Symbol.for('IConfig'),
  ICrypto: Symbol.for('ICrypto'),
  ILogNotificacionService: Symbol.for('ILogNotificacionService'),
  ILogger: Symbol.for('ILogger'),
  IPersistenceService: Symbol.for('IPersistenceService'),
  IPresentacionService: Symbol.for('IPresentacionService'),
  IStepFactory: Symbol.for('IStepFactory'),
  IWorkflowService: Symbol.for('IWorkflowService'),
}
