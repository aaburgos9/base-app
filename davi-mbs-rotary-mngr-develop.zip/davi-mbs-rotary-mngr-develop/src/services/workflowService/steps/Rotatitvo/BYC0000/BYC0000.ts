//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi from 'joi'
import moment from 'moment'
import { UTILITIES } from '~/utils/utilities'

const STEP: string = 'BYC0000'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    ip: joi.string().required(),
    llaveEncriptacion: joi.string().optional(),
  })
  .optional()

export class BYC0000 extends Step {
  private parmsData: any = {}
  private listaCiudadesCon: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger,
    private persistence: IPersistenceService
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData
    // tslint:disable-next-line: no-console
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de persistencia de datos recibidos del front
    this.sessionData.sesion.app.llaveEncriptacion = reqPayload.llaveEncriptacion
    this.sessionData.sesion.ip = reqPayload.ip

    // Lógica de obtención de parametros del step (BYC0000)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.BYC0000',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    // Flujo: Consulta de datos al proceso de biometria interna
    let dataProceso: boolean = false
    try {
      dataProceso = await this.consultaDataProcesoPROBIOINT()
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    this.logger.debug(
      `${STEP}:getNextStep - datos obtenidos del proceso de biometria interna (MBaaS 2.0): ${dataProceso} `,
      this.sessionData.sesion.clientId
    )
    // Flujo: El cliente tiene data en el proceso de biometria, y aprobo la validacion de biometriaInterna
    if (dataProceso) {
      if (this.sessionData.biometria.esRiesgoBajo) {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            userId: this.sessionData.sesion.presentacion.client?.userId,
          },
          status: STATUS_ID.NORMAL,
          stepId: STEP_ID.OTP0010,
        }

        return nextStep
      }

      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,
          kind: this.sessionData.dataProducto.moduloId,
          lenguaje: IDIOMA,
          modulo: this.parmsData.kind,
          pais: this.sessionData.dataProducto.country,
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          userId: this.sessionData.sesion.presentacion.client?.userId,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.PROD0010,
      }

      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > BYC0010 - Flujo`,
        this.sessionData.sesion.clientId
      )
      return nextStep
    }

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()

    // Flujo: La generación del token es exitosa, redirección a la pantalla Formulario
    this.logger.debug(
      `${STEP}:El userId enviado por canal es ${this.sessionData.sesion.presentacion.client?.userId} `,
      this.sessionData.sesion.clientId
    )
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        canal: this.sessionData.dataProducto.canalId,
        kind: this.sessionData.dataProducto.moduloId,
        lenguaje: IDIOMA,
        modulo: this.parmsData.kind,
        pais: this.sessionData.dataProducto.country,
        tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
        userId: this.sessionData.sesion.presentacion.client?.userId,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.BYC0010,
    }
    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > BYC0000 - Flujo Exitoso`,
      this.sessionData.sesion.clientId
    )

    // control de flujo
    this.sessionData.flujo.stepBYC0000 = true
    this.logger.debug(
      `${STEP}:getNextStep - estado control de flujo: `,
      this.sessionData.flujo.stepBYC0000
    )
    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

  private consultaDataProcesoPROBIOINT = async () => {
    const endpointUrl = `${
      this.config.getVars().back.procesoBiometriaInternaWorkflowServiceUrl
    }/data`

    const payload = {
      clientId: this.getClientId(),
    }

    this.logger.debug(
      `${STEP}:consultaDataProcesoPROBIOINT - Payload: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any
    try {
      serviceData = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valProcesoBiometriaInternaWfSvc = serviceData.data.data
    this.logger.debug(
      `${STEP}:consultaDataProcesoPROBIOINT -  Response: ${JSON.stringify(
        valProcesoBiometriaInternaWfSvc
      )}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    if (valProcesoBiometriaInternaWfSvc.flujo.stepProBioInt010) {
      if (
        valProcesoBiometriaInternaWfSvc.biometria.retoOtp.validacion
          .esValidacionExitosa
      ) {
        estatus = true
        this.sessionData.biometria.retoOtp.numero =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.numero
        this.sessionData.biometria.retoOtp.tipo =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.tipo
        this.sessionData.biometria.retoOtp.tokenOTP =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.generacion.tokenOTP
        this.sessionData.biometria.retoOtp.idTokenOTP =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.generacion.idTokenOTP
        this.sessionData.biometria.retoOtp.esValidacionExitosa =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.validacion.esValidacionExitosa
        this.sessionData.biometria.retoOtp.intentos =
          valProcesoBiometriaInternaWfSvc.biometria.retoOtp.validacion.intentos
      }
    } else if (valProcesoBiometriaInternaWfSvc.biometria.estatus) {
      estatus = true
      this.sessionData.biometria.estatus =
        valProcesoBiometriaInternaWfSvc.biometria.estatus
      this.sessionData.biometria.idAutenticacion =
        valProcesoBiometriaInternaWfSvc.biometria.idAutenticacion
      this.sessionData.biometria.idTransaccion =
        valProcesoBiometriaInternaWfSvc.biometria.idTransaccion
      this.sessionData.biometria.tipoReto =
        valProcesoBiometriaInternaWfSvc.biometria.tipoReto
      this.sessionData.biometria.fecha =
        valProcesoBiometriaInternaWfSvc.biometria.fecha
      this.sessionData.biometria.hora =
        valProcesoBiometriaInternaWfSvc.biometria.hora
      this.sessionData.biometria.semilla =
        valProcesoBiometriaInternaWfSvc.biometria.semilla
      // this.sessionData.sesion.presentacion.consumer.appConsumer.canalId =
      //   valProcesoBiometriaInternaWfSvc.sesion.presentacion.consumer.appConsumer.canalId
    } else if (
      valProcesoBiometriaInternaWfSvc.flujo.stepProBioInt000 &&
      valProcesoBiometriaInternaWfSvc.biometria.analisis.codigo ===
        this.parmsData.usuarioSinRiesgo
    ) {
      estatus = true
      this.sessionData.biometria.esRiesgoBajo = true
    }

    return estatus
  }
}
