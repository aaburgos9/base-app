//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { KIND } from '@models/enums/kind.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { TipoSesion } from '@models/sesion/sesion.model'
import { WorkflowData } from '@models/workflowData.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { PresentacionService } from '@services/presentacion/presentacionService'

jest.mock('@services/auth/authService')
jest.mock('@services/crypto/cryptoService')
jest.mock('@services/persistence/persistenceService')

// Crear mock Config
const mockConfigVars = {
  back: {
    authServiceUrl: 'http://mbaas/auth',
    persistenceServiceUrl: 'http://mbaas/persistence',
  },
  front: {
    url: 'http://mbaas/rotativo#',
  },
}

class MockConfig implements IConfig {
  public getVars = () => {
    return mockConfigVars
  }
}

describe('PresentacionService', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('info')
  const persistence = new PersistenceService(config, logger)
  const auth = new AuthService(config)
  const crypto = new CryptoService(auth, logger)
  const cryptoAux = new CryptoService(auth, logger)
  let presentacion: PresentacionService

  const mockLinkrotativo = 'lkjf12346uiop000'
  const mockJwe =
    'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IkhTMjU2In0.eyJjbGllbnQiOnsiZG9jdW1lbnRDbGllbnQiOnsibnVtYmVyIjoiMTExMjIyMzMzIiwidHlwZSI6IjAxIn0sImVtYWlsIjoibWFyaWFoZWxlbmFAZ21haWwuY29tIiwibmFtZSI6Ik1hcmlhIGRlbCBDYXJtZW4gSGVsZW5hIiwicGhvbmVOdW1iZXIiOnsiY291bnRyeUlkIjoiNTciLCJudW1iZXIiOiIzMTcyMjI0NDQ0In19LCJjb25zdW1lciI6eyJhcHBDb25zdW1lciI6eyJjYW5hbElkIjoiMzciLCJpZCI6IkJVTkRMRS0xIiwic2Vzc2lvbklkIjoiMTIzNDU2NzgtYWJjZC0xMjM0LWFiY2QtMTIzNDU2Nzg5MGFiIiwidGVybWluYWxJZCI6InRlcm0xMjM0IiwidHJhbnNhY3Rpb25JZCI6InQxMjM0NTYifSwiZGV2aWNlQ29uc3VtZXIiOnsiaWQiOiJkZXZpY2UtMTExMTExMjIyMjIiLCJpbmFjdGl2ZUludGVydmFsIjoiNjAwMDAiLCJsb2NhbGUiOiJDTyIsInJlc29sdXRpb24iOiI3NTAgeCAxMzM0Iiwic2Vzc2lvblRpbWVvdXQiOiI2MDAwMDAiLCJ1c2VyQWdlbnQiOiJNb3ppbGxhLzUuMCAoaVBob25lOyBDUFUgaVBob25lIE9TIDhfMiBsaWtlIE1hYyBPUyBYKSBBcHBsZVdlYktpdC82MDAuMS40Iiwidmlld1BvcnQiOiIzNzUgeCA2NjcifSwiZ2VuZXJpY0RhdGEiOnsiZGF0YUl0ZW0iOlt7ImtleSI6InRva2VuRnJvbnRlbmQiLCJ2YWx1ZSI6IlhYWFhYWFhYWFhYWCJ9XX19LCJwYXJ0bmVyIjp7ImNhbGxiYWNrVXJsIjp7ImVycm9yIjoiaHR0cHM6Ly93d3cuZGF2aXZpZW5kYS5jb20vZXJyb3IiLCJzdWNjZXNzIjoiaHR0cHM6Ly93d3cuZGF2aXZpZW5kYS5jb20ifSwiaWQiOiJMTSJ9LCJwcm9kdWN0Ijp7ImNvdW50cnkiOiJDTyIsImlkIjoiV0VCQ0hFQ0tPVVQifX0.WZzW5pzp7-n7vBVP_1hX4t0W-lexMMDleDqcg6ZkUiE'

  const mockStepPayload = {
    client: {
      documentClient: {
        number: '111222333',
        type: '01',
      },
      phoneNumber: {
        countryId: '',
        number: '',
      },
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        terminalId: 'term1234',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        inactiveInterval: '60000',
        locale: 'CO',
        resolution: '750 x 1334',
        sessionTimeout: '600000',
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
        viewPort: '375 x 667',
      },
      genericData: {
        dataItem: [
          {
            key: 'tokenFrontend',
            value: 'XXXXXXXXXXXX',
          },
        ],
      },
    },
    linkrotativo: 'qwert4567999',
    montoProducto: '300000,00',
    nombreProducto: 'ZAPATOS',
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      },
      id: 'LM',
    },
    product: {
      country: 'CO',
      id: 'rotativo',
    },
  }

  const mockStepPayloadAux = {
    client: {
      documentClient: {
        number: '111222333',
        type: '01',
      },
      phoneNumber: {
        countryId: '',
        number: '',
      },
    },
    consumer: {
      appConsumer: {
        canalId: '37',
        id: 'BUNDLE-1',
        sessionId: '12345678-abcd-1234-abcd-1234567890ab',
        terminalId: 'term1234',
        transactionId: 't123456',
      },
      deviceConsumer: {
        id: 'device-11111122222',
        inactiveInterval: '60000',
        locale: 'CO',
        resolution: '750 x 1334',
        sessionTimeout: '600000',
        userAgent:
          'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
        viewPort: '375 x 667',
      },
      genericData: {
        dataItem: [
          {
            key: 'tokenFrontend',
            value: 'XXXXXXXXXXXX',
          },
        ],
      },
    },
    partner: {
      callbackUrl: {
        error: 'https://www.davivienda.com/error',
        success: 'https://www.davivienda.com',
      },
      id: 'LM',
    },
    product: {
      country: 'CO',
      id: 'rotativo',
    },
  }

  const mockStepPayloadVacioAux = {
    number: '111222333',
  }

  test('Presentacion instancia correctamente', () => {
    presentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )
    expect(presentacion).toBeDefined()
  })

  test('Presentacion de producto valido | Linkrotativo (OK) -> creo sesion ok', async (done) => {
    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockLinkrotativo)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }

    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: mockJwe })
      expect(sesion).toBeDefined()
      expect(wfData.sesion.tipo).toEqual(TipoSesion.PRODUCTO)
      expect(persistence.setData).toHaveBeenCalledWith(
        KIND.rotativo,
        sesion.clientId,
        jasmine.any(WorkflowData)
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('Presentacion de producto valido | Linkrotativo (Vacio) -> creo sesion ok', async (done) => {
    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockLinkrotativo)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }

    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayloadAux)
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: mockJwe })
      expect(sesion).toBeDefined()
      expect(wfData.sesion.tipo).toEqual(TipoSesion.PRODUCTO)
      expect(persistence.setData).toHaveBeenCalledWith(
        KIND.rotativo,
        sesion.clientId,
        jasmine.any(WorkflowData)
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('Presentacion con formato inválido -> retorno error 422', async (done) => {
    // mock de respuesta de crypto con desencriptacion de datos de payload
    cryptoAux.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayloadVacioAux)
    )

    // mock de tipo de documento a vacio para forzar error
    const jweConError =
      'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.e5C2fwFKescXJt3bQqFST4fPmeD2y8FO7ZJRygRpXYakQVTnZp17X_l4DJq7HQhAv0CAIC-PDKNcyGKbCrqEcdMooDljzN6U3Icj9RN-nmGyIM119C6ZCQC3o0UyjegNg5rqHSUoftXxmnIMPEEzFNfede-WeKaMfhjal5ANfzhUSrmkK0HVHqC90YBGkhe_4VpUdr_l2rig4a7SYfAaSb8KTFcZXzbUvl-UaeE56RE0ty8d5jUtw50t7RmvZ_oEY6mNbUkItUpSbtkdNkSJw4fCUIkhONJAx__Aa6xsW8U0JT5uam6d6NFBueef5E7ibNro9mYvJDHCMiAgir0AvA.aY4ujedg1b7_9e7yoHjXxA.-F83QcPoMqrb_gYD8Ch7gAhKqTRfEEdzZqITdFMhOGCOj2_s0GB85v5q4d8oGKnqcXkW_MJd0RoTI2Pvz4CXk7s-ORbh53PWaxdd8RQ4lvvA1qucRgI2bfYXmg_LK7Ot5Zehn5SbF6C3jdChkz5eHgeJ15LuwxEsxdoJ3njGpb3GHXXPHfr6X9D_-yHshux29EqB9gnvvlRMrHw7rLTmGt6WCXSj0Di1VcXN9HtcdhQdSWsVKYyGUXhLYR5B5g_7pRvhYZramIU3mHrUTt3ILYbEo6p1-ifppq2fm9YLnvqlgn02FHGN_6rECeDi_CSlH3R8WBTf-wpT18UI0SCAhw8Jsx2HFCTzW3wtN0iTiSQA1poz0WCbWN-Y8mtfVflCl0XDCIu5ebdZIiTVVcd9TdD1aAVgzBfTKUw7lIusiSolEJ8hKZPC3IjMY8s5I5oxjUDjsDdbILeIN285Pm6ftTkLiFplvC30_kOuG2DONHhHX47JewZZV76rc-E6-5K6OdZpeQt-HtQPrRY2DWaEI4eSDpcvgE7FRicoSKsQv0OtRwlWPjrjsGNZoeNNt7WerPYiuhChF_Nk5_-X74sgbcFdlejSFSPJ6K6qNoT6bHgZ4r_UdMbFRzbwvw10Bxm4ZQ9SfkTei2i57LShTNahp_oS-bLpOvIhvtKXAxBbYVab2wl1RWZ0UKhWxDhAqy7M9StQs3fCiT7YQQxJV9GD0zcUBXfYPlXdnX6RV6P2Ay26cz70brKgu0Kzo93P-DYmZMi_76KPIIBQm-k3HdwwhQZ03axKbHgYb7LcSHybs0y7VTKgliZmqueNRADvmXQMWp5ZWdjjXdzH1_enInrwQdE3AV8WuBZ17sReSbw4WuA9DEsy5tmxDazGlPKUAdj64X0wDc-iWS5plAXql_ewIwhhdvBmqfBSf1U_VZ1ZwrvBjgOVHlYg12npROWx9FcsNMUxnVEk7aBtRILM8rCHz1OJLe_jeHQb62t_hmT8JhN4lvwHA3l0sYJHLTU-S32TOzDCokqe0-LmSKdZdImMKbQ_rbe_CLT6TpURstR1B0qpp_kw-7wxQ2YpQncZArPsiYtPnIisAv0Q7ZNHs_i4oz4NbzX_BtvgYq4Mb40W-LVBva7xYF8QyqichHKvWAjJOJpxRrt8p-SH0iQpIa5CEk9hmOulIUAH8jCRA_3bFRTRJy9BE4g-1Qq64dCaaDxtk36OSkjiroUb2A6lhrTUndpVkSVETMrPQp5avBDPLLcE6pFRLIjGsjCKCJAu3OeSbFhxQXKGQnFSpVZfMqoyjw.gbx6-Nd7qnibJWaqTE9KA3cAnLvTZEf2p8cTPN7YxZE'

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      cryptoAux
    )

    try {
      const sesion = await localPresentacion.crear({ data: jweConError })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      // expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  test('Datos de parametro con JWE inválido -> retorno error 422', async (done) => {
    // mock de tipo de documento a vacio para forzar error
    const jweConError =
      'FAKE-FAKElbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiMTU1MzEzMzAwNiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.MzTRQQXtL5-J_8BnaZHdrKRMohULqrQub3n6y_T3CZx4q5Gq-bA6cYMP-VRKpLhNeEkDjDSus25LbhxbxkNQa8BM_P0IqhcD4D4BePjEwOc9bz0mZsaSNMk8ag_ypqrjQgcGGKuq13xW1g8U_w343fHYjQxxh0RpLjUdHjqTxL4FfCMg_cHuiKA9BSY0h-W69aWGQnxM0kU7ryw3GGlElQNsAEwrFtGVNre9BjRDdfwYI-km_a58xjWuWFRMiVDhSChySnjDa3mmhFedTzpY5frKn_K9HRHUeUuw5l5sHe4abHXLpI7UvxEEAFlBWAbhhdoL7diTEGROTBE8vaZSgQ.DNV-89rCqr60QeS8L_qmkQ.X9DOnGKwkHg-GUetE-h3ENBGP8Oy18bt9BZ1MLzbXGvSLnhnLDFv1HdCiPeyQgM6d3-6YuvzxUw5uJcoZGQZECoNZb4J54n3uO8NpDkRMNhRE_JMYGT8Jyu47X1Z5Mg1o_yRExmjtDmzzFYyonFQvRFAnTAx0TLh5HIIAP_OA0V6PrufEeMnQC-JHwM2Xff0PZkD44-OUesp4ZvOMQ5NDGZNaF6vbNRNR3cTYXahQG9zyk2M6DnR97P1r9JzbPWFeah7LV-jBLDYN0ZorHphoA.nSjl1wXNd7Gso6WMoJovRBBNATW1Q4KAOKF9iSVXRSE'

    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockLinkrotativo)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }

    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.reject(new Error('upsss'))
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: jweConError })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  test('Error en servicio de persistencia -> retorno error 500', async (done) => {
    // mock de auth
    auth.createOtp = jest.fn((clientId: string) =>
      Promise.resolve(mockLinkrotativo)
    )

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }
    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de persistencia
    persistence.setData = jest.fn((kind: string, k: string, d: any) =>
      Promise.reject(new Error('ups-en-persistencia'))
    )

    const localPresentacion = new PresentacionService(
      config,
      logger,
      persistence,
      auth,
      crypto
    )

    try {
      const sesion = await localPresentacion.crear({ data: mockJwe })
      expect(sesion).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('ups-en-persistencia')
      done()
    }
  })
})
