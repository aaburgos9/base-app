//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi from 'joi'
import moment from 'moment'
import uuid = require('uuid')

const STEP: string = 'beneficiosCaracteristicasStep'
const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    ipAddress: joi.string().required(),
    llaveEncriptacion: joi.string().optional(),
  })
  .optional()


export class BeneficiosCaracteristicasStep extends Step {
  private parmsData: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de persistencia de datos recibidos del front
    this.sessionData.sesion.app.llaveEncriptacion = reqPayload.llaveEncriptacion

    // Lógica de obtención de parametros del step (rotativo000)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.beneficiosCaracteristicasStep',
        `canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()

    // Lógica del step
    try {
      this.logger.error(
        `${STEP}:getNextStep - error ${JSON.stringify(
          'try'
        )} `,
        this.sessionData.sesion.clientId
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    let nextStep: IStepData
    // Flujo: La generación del token es exitosa, redirección a la pantalla de 'Ingrese sus Datos'
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.rotativo010,
    }

    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > rotativo010 - Flujo`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */
  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

}
