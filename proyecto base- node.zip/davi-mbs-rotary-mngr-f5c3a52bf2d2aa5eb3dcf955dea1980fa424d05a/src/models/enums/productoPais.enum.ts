//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum PAIS {
  CO = 'CO',
}

export enum PRODUCTO {
  rotativo = 'rotativo',
}

export enum PRODUCTO_PAIS {
  rotativo_CO = 'rotativo_CO',
}
