//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { TYPES } from '@config/ioc/types'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IAuthService } from '@services/auth'
import { ILogger } from '@services/loggerService'
import { inject } from 'inversify'
import { provide } from 'inversify-binding-decorators'
import { JWE, JWK, util } from 'node-jose'
import { ICryptoService } from '.'

@provide(TYPES.ICrypto)
export class CryptoService implements ICryptoService {
  constructor(
    @inject(TYPES.IAuthService) private auth: IAuthService,
    @inject(TYPES.ILogger) private logger: ILogger
  ) {}

  public encryptJwe = async (encryptKey: string, payload: any) => {
    // convertir key a JWK y crear encryptor
    let jweToken
    let encryptor
    try {
      const jwkKey = await JWK.asKey(encryptKey)
      encryptor = JWE.createEncrypt(
        {
          contentAlg: 'A256CBC-HS512',
          fields: {
            kid: jwkKey.kid,
          },
          format: 'compact',
        },
        jwkKey
      )
      // Encriptar payload y retornar JWE
      jweToken = await encryptor.update(JSON.stringify(payload)).final()
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, new Error('Error al crear o encriptar con JWE Encryptor'))
    }

    return jweToken.toString()
  }

  public decryptJwe = async (jweToken: any) => {
    // Intento extraer el protected header
    const tokenParts = jweToken.split('.')

    // Obtengo el kid de la llave usada para encriptar
    const header = JSON.parse(util.base64url.decode(tokenParts[0]).toString())
    const kid = header.kid

    this.logger.debug(`Crypto: rotativo > Inicio - Decrypt JWE: ${JSON.stringify(header)}`)

    // busco llave en keystore y creo decryptor e intento desencriptar el JWE
    try {
      let privateKey
      let decryptedPayload
      privateKey = await this.auth.getKey(kid, 'enc')
      const decryptor = JWE.createDecrypt(privateKey)
      decryptedPayload = await decryptor.decrypt(jweToken)
      return JSON.parse(decryptedPayload.payload.toString('binary'))
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.invalid_data_format, error)
    }
  }
}
