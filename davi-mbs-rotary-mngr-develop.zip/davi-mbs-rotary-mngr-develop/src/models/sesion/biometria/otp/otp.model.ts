//
// Copyright (C) 2022 - Banco Davivienda S.A. y sus filiales.
//

export class RetoOtpData {
  /*
   * Atributos
   */
  public numero: string = ''
  public tipo: string = ''
  public tokenOTP: string = ''
  public idTokenOTP: string = ''
  public esValidacionExitosa: boolean = false
  public intentos: string = ''

  /*
   * Metodo constructor (inicialización) de la clase RetoOtpData
   */
  constructor(
    numero: string,
    tipo: string,
    tokenOTP: string,
    idTokenOTP: string,
    esValidacionExitosa: boolean,
    intentos: string
  ) {
    this.numero = numero
    this.tipo = tipo
    this.tokenOTP = tokenOTP
    this.idTokenOTP = idTokenOTP
    this.esValidacionExitosa = esValidacionExitosa
    this.intentos = intentos
  }
}
