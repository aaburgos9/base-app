//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { JWE, JWK } from 'node-jose'

jest.mock('@services/auth/authService')

// Crear mock Config
class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        authServiceUrl: 'http://auth-service/api',
      },
    }
  }
}

describe('CryptoService', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('info')
  const auth = new AuthService(config)
  let crypto: CryptoService

  const mockData = {
    encKey:
      '{"kty": "RSA","kid": "1553133006","use": "enc","alg": "RSA-OAEP-256","key_ops": ["encrypt","wrap","verify"],"e": "AQAB","n": "lEkhmX7QqUGzA0efqo6tmdhLN0RwvNGIjZmDOE4DXuZjFGNWHrTlbNhqUXebwuRRHJBxM3JB-C0s2Fd6qvI9oduYs1dQBBUtiDeH6TUvYmdTlLDBytCGDUN4Aup5G6S3CEeSOmboi48CroVmMqAE1FXLQEF35bgFSdyt_87B5bqIfLTvcna8FQ2OT7O_wlQcmt4OtOAVxRtDm1cr92A8VfhXZ_fgb7aKQBhmULt22_dHcjc2bylCj0cjfBeKAf_UDgDHNK324B_kipurcMvY53sMWzKemweIsb1UnRKAKX68b6QXa5xu-VjuS3obo7to4DIBIBpXAtdHQJeYSKXBqw","d": "O80abcrE392NEh-KdsA_prGh89H4HU3rYh-s2cIsfdMv1gMRsiSF-dV1WxF_kaN-SqS94l-L10hws3bkE5jJ3kKvXHQz4tGfoTWz7Ar05xyAipCWNvLNfP_eoF5rJQjSf9ZNVJw34EB2dmd6BaSfDfrjkzBT6CLEjzseOPHrJHftfIBw5LoBlhreo6sgzg_AtD_s9zvMQvyUdAAyFEdpmweRtqwO0VatfETArAj7r7mG0T_PMpx1m4tR1rD_LA0fmt_OlGzNiYKdu3oXpkup1kuGItANetz4-nJq2s0Ok02CMABo4Bt3433oYSrKgIhwmjSidZ1RNUl5gJDI5nY00Q","p": "2egk333r7XFzY6G5g3_5DjjFCDBmPJb0D_GTgcFICPyGOyfHUjf9N63zOg4TEEt50osXk75ZlUa_ya7rXSkgCrE88sv8ii1_zJzxclHMie9bJQcAgDKvqs-9hfMEveUHkFYD_tbPEX0NxGMz3EY8GQNhhAx3hi7AZatK-omOsPU","q": "rjVF36tJyr6GV48jvq3Jd_-4lIqNJc7avwnctkaB6g-ljhPtUg3nogGIDrXnnSrBnwd87Sb7uf3Dcs99NZLhasnkiOoQlHInc9Pw0qjB-cWb3EOme6yu2SRucnYjSX_W87aSKLuBBTyykoFcAWGxICSsGgaP5pi_HmQrVySghB8","dp": "nh76QsLZJF-i37VHLMj8LPm84Ahe57CSQc-Gvi1G3F6B-QMQe_Ts5i5vxLzZ0IU0TTdpUGhcERpZqTwoxl1FRvz9wSGMi6ggiJWKDu6UgbMSbHf8QQqGtmgwmraRxkofhvkjxRSTBZm9F7j0tO6yRWRSqsNxKAlcy2nU6qBOztE","dq": "np-PYhw7csqM1MlXSNZBLmzAizClWRnDAFRgjfAhdxiMLJRkcWSL124BjzN_FBLMfpt42w-2AiLYhn_7iH6Xln8DAs_uDNzso4EGNSrIhT-zrZpDyzTveHS9xKdhdhlbhkplR4WD81rTVqdHOVLUz2nU81WqTdQjoe6fsBd_uQ0","qi": "M5vcrNqbMMdU2Y1VJEnto4PBWjzNlQHiTuVVn4jPLbLdqRV4JzjYxF3ApHbUXzha8nfFk0qwJH5POLPfnzcZJyLwyJJbjXiIwaF1436kir0LeFn-vQNF-bZCmudL68eFE0GyDO2-rlgVSM8hawqi2m9Xz57XMr5XsgfP1U7QTEU"}',
    jweToken:
      'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.Qa78LICUC5PTo5djOYiqCbr8PAnqccVp7prezVfp-pO8BSpP9U7lXzmR4KrRjSKMqCzyBpycn4y00B6QuhyefIXT4KB6CVQFT6ClhsXqUdGpt5fkuD-pfMYE6FAp1P0UQQJOZK7AL-1VSmYtvffMKraKSL9RnQYi49tAHLzC3X1r20F92C6DgOhBcxjmwNGJPYqkR1ZeXfRdT34dTvfN6iHd3irAsko5UxSdQZyhQjPmySdAmFONOWiM8yf_PoE794_NJHPhnCefB0Nd5wzAwpXFsdFpxBDpOw4FwYPflgIEJ5KsNVoDBnq4MUTYcn8D6Ipam1_2_4JQjN9ojQTEzw.QsdRcf02KrD0Vn9L_SYrsw.sBMkS9Blo7bbA3PBJiuwSa842Wj5KYlK8w5gnzvbz2d8np7aLKVXxS1FJoaqI5Uo.H0G319PAsKfATvvKMMizNN7vnvQ5fz8xwVVWUfTVSew',
    payload: {
      campo1: 'hola',
      campo2: 'mundo',
    },
  }
  let jweToken: string

  test('Instancia correctamente', () => {
    crypto = new CryptoService(auth, logger)
    expect(crypto).toBeDefined()
  })

  test('Encripta correctamente', async (done) => {
    try {
      const jwe = await crypto.encryptJwe(mockData.encKey, mockData.payload)
      expect(jwe).toBeTruthy()
      jweToken = jwe
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('Desencripta correctamente', async (done) => {
    try {
      const payload = await crypto.decryptJwe(mockData.jweToken)
      expect(payload).toBeTruthy()
      expect(payload).toEqual(mockData.payload)
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('Encripta con error en JWK.asKey retorna error 500', async (done) => {
    // mock de JWK
    JWK.asKey = jest.fn(() => Promise.reject(new Error('ups-en-asKey')))
    /*JWK.asKey = jest.fn((encKey: string) =>
      Promise.reject(new Error('ups-en-asKey'))
    )*/

    try {
      const jwe = await crypto.encryptJwe(mockData.encKey, mockData.payload)
      expect(jwe).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      done()
    }
  })

  // REVISAR PORQUE NO FUNCIONA JWK.asKey
  /*test('encripta con error en encryptor.update retorna error 500', async done => {
    // mock de JWK
    JWK.asKey = jest.fn((encKey: string) =>
      Promise.resolve(new Error('internal_server_error'))
    )

    try {
      const jwe = await crypto.encryptJwe(mockData.encKey, mockData.payload)
      expect(jwe).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      done()
    }
  })*/

  test('Desencriptar con error en auth.getKey retorna error 422', async (done) => {
    // mock de auth
    auth.getKey = jest.fn((clientId: string) =>
      Promise.reject(new Error('ups-en-getKey'))
    )

    try {
      const payload = await crypto.decryptJwe(mockData.jweToken)
      expect(payload).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })

  // REVISAR PORQUE NO FUNCIONA auth.getKey Y JWE.createDecrypt
  /*test('desencriptar con error en JWE.createDecrypt retorna error 422', async done => {
    // mock de auth
    auth.getKey = jest.fn((kindId: string, clientId: string) => Promise.resolve(true))
    // mock de JWE
    JWE.createDecrypt = jest.fn((privateKey: string) =>
      Promise.resolve(new Error('ups-en-createDecrypt'))
    )

    try {
      const payload = await crypto.decryptJwe(mockData.jweToken)
      expect(payload).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      done()
    }
  })*/
})
