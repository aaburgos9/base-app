//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IKey } from '@services/auth/key.model'
import { Dictionary } from '@utils/dictionary'
import axios from 'axios'
import { inject } from 'inversify'
import { JWK } from 'node-jose'
import { IAuthService } from '.'

@provide(TYPES.IAuthService)
export class AuthService implements IAuthService {
  public keystoreCache = new Dictionary<IKey>()

  constructor(@inject(TYPES.IConfig) private config: IConfig) {}

  /**
   * Llama al endpoint OTP del Auth_service y retorna el OTP creado.
   */
  public createOtp = async (clientId: string, productAux: string) => {
    const endpointUrl = `${this.config.getVars().back.authServiceUrl}/otp`
    let serviceResponse
    try {
      serviceResponse = await axios.post(endpointUrl, {
        payload: {
          product: `${productAux}`,
        },
        subject: clientId,
      })
    } catch (err) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, err)
    }
    if (serviceResponse.status !== 200) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(
          JSON.stringify({
            data: serviceResponse.data,
            status: serviceResponse.status,
          })
        )
      )
    }
    return serviceResponse.data.data.token
  }

  /**
   * Obtiene key desde keystore
   */
  public getKey = async (kid: string, use: string) => {
    // buscar en cache
    const keyId = `${kid}_${use}`
    const cachedKey = this.keystoreCache.get(keyId)
    const nowTime = Math.floor(new Date().getTime() / 1000)

    // si está en caché y aun sin expirar entonces retornar este valor
    if (cachedKey && cachedKey.exp > nowTime) return cachedKey.jwk

    // caso contrario buscarla en el keystore
    const endpointUrl = `${
      this.config.getVars().back.authServiceUrl
    }/keystore/jwk/${kid}/${use}`
    let serviceResponse
    try {
      serviceResponse = await axios.get(endpointUrl)
    } catch (err) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, err)
    }
    if (serviceResponse.status === 404) {
      throw new ServiceError(
        MBAAS_ERRORS.data_not_found,
        new Error(
          JSON.stringify({
            data: serviceResponse.data,
            status: serviceResponse.status,
          })
        )
      )
    }
    if (serviceResponse.status !== 200 && serviceResponse.status !== 404) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(
          JSON.stringify({
            data: serviceResponse.data,
            status: serviceResponse.status,
          })
        )
      )
    }
    // agregar key a caché
    const jwkKey = await JWK.asKey(serviceResponse.data.data)
    const newKey: IKey = {
      exp: Math.floor((new Date().getTime() + 3600000) / 1000),
      jwk: jwkKey,
    }
    this.keystoreCache.set(keyId, newKey)
    return jwkKey
  }

  /**
   * Llama al endpoint Blacklist del Auth_service para anular un token de refresco.
   */
  public endSession = async (clientId: string) => {
    const endpointUrl = `${
      this.config.getVars().back.authServiceUrl
    }/keystore/blacklist/rtnbl/${clientId}`
    let serviceResponse
    try {
      serviceResponse = await axios.put(endpointUrl, {
        client_id: clientId,
        exp: Math.floor(
          (new Date().getTime() + 10 * 24 * 60 * 60 * 1000) / 1000
        ).toString(),
        jti: clientId,
      })
    } catch (err) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, err)
    }
    if (serviceResponse.status !== 200) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(
          JSON.stringify({
            data: serviceResponse.data,
            status: serviceResponse.status,
          })
        )
      )
    }
    return true
  }

  /**
   * Llama al endpoint Blacklist del Auth_service para obtener el certificado de encriptacion.
   */
  public getCertificate = async (certificateId: string) => {
    const endpointUrl = `${
      this.config.getVars().back.authServiceUrl
    }/keystore/certificate/${certificateId}`
    let serviceResponse
    try {
      serviceResponse = await axios.get(endpointUrl)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    if (serviceResponse.status === 404) {
      return null
    }
    if (serviceResponse.status !== 200) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(
          JSON.stringify({
            data: serviceResponse.data,
            status: serviceResponse.status,
          })
        )
      )
    }
    return serviceResponse.data.data
  }
}
