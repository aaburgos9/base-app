//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { BeneficiosCaracteristicasStep } from '~/services/workflowService/steps/Rotatitvo/beneficiosCaracteristicasStep/beneficiosCaracteristicasStep'
// Importar implementaciones de pasos
import { IStepFactory } from '.'
import { StepFactory } from './stepFactory'

jest.mock('@services/persistence/persistenceService')

// Mock de config y datos de sesion
class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {},
    }
  }
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      expeditionCity: '16911001',
      expeditionDate: '15/12/2000',
      number: '1234567890',
      type: '01',
    },
    email: 'usuario@correo.com',
    name: 'Helena Maria Lopez Perez',
    phoneNumber: {
      countryId: '57',
      number: '3124451512',
    },
  },
  consumer: {
    appConsumer: {
      canalId: '48',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      terminalId: 'term1234',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      inactiveInterval: '60000',
      locale: 'CO',
      sessionTimeout: '600000',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko)',
    },
    genericData: {
      dataItem: [
        {
          key: 'tokenFrontend',
          value: 'xxxxxxxxxxxx',
        },
      ],
    },
  },
  partner: {
    callbackUrl: {
      error: '',
      success: '',
    },
    id: '',
  },
  product: {
    country: 'CO',
    id: 'rotativo',
  },
}

const mockWfData = new WorkflowData(mockPresentacion, '', 0)
const config = new MockConfig()
const logger = new LoggerStub('info')

describe('StepFactory', () => {
  let steps: IStepFactory

  test('Factory instancia correctamente', () => {
    steps = new StepFactory(config, logger)
    expect(steps).toBeDefined()
  })

  test('BeneficiosCaracteristicasStep instancia correctamente', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.rotativo000,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(BeneficiosCaracteristicasStep)
  })

  test('Paso desconocido instancia BeneficiosCaracteristicasStep', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.PENDIENTE,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(BeneficiosCaracteristicasStep)
  })

  test('rotativo010 instancia correctamente', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(BeneficiosCaracteristicasStep)
  })
})
