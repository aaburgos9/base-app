//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import joi from 'joi'

// Esquema de validación para requests de Presentacion de Clientes
export const presentacionRequestSchema = joi
  .object()
  .keys({
    data: joi.string().required(),
  })
  .optional()
