//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { DocumentoData } from '@models/sesion/documento/documento.model'
import { FlujoData } from '@models/sesion/flujo/flujo.model'
import { OtpData } from '@models/sesion/otp/otp.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { SesionData } from '@models/sesion/sesion.model'

export class WorkflowData {
  /*
   * Atributos
   */
  public documento: DocumentoData
  public otp: OtpData
  public accessToken: string = ''
  public expiracionToken: number = 0
  public flujo: FlujoData
  public sesion: SesionData // TODO: REFINAR MODELO DE SESION

  /*
   * Metodo constructor (inicialización) de la clase WorkflowData
   */
  constructor(
    presentacionCliente: IPresentacionClientes,
    accessToken: string,
    expiracionToken: number
  ) {
    this.documento = new DocumentoData('', '')
    this.otp = new OtpData('', 0, '', false, '', false)
    this.accessToken = accessToken
    this.expiracionToken = expiracionToken
    this.flujo = new FlujoData(false)
    this.sesion = new SesionData(presentacionCliente, '', '', '')
  }
}
