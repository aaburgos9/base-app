//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import joi from 'joi'
import { PRODUCTO } from '~/models/enums/productoPais.enum'

// Esquema de validación para requests de workflow
export const workflowRequestSchema = joi
  .object()
  .keys({
    clientId: joi.string().allow('').required(),
    module: joi.string().optional().allow('').default(PRODUCTO.rotativo),
    payload: joi.string().required(),
    status: joi.number().optional(),
    stepId: joi.string().required(),
  })
  .required()
