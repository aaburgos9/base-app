//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface IDictionary<T> {
  set(key: string, value: T): void
  containsKey(key: string): boolean
  count(): number
  get(key: string): T
  keys(): string[]
  remove(key: string): T
  values(): T[]
}

export class Dictionary<T> implements IDictionary<T> {
  private ITEMS: { [index: string]: T } = {}
  private COUNT: number = 0

  public containsKey(key: string): boolean {
    return this.ITEMS.hasOwnProperty(key)
  }

  public count(): number {
    return this.COUNT
  }

  public set(key: string, value: T) {
    if (!this.ITEMS.hasOwnProperty(key)) {
      this.COUNT += 1
    }
    this.ITEMS[key] = value
  }

  public remove(key: string): T {
    const val = this.ITEMS[key]
    if (val) {
      delete this.ITEMS[key]
      this.COUNT -= 1
    }
    return val
  }

  public get(key: string): T {
    return this.ITEMS[key]
  }

  public keys(): string[] {
    const keySet: string[] = []

    // tslint:disable-next-line: forin
    for (const prop in this.ITEMS) {
      // ACTIVAR EN CASO DE IMPLEMENTAR dictionary.ts
      // if (this.ITEMS.hasOwnProperty(prop)) {
      keySet.push(prop)
      // }
    }

    return keySet
  }

  public values(): T[] {
    const values: T[] = []

    // tslint:disable-next-line: forin
    for (const prop in this.ITEMS) {
      // ACTIVAR EN CASO DE IMPLEMENTAR dictionary.ts
      // if (this.ITEMS.hasOwnProperty(prop)) {
      values.push(this.ITEMS[prop])
      // }
    }

    return values
  }
}
