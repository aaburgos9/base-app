//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { ESTADO_SESION } from '@models/enums/estadoSesion.enum'
import { EstadoAppData } from '@models/sesion/estadoApp.model'
import { EstadoWorkflowData } from '@models/sesion/estadoWorkflow.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { string } from 'joi'
import uuid = require('uuid')

export enum TipoSesion {
  PRODUCTO,
}

export class SesionData {
  /*
   * Atributos
   */
  public clientId: string = ''
  public tipo: TipoSesion
  public presentacion: IPresentacionClientes
  public workflow: EstadoWorkflowData
  public app: EstadoAppData
  public estado: ESTADO_SESION
  public fechaExpiracion: string = ''
  public expiracionSesion: string = ''
  public ultimaAccion: string = ''
  public ip: string = ''
  public listasRestrictivas: any
  public grabarInfoSol: any
  public consultaClientePN: any
  public consultaProducto: any
  public seguroVoluntario: any
  public consultaTasaSimulador: any
  public evaluadorPCO: any
  public vinculacion: any
  public autenticacionLiviana: any
  public total: string = ''
  public crearSolicitud: any
  public consultaPersistencia: any
  public crearPagareDigital: any
  public crearCuentaDigital: any
  public datosFormulario: any
  public aprobacionCredito: any
  public cuentaRotativo: any
  public cuentaDebito: any
  public autorizacionDebitoAuto: boolean = false

  /*
   * Metodo constructor (inicialización) de la clase SesionData
   */
  constructor(
    presentacionCliente: IPresentacionClientes,
    fechaExpiracion: string,
    expiracionSesion: string,
    ultimaAccion: string,
    autorizacionDebitoAuto: boolean,
    ip: string,
    total: string,
    listasRestrictivas = {
      tipoOperacionLog: '',
      tipoPersona: '',
    },
    grabarInfoSol = {
      estadosDeLaSolicitud: '',
      motivoRechazo: '',
      nroProceso: '',
      plazoCredito: '',
      valorSolicitado: '',
    },
    consultaClientePN = {
      ciudad: '',
      ciudadConDepartamento: '',
      ciudadDI: '',
      ciudadExpedicion: '',
      departamento: '',
      departamentoDI: '',
      direccionDI: '',
      email: '',
      esCliente: false,
      fechaExpedicionCLI: '',
      fechaNacimientoCLI: '',
      ingresos: '',
      lugarExpedicionCLI: '',
      nombres: '',
      numeroCel: '',
      oficinaRadicacionCLI: '',
      primerApellido: '',
      scorePrecioCliente: '',
      segundoApellido: '',
      sexoCLI: '',
      tipoContratoAL: '',
      tipoOperacionLog: '',
      valIngresoEspecialistaCLI: '',
    },
    consultaProducto = {
      registros: [
        {
          numeroCuenta: '',
          tipoCuenta: '',
        },
      ],
    },
    seguroVoluntario = {},
    consultaTasaSimulador = {
      infoConSeguro: {
        seguroDesempleo: '',
        seguroVidaEITP: '',
        seguroVidaITPXMillon: '',
        tasaEA: '',
        tasaMV: '',
        valorCuotaMensual: '',
        valorFinalCredito: '',
      },
      infoSinSeguro: {
        seguroDesempleo: '',
        seguroVidaEITP: '',
        seguroVidaITPXMillon: '',
        tasaEA: '',
        tasaMV: '',
        valorCuotaMensual: '',
        valorFinalCredito: '',
      },
      seguroAdquirido: false,
      valorMontoContraOferta: 0,
      valorPlazoContraOferta: '',
    },
    evaluadorPCO = {
      causalDecisionSolicitud: {
        causalDecisionSolicitud1: '',
        causalDecisionSolicitud2: '',
        causalDecisionSolicitud3: '',
        causalDecisionSolicitud4: '',
        causalDecisionSolicitud5: '',
      },
      codigoCausalDecisionSolicitud: '',
      decisionCategory: '',
      montoMaximoContraoferta: '0',
      plazoAprobado: '0',
      valorAcierta: '',
      valorAprobado: '',
      valorCobroSeguroVida: '',
    },
    vinculacion = {
      data: {},
      infoClientePN: {},
    },
    autenticacionLiviana = {
      data: {},
    },
    crearSolicitud = {
      numeroCredito: '',
    },
    consultaPersistencia = {
      campana: '',
      canalVentaOrigen: '',
      estadoDaviplata: '',
      gmf: '',
      indicadorLibranza: '',
      nroSolicitud: '',
      nroSolicitudRetoma: '',
      otp: '',
      spreed: '',
      tipoTasaFijaOVariable: '',
      valAceptado: '',
    },
    crearPagareDigital = {
      idPagareDigital: '',
    },
    crearCuentaDigital = {},
    datosFormulario = {
      actividadEconomica: '',
      actividadLaboral: {},
      autorizacion: {},
      ciudadResidencia: '',
      codigoAsesor: '',
      direccionPrincipal: '',
      ingresosMensuales: '',
      nombreEmpresa: '',
      tipoContrato: {},
      valorAceptado: 0,
    },
    aprobacionCredito = {
      causalDecisionSolicitud: {
        CausalDecisionSolicitud1: '',
        CausalDecisionSolicitud2: '',
        CausalDecisionSolicitud3: '',
        CausalDecisionSolicitud4: '',
        CausalDecisionSolicitud5: '',
      },
      codigoCausalDecisionSolicitud: '',
      decisionCategory: '',
      valorAprobado: '',
      valorCobroSeguroVida: '',
    },
    cuentaRotativo = {
      numeroCuentaConfirmada: '',
      tipoCuentaConfirmada: '',
      tipoCuentaConfirmadaNombre: '',
    },
    cuentaDebito = {
      numeroCuentaDebitar: '',
      tipoCuentaDebitar: '',
    }
  ) {
    this.clientId = uuid.v1()
    this.tipo = TipoSesion.PRODUCTO
    this.workflow = new EstadoWorkflowData('', '', '', {
      canal: 0,
      esAliado: false,
      idAliado: '',
    })
    this.app = new EstadoAppData()
    this.presentacion = presentacionCliente
    this.estado = ESTADO_SESION.NUEVO
    this.fechaExpiracion = fechaExpiracion
    this.expiracionSesion = expiracionSesion
    this.ultimaAccion = ultimaAccion
    this.ip = ip
    this.listasRestrictivas = listasRestrictivas
    this.grabarInfoSol = grabarInfoSol
    this.consultaClientePN = consultaClientePN
    this.consultaProducto = consultaProducto
    this.seguroVoluntario = seguroVoluntario
    this.consultaTasaSimulador = consultaTasaSimulador
    this.evaluadorPCO = evaluadorPCO
    this.vinculacion = vinculacion
    this.autenticacionLiviana = autenticacionLiviana
    this.total = total
    this.crearSolicitud = crearSolicitud
    this.consultaPersistencia = consultaPersistencia
    this.crearPagareDigital = crearPagareDigital
    this.crearCuentaDigital = crearCuentaDigital
    this.datosFormulario = datosFormulario
    this.aprobacionCredito = aprobacionCredito
    this.cuentaRotativo = cuentaRotativo
    this.cuentaDebito = cuentaDebito
    this.autorizacionDebitoAuto = autorizacionDebitoAuto
  }
}
