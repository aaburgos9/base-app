//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { AuthService } from '@services/auth/authService'
import { IKey } from '@services/auth/key.model'
import axios from 'axios'
import { JWK } from 'node-jose'

jest.mock('axios')

// Crear mock Config
const mockConfigData = {
  back: {
    authServiceUrl: 'http://auth-service/api',
  },
}
class MockConfig implements IConfig {
  public getVars = () => {
    return mockConfigData
  }
}

describe('AuthService', () => {
  const config = new MockConfig()
  const auth = new AuthService(config)
  const mockData = {
    canal: '37',
    clientId: 'abc123',
    otpToken: 'eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vdGVzdC5jbG91ZC5kYXYubmV0Ly53ZWxsLWtub3duL2p3a3MuanNvbiIsImtpZCI6IjE1NTE4MTc4MjkifQ.eyJhdWQiOiJEQVY6Q0xPVUQ6QVVUSCIsImV4cCI6IjE4Njg2Njc3NzkiLCJpYXQiOiIxNTUzMDkxNzc5IiwiaXNzIjoiREFWOkNMT1VEOkFVVEgiLCJzdWIiOiJhYmMxMjMiLCJ1c2UiOiJvIiwianRpIjoiYTlmODE5YzAtNGIxYi0xMWU5LThlYjItOTE1YTA0OTZlNTQ1In0.BiEUUmU8UMBJfWX5k6SXSW20zXC_P_HwLXf4UOVxIeLWPa4-1S6PCcSqjAFWOl5bgY5NdIDhUQWg4VCCY5tOLzwfun02QRqCX5sW8bmXg63p91MVKZwTL9-fkE2-Kb5ZM1cVqTSsKNfxhX3K0g_1zylPV53xvi_9nwoGtAsLszV_V6fZtydjAP9KtC_laBIiTL0ijx248W4LV7uYwGxjnBQTwK-mUoJKeoFp6IUXp75zlD0cBOu6KJGQgbnEFI6Igf71DSE-aE0_WUS7uVbHMhJ8uhyLfj3GJt9VjScKmHjeOptS6iOS1B7Zcri2D_mlcBIVj6fkqJQrFxyPMhkQmw',
    producto: 'rotativo_CO',
    sigKey: '{"kty": "RSA","kid": "1551817829","use": "sig","alg": "RS256","e": "AQAB","n": "pA2R8AEbsszPIUPBqnRrGCJbwoX14osIDVNmpvE9OR4tYtFhck2h6eVVvPAzQO55bWLtHS8kxiL0q_VCssXeDelADVcOdTtbJcmIU2qBTyqRMI11euKczCxf4HQrGTDUrkTpLP6eFVp538P1t2qfJ8IxMFRh3PuSKakaxzQ0YoZ6IL2BJZToQWGHX7i3PDJM2QoT1QCqKwBZGZXG7rZd5BeJ3UDRCfTnnvMqxsdeyXR-Zjj92P8CrSEJDbUsmssONhni_4sczEy0axKAb48eT3Mrk6l9bOnGFIdId9QBevE0mls4XXeQYF2KRV-kUZLnDgs4Gc-xlxcvbqkzMfGFQw","d": "WnVlGCr0Q_Ys7FG5My04dDlV0YAeYgl5qidnvfvdX2Zlbky359goxJkBWsoz6MTWTduzlVkOdPaHZV46per3E0KfX_u17CyLiN2Ef0KGBMoa_uOxeM4F2YtKXrCPpzdGvsUesgG_11RpSVp7XeS716d7igOtZrWNFc26B0eg7wYHBPdHmZk2r9uqynIu2ggd_dnGYjbkA-SFwG0owjAOP7z2Mi5e-DG0W1zrEnBT4RQBkf4gsb0sOIDPKuYvYftum8yaCmvql7bdeZhijEUvQMB4NpFH07_xGQkYnIS9piG8rnfcENw7lM50_yjQ8foBRhyub0KcZexiglrXePMWUQ","p": "3miN3FtQ8cn2RaQOPmynInGDZa5HBxCi7ED-4EO9LSVJ2wPjwNkKhQtr23CZtIRReHZpNwjERghTHSFIp_0kxJuiS-UsZj_fTFpR2fysIdEOiIh3l4lbtQDvMuAHYbKCmHPZpvIUKUUpR-9jMum-zisYARwlXuJTem_44bs2PUk","q": "vNSynIuFwFJhaYuSYGlP_AZRqvwXPQdrCU6XPzIwnu010gyZZAyckZ8lBXQXiC9yKamCuXmR6FzD8w1geuUqVskNESYLgnYdus4ZR2ylvXdqzOO5wUyNAVJQ126oveJoK_p-261z9l5pRW8zLnY5ToUSObC7Kh4CGBUvfn_Nais","dp": "isCDsDOv_ghXgf7lfABhDNXweaEOYtP4MJgj6lmYTe_zcZWtowRE0dfcRBytZ7cc9KA658CqYl6TK5s2Lsd5BsdpqxugZXH3pzS519sQsFAyVu98XKeu9O9OS1kEgejSHLY51TM1bMHfDSfFpV-6T_kGkrqyfc2I8tukU39uSTE","dq": "D_Ht-yYU7z6Fl0H_5EBATsnBz6xl0fN0aF7Iir-UN3dUWh5SPY6LEgjcOW-qJQfMnhQAQ-UuGu7qZPW2Nepv_tAPWGlcA3Ix5HpOzCcyf6M7031PTDFIntnylZ50hUQ_A6etWqN07VLflMtlCQFWqXi3J0PzKgVKq_nt_sKP9-0","qi": "s-uCsOZNYt2Wcmw9bL9yWzl4oxvEUfgDG1e6kJ5yYkK3q5_oU6ysAYy9GjjR9OTLXl0IPc-A3kXMPgKgtc5adldQqxDJP3c8AY3S3maQkF5DsWsyFyietz1tc1Eb-ocZ5eQ14ZfTIxfT-fNBHubuq8Nzv4yLL5ASj-0Yo3YrUGE"}',
  }

  test('createOtp con respuesta satisfactoria del servicio retorna token', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: {
          token: mockData.otpToken,
        },
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.post = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await auth.createOtp(mockData.clientId, mockData.producto, mockData.canal)
    } catch (err) {
      expect(err).toBeFalsy()
    }
    // Verificar los resultados
    expect(returnedData).toEqual(mockData.otpToken)
    expect(axios.post).toHaveBeenCalledTimes(1)
    expect(axios.post).toHaveBeenCalledWith('http://auth-service/api/otp', {
      payload: {
        product: `${mockData.producto}_${mockData.canal}`,
      },
      subject: mockData.clientId,
    })
    done()
  })

  test('createOtp con respuesta con error en llamada al servicio auth retorna error 500', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: {},
        errors: ['ups-en-auth'],
      },
      status: 404,
    }

    // Decirle a axios que responder
    axios.post = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await auth.createOtp(mockData.clientId, mockData.producto, mockData.canal)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-auth')
      done()
    }
  })

  test('createOtp con error de axios en llamada al servicio auth retorna error 500', async (done) => {
    // Decirle a axios que responder
    axios.post = jest
      .fn()
      .mockImplementationOnce(() => Promise.reject(new Error('ups-en-axios')))

    // Realizar la llamada a probar
    let returnedData
    try {
      returnedData = await auth.createOtp(mockData.clientId, mockData.producto, mockData.canal)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-axios')
      done()
    }
  })

  /*
   *
   *  pruebas de      g e t K e y
   *
   */

  test('getKey con llave (no cache) obtiene desde servicio y retorna JWK', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: JSON.parse(mockData.sigKey),
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551817829', 'sig')
      // Verificar los resultados
      expect(returnedData).toBeTruthy()
      expect(returnedData.kid).toEqual(mockResponse.data.data.kid)
      expect(axios.get).toHaveBeenCalledTimes(1)
      expect(axios.get).toHaveBeenCalledWith(
        'http://auth-service/api/keystore/jwk/1551817829/sig'
      )
      expect(auth.keystoreCache.containsKey('1551817829_sig')).toBeTruthy()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('getKey con llave en cache no expirado no consulta el servicio y retorna JWK desde cache', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: JSON.parse(mockData.sigKey),
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // agregar key a cache
    const jwkKey = await JWK.asKey(mockData.sigKey)
    const newKey: IKey = {
      exp: Math.floor((new Date().getTime() + 360000) / 1000),
      jwk: jwkKey,
    }
    auth.keystoreCache.set('1551899999_sig', newKey)

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551899999', 'sig')
      // Verificar los resultados
      expect(returnedData).toBeTruthy()
      expect(returnedData.kid).toEqual(mockResponse.data.data.kid)
      expect(axios.get).toHaveBeenCalledTimes(0)
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('getKey con llave en cache expirado si consulta el servicio y actualiza cache', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: JSON.parse(mockData.sigKey),
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // agregar key a cache
    const jwkKey = await JWK.asKey(mockData.sigKey)
    const newKey: IKey = {
      exp: Math.floor((new Date().getTime() - 360000) / 1000),
      jwk: jwkKey,
    }
    auth.keystoreCache.set('1551888888_sig', newKey)

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551888888', 'sig')
      // Verificar los resultados
      expect(returnedData).toBeTruthy()
      expect(returnedData.kid).toEqual(mockResponse.data.data.kid)
      expect(axios.get).toHaveBeenCalledTimes(1)
      expect(axios.get).toHaveBeenCalledWith(
        'http://auth-service/api/keystore/jwk/1551888888/sig'
      )
      expect(auth.keystoreCache.containsKey('1551888888_sig')).toBeTruthy()
      expect(auth.keystoreCache.get('1551888888_sig').exp).toBeGreaterThan(
        newKey.exp
      )
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('getKey con error 404 en llamada al servicio auth retorna error 404', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: {},
        errors: ['not_found'],
      },
      status: 404,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551777777', 'sig')
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.data_not_found)
      expect(error.statusCode).toEqual(404)
      done()
    }
  })

  test('getKey con error != 404 en llamada al servicio auth retorna error 500', async (done) => {
    // Preparar datos a usar en el test
    const mockResponse = {
      data: {
        data: {},
        errors: ['formato_invalido'],
      },
      status: 422,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551777777', 'sig')
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      done()
    }
  })

  test('getKey con error de axios en llamada al servicio auth retorna error 500', async (done) => {
    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.reject(new Error('ups-en-axios')))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getKey('1551777777', 'sig')
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-axios')
      done()
    }
  })

  /*
   *
   *  pruebas de      e n d S e s s i o n
   *
   */

  test('blacklistToken con clientId valido retorna true', async (done) => {
    // Preparar datos a usar en el test
    const clientId = '197c526f-2a4f-11e9-b210-d62154fgv789'
    const mockRequest = {
      client_id: clientId,
      exp: 1548272862,
      jti: clientId,
    }
    const mockResponse = {
      data: {
        data: mockRequest,
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.put = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.endSession(clientId)
      // Verificar los resultados
      expect(returnedData).toBeTruthy()
      expect(axios.put).toHaveBeenCalledTimes(1)
      expect(axios.put).toHaveBeenCalledWith(
        `${mockConfigData.back.authServiceUrl}/keystore/blacklist/rtnbl/${clientId}`,
        {
          client_id: clientId,
          exp: jasmine.any(String),
          jti: clientId,
        }
      )
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('blacklistToken con error en la respuesta retorna error', async (done) => {
    // Preparar datos a usar en el test
    const clientId = '197c526f-2a4f-11e9-b210-d62154fgv789'
    const mockResponse = {
      data: {
        errors: ['ups-en-servicio'],
      },
      status: 500,
    }

    // Decirle a axios que responder
    axios.put = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.endSession(clientId)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-servicio')
      done()
    }
  })

  test('blacklistToken con error en axios retorna error', async (done) => {
    // Preparar datos a usar en el test
    const clientId = '197c526f-2a4f-11e9-b210-d62154fgv789'

    // Decirle a axios que responder
    axios.put = jest
      .fn()
      .mockImplementationOnce(() => Promise.reject(new Error('ups-en-axios')))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.endSession(clientId)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-axios')
      done()
    }
  })

  /*
   *
   *  pruebas de      g e t C e r t i f i c a t e
   *
   */
  test('retorna un certificado cuando el id existe', async (done) => {
    // Preparar datos a usar en el test
    const certificateId = 'CCV-CO'
    const mockResponse = {
      data: {
        data: '----PEM----\nblablabla\n----PEM----',
      },
      status: 200,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getCertificate(certificateId)
      // Verificar los resultados
      expect(returnedData).toBeTruthy()
      expect(returnedData).toEqual(mockResponse.data.data)
      expect(axios.get).toHaveBeenCalledTimes(1)
      expect(axios.get).toHaveBeenCalledWith(
        `${mockConfigData.back.authServiceUrl}/keystore/certificate/${certificateId}`
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('retorna null cuando el id del certificado no existe', async (done) => {
    // Preparar datos a usar en el test
    const certificateId = 'CCV-CO'
    const mockResponse = {
      data: {
        data: null,
      },
      status: 404,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getCertificate(certificateId)
      // Verificar los resultados
      expect(returnedData).toBeFalsy()
      expect(axios.get).toHaveBeenCalledTimes(1)
      expect(axios.get).toHaveBeenCalledWith(
        `${mockConfigData.back.authServiceUrl}/keystore/certificate/${certificateId}`
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('retorna error 500 cuando el endpoint retorna status distinto de 200 o 404', async (done) => {
    // Preparar datos a usar en el test
    const certificateId = 'CCV-CO'
    const mockResponse = {
      data: {
        data: null,
        errors: ['ups-en-servicio'],
      },
      status: 500,
    }

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(mockResponse))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getCertificate(certificateId)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-servicio')
      done()
    }
  })

  test('retorna error 500 cuando falla axios', async (done) => {
    // Preparar datos a usar en el test
    const certificateId = 'CCV-CO'

    // Decirle a axios que responder
    axios.get = jest
      .fn()
      .mockImplementationOnce(() => Promise.reject(new Error('ups-en-axios')))

    // Realizar la llamada a probar
    try {
      const returnedData = await auth.getCertificate(certificateId)
      expect(returnedData).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toContain('ups-en-axios')
      done()
    }
  })
})
