//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { PRODUCTO } from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { BYC0000 } from '@services/workflowService/steps/Rotatitvo/BYC0000/BYC0000'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'

import axios from 'axios'

const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        parmsServiceUrl: 'http://catalogo/v1',
        persistenceServiceUrl: 'http://localhost:5003/persistence/v1',
        procesoBiometriaInternaWorkflowServiceUrl:
          'http://probioiw/v1/workflow',
      },
    }
  }
}

const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    ip: '192.168.0.15',
    llaveEncriptacion: 'llave',
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.BYC0000,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    authenticationType: 'VIRTUAL',
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
    userId: '121212',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'SUPERAPP',
      platformType: 'SUPERAPP',
      sessionId: 'sp2~ObaQXb9EIIhh8bx_pTPBEg__.t1',
      transactionId: '12343',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      inactiveInterval: '60000',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
    genericData: {
      dataItem: [
        {
          key: 'tokenFrontend',
          value: 'WRG4QG3T-BVETPBTA-5FWAPY4VKPAS7JEG-EC',
        },
      ],
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      denial: '',
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const valParmsResponse = {
  data: {
    data: {
      codIdioma: 'ES',
      consultaClientePN: {
        tipoOperacionLog: 'CONSULTA_CLIENTE',
      },
      consultaPersistenciaCredito: {
        nuevaSolicitud: 'R',
        retomaSolicitud: 'V',
      },
      destinoCredito: '',
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        indicadorConSeguro: '',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '1',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      listasRestrictivas: {
        codigoSolicitud: 'SOLCREDIG',
        listasAsegurables: ['ASEGURADORA 1', 'ASEGURADORA 2'],
        motivoRechazoListas: '4',
        tipoOperacionLog: 'LISTAS_RESTRICTIVAS',
        tipoPersona: 'N',
        valRespuesta: ['S', 'I'],
        valRespuestaI: 'I',
      },
      locale: 'CO',
      loggerVersion: 'v1',
      periodicidadPago: 'M',
      productosEnMora: {
        data: {
          valProductoRrpSolicitado: '0140',
          valSubproductoRprSolicitado: '7001',
        },
        dataHeader: {
          jornada: '0',
          modoDeOperacion: '0',
          nombreOperacion: 'ValidacionProductosEnMora',
          perfil: '0',
          usuario: 'WEL',
          versionServicio: '1.0.0',
        },
        idService: 'ValidacionProductosEnMora',
        operaciones: {
          operation: {
            statusResponse: {
              status: 'OK',
            },
            type: 'VALIDACIONES_INGRESO',
          },
        },
      },
      sessionTimeout: '600000',
      terminalId: '370062',
      total: '370000',
      usuarioSinRiesgo: '0',
    },
    status: 200,
  },
}

const valParmsResponseAux = {
  data: {
    data: {
      codIdioma: 'ES',
      consultaClientePN: {
        tipoOperacionLog: 'CONSULTA_CLIENTE',
      },
      consultaPersistenciaCredito: {
        nuevaSolicitud: 'R',
        retomaSolicitud: 'V',
      },
      destinoCredito: '',
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        indicadorConSeguro: '',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '1',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      listasRestrictivas: {
        codigoSolicitud: 'SOLCREDIG',
        listasAsegurables: ['ASEGURADORA 1', 'ASEGURADORA 2'],
        motivoRechazoListas: '4',
        tipoOperacionLog: 'LISTAS_RESTRICTIVAS',
        tipoPersona: 'N',
        valRespuesta: ['S', 'I'],
        valRespuestaI: 'I',
      },
      locale: 'CO',
      loggerVersion: 'v1',
      periodicidadPago: 'M',
      productosEnMora: {
        data: {
          valProductoRrpSolicitado: '0140',
          valSubproductoRprSolicitado: '7001',
        },
        dataHeader: {
          jornada: '0',
          modoDeOperacion: '0',
          nombreOperacion: 'ValidacionProductosEnMora',
          perfil: '0',
          usuario: 'WEL',
          versionServicio: '1.0.0',
        },
        idService: 'ValidacionProductosEnMora',
        operaciones: {
          operation: {
            statusResponse: {
              status: 'OK',
            },
            type: 'VALIDACIONES_INGRESO',
          },
        },
      },
      sessionTimeout: '',
      terminalId: '370062',
      total: '370000',
      usuarioSinRiesgo: '0',
    },
    status: 200,
  },
}

const valconsultarDataPROBIOINTSinDatosResponse = {
  data: {
    data: {
      biometria: {
        analisis: {
          codigo: '0',
        },
        estatus: false,
        fecha: '',
        hora: '',
        idAutenticacion: '',
        idTransaccion: '',
        retoOtp: {
          generacion: {
            expiracion: 'TEST',
            fecha: {
              fecha: '07-02-2022',
              fechaHora: '07-02-2022T22:13:28',
              hora: '22:13:28',
              inicio: 'TEST',
              operacion: 'TEST',
              tiempo: 'TEST',
              tokenOTP: 'TEST',
            },
            idTokenOTP: '',
            mediosNotificados: {
              esMail: false,
              esPush: false,
              esSms: true,
            },
          },
          numero: '098765',
          tipo: 'OTP',
          validacion: {
            esValidacionExitosa: false,
            intentos: 0,
          },
        },
        semilla: 'ABCDTEFGTYUIOP',
        tipoReto: 'SMS OTP',
      },
      dataProducto: {
        tokenFrontend: 'ABCDEFGHIJKLMNÑOPQRSTU',
      },
      flujo: {
        consecutivoTotal: 370029,
        stepProBioInt000: false,
        stepProBioInt010: false,
      },
      sesion: {
        presentacion: {
          consumer: {
            appConsumer: {
              canalId: '37',
            },
          },
        },
      },
    },
  },
  status: 200,
}
const valconsultarDataPROBIOINTSinDatosResponseAux = {
  data: {
    data: {
      biometria: {
        analisis: {
          codigo: '0',
        },
        estatus: false,
        fecha: '',
        hora: '',
        idAutenticacion: '',
        idTransaccion: '',
        retoOtp: {
          generacion: {
            expiracion: 'TEST',
            fecha: {
              fecha: '07-02-2022',
              fechaHora: '07-02-2022T22:13:28',
              hora: '22:13:28',
              inicio: 'TEST',
              operacion: 'TEST',
              tiempo: 'TEST',
              tokenOTP: 'TEST',
            },
            idTokenOTP: '',
            mediosNotificados: {
              esMail: false,
              esPush: false,
              esSms: true,
            },
          },
          numero: '098765',
          tipo: 'OTP',
          validacion: {
            esValidacionExitosa: false,
            intentos: 0,
          },
        },
        semilla: 'ABCDTEFGTYUIOP',
        tipoReto: 'SMS OTP',
      },
      dataProducto: {
        tokenFrontend: 'ABCDEFGHIJKLMNÑOPQRSTU',
      },
      flujo: {
        consecutivoTotal: 370029,
        stepProBioInt000: false,
        stepProBioInt010: true,
      },
      sesion: {
        presentacion: {
          consumer: {
            appConsumer: {
              canalId: '37',
            },
          },
        },
      },
    },
  },
  status: 200,
}

const valconsultarDataPROBIOINTEstatusTrueResponse = {
  data: {
    data: {
      biometria: {
        analisis: {
          codigo: '0',
        },
        estatus: true,
        fecha: '',
        hora: '',
        idAutenticacion: '',
        idTransaccion: '',
        retoOtp: {
          generacion: {
            expiracion: 'TEST',
            fecha: {
              fecha: '07-02-2022',
              fechaHora: '07-02-2022T22:13:28',
              hora: '22:13:28',
              inicio: 'TEST',
              operacion: 'TEST',
              tiempo: 'TEST',
              tokenOTP: 'TEST',
            },
            idTokenOTP: '',
            mediosNotificados: {
              esMail: false,
              esPush: false,
              esSms: true,
            },
          },
          numero: '098765',
          tipo: 'OTP',
          validacion: {
            esValidacionExitosa: false,
            intentos: 0,
          },
        },
        semilla: 'ABCDTEFGTYUIOP',
        tipoReto: 'SMS OTP',
      },
      dataProducto: {
        tokenFrontend: 'ABCDEFGHIJKLMNÑOPQRSTU',
      },
      flujo: {
        consecutivoTotal: 370029,
        stepProBioInt000: true,
        stepProBioInt010: false,
      },
      sesion: {
        presentacion: {
          consumer: {
            appConsumer: {
              canalId: '37',
            },
          },
        },
      },
    },
  },
  status: 200,
}

const valconsultarDataPROBIOINTExitosoOtpResponse = {
  data: {
    data: {
      biometria: {
        analisis: {
          codigo: '0',
        },
        estatus: true,
        fecha: '',
        hora: '',
        idAutenticacion: '',
        idTransaccion: '',
        retoOtp: {
          generacion: {
            expiracion: 'TEST',
            fecha: {
              fecha: '07-02-2022',
              fechaHora: '07-02-2022T22:13:28',
              hora: '22:13:28',
              inicio: 'TEST',
              operacion: 'TEST',
              tiempo: 'TEST',
              tokenOTP: 'TEST',
            },
            idTokenOTP: '',
            mediosNotificados: {
              esMail: false,
              esPush: false,
              esSms: true,
            },
          },
          numero: '098765',
          tipo: 'OTP',
          validacion: {
            esValidacionExitosa: true,
            intentos: 0,
          },
        },
        semilla: 'ABCDTEFGTYUIOP',
        tipoReto: 'SMS OTP',
      },
      dataProducto: {
        tokenFrontend: 'ABCDEFGHIJKLMNÑOPQRSTU',
      },
      flujo: {
        consecutivoTotal: 370029,
        stepProBioInt000: false,
        stepProBioInt010: true,
      },
      sesion: {
        presentacion: {
          consumer: {
            appConsumer: {
              canalId: '37',
            },
          },
        },
      },
    },
  },
  status: 200,
}

const valconsultarDataPROBIOINTExitosoSinRiesgoResponse = {
  data: {
    data: {
      biometria: {
        analisis: {
          codigo: '0',
        },
        estatus: false,
        fecha: '',
        hora: '',
        idAutenticacion: '',
        idTransaccion: '',
        retoOtp: {
          generacion: {
            expiracion: 'TEST',
            fecha: {
              fecha: '07-02-2022',
              fechaHora: '07-02-2022T22:13:28',
              hora: '22:13:28',
              inicio: 'TEST',
              operacion: 'TEST',
              tiempo: 'TEST',
              tokenOTP: 'TEST',
            },
            idTokenOTP: '',
            mediosNotificados: {
              esMail: false,
              esPush: false,
              esSms: true,
            },
          },
          numero: '098765',
          tipo: 'OTP',
          validacion: {
            esValidacionExitosa: true,
            intentos: 0,
          },
        },
        semilla: 'ABCDTEFGTYUIOP',
        tipoReto: 'SMS OTP',
      },
      dataProducto: {
        tokenFrontend: 'ABCDEFGHIJKLMNÑOPQRSTU',
      },
      flujo: {
        consecutivoTotal: 370029,
        stepProBioInt000: true,
        stepProBioInt010: false,
      },
      sesion: {
        presentacion: {
          consumer: {
            appConsumer: {
              canalId: '37',
            },
          },
        },
      },
    },
  },
  status: 200,
}

const mockWfData = new WorkflowData(mockPresentacion)

const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)
const serviceUrls = {
  parametros: `http://catalogo/v1/parms/services.workflow.BYC0000?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO.CRRT}`,
  probioInt: `http://probioiw/v1/workflow/data`,
}

let step: BYC0000
let nextStep: IStepData

describe('BYC0000', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para BYC0000
   *
   */

  test('Instancia correctamente del objeto BYC0000', () => {
    step = new BYC0000(stepData, mockWfData, config, logger, persistence)
    expect(step).toBeDefined()
  })

  test('Validación del objeto BYC0000 con payload correcto (no retorna mensaje de error)', () => {
    expect(step.isRequestValid()).toBeTruthy()
  })

  test('Validación del objeto BYC0000 con payload incorrecto (si retorna mensaje de error)', () => {
    const badStepData: IStepData = {
      clientId: 'abc123',
      payload: {
        bad: '',
      },
      stepId: STEP_ID.BYC0000,
    }
    const badStep = new BYC0000(
      badStepData,
      mockWfData,
      config,
      logger,
      persistence
    )
    expect(badStep.isRequestValid()).toBeFalsy()
    expect(badStep.getRequestValidationError().length).toBeGreaterThan(0)
  })

  /*
   *
   *  Verificacion del flujo para BYC0000
   *
   */
  test('Validación del getCurrentStep retorna valor del request', () => {
    expect(step.getCurrentStep()).toEqual(stepData.stepId)
  })

  test('BYC0010 => Presentación sin sessionTimeOut', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTSinDatosResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación con sessionTimeOut', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTSinDatosResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => consulta ProbioInt OK || stepProBioInt010: true', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTExitosoOtpResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => consulta ProbioInt OK || stepProBioInt010: false || estatus: true', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valconsultarDataPROBIOINTEstatusTrueResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => consulta ProbioInt OK || stepProBioInt010: false || estatus: false || stepProBioInt000 : true || usuarioSinRiesgo', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(
          valconsultarDataPROBIOINTExitosoSinRiesgoResponse
        )
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => consulta ProbioInt false || stepProBioInt010: false || estatus: false || stepProBioInt000 : false ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(
          valconsultarDataPROBIOINTExitosoSinRiesgoResponse
        )
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  /*
   *
   *  Verificación de errores al
   *
   */

  test('BYC0000 => Cliente con error al consultar parametros -> Error 500 | CRRT', async (done) => {
    const valParmsResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0000 => Cliente con error en axios al consultar parametros -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0000 => Cliente con error al consultar datos al workFlow de PROBIOI -> Error 500', async (done) => {
    const valWorkFlowSvcResponse = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.resolve(valWorkFlowSvcResponse)
      }
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0000 => Cliente con error en axios al consultar datos al workFlow de PROBIOI -> Error 500', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.probioInt) {
        return Promise.reject(new Error('internal_server_error'))
      }
    })

    try {
      step = new BYC0000(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })
})
