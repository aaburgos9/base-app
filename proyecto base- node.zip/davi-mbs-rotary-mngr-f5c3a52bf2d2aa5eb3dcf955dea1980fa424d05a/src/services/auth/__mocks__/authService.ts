//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { JWK } from 'node-jose'

const mockData = {
  certificado: '----PEM----\nblablabla\n----PEM----',
  jweKey: '{"kty": "RSA","kid": "1553133006","use": "enc","alg": "RSA-OAEP-256","key_ops": ["encrypt","wrap","verify"],"e": "AQAB","n": "lEkhmX7QqUGzA0efqo6tmdhLN0RwvNGIjZmDOE4DXuZjFGNWHrTlbNhqUXebwuRRHJBxM3JB-C0s2Fd6qvI9oduYs1dQBBUtiDeH6TUvYmdTlLDBytCGDUN4Aup5G6S3CEeSOmboi48CroVmMqAE1FXLQEF35bgFSdyt_87B5bqIfLTvcna8FQ2OT7O_wlQcmt4OtOAVxRtDm1cr92A8VfhXZ_fgb7aKQBhmULt22_dHcjc2bylCj0cjfBeKAf_UDgDHNK324B_kipurcMvY53sMWzKemweIsb1UnRKAKX68b6QXa5xu-VjuS3obo7to4DIBIBpXAtdHQJeYSKXBqw","d": "O80abcrE392NEh-KdsA_prGh89H4HU3rYh-s2cIsfdMv1gMRsiSF-dV1WxF_kaN-SqS94l-L10hws3bkE5jJ3kKvXHQz4tGfoTWz7Ar05xyAipCWNvLNfP_eoF5rJQjSf9ZNVJw34EB2dmd6BaSfDfrjkzBT6CLEjzseOPHrJHftfIBw5LoBlhreo6sgzg_AtD_s9zvMQvyUdAAyFEdpmweRtqwO0VatfETArAj7r7mG0T_PMpx1m4tR1rD_LA0fmt_OlGzNiYKdu3oXpkup1kuGItANetz4-nJq2s0Ok02CMABo4Bt3433oYSrKgIhwmjSidZ1RNUl5gJDI5nY00Q","p": "2egk333r7XFzY6G5g3_5DjjFCDBmPJb0D_GTgcFICPyGOyfHUjf9N63zOg4TEEt50osXk75ZlUa_ya7rXSkgCrE88sv8ii1_zJzxclHMie9bJQcAgDKvqs-9hfMEveUHkFYD_tbPEX0NxGMz3EY8GQNhhAx3hi7AZatK-omOsPU","q": "rjVF36tJyr6GV48jvq3Jd_-4lIqNJc7avwnctkaB6g-ljhPtUg3nogGIDrXnnSrBnwd87Sb7uf3Dcs99NZLhasnkiOoQlHInc9Pw0qjB-cWb3EOme6yu2SRucnYjSX_W87aSKLuBBTyykoFcAWGxICSsGgaP5pi_HmQrVySghB8","dp": "nh76QsLZJF-i37VHLMj8LPm84Ahe57CSQc-Gvi1G3F6B-QMQe_Ts5i5vxLzZ0IU0TTdpUGhcERpZqTwoxl1FRvz9wSGMi6ggiJWKDu6UgbMSbHf8QQqGtmgwmraRxkofhvkjxRSTBZm9F7j0tO6yRWRSqsNxKAlcy2nU6qBOztE","dq": "np-PYhw7csqM1MlXSNZBLmzAizClWRnDAFRgjfAhdxiMLJRkcWSL124BjzN_FBLMfpt42w-2AiLYhn_7iH6Xln8DAs_uDNzso4EGNSrIhT-zrZpDyzTveHS9xKdhdhlbhkplR4WD81rTVqdHOVLUz2nU81WqTdQjoe6fsBd_uQ0","qi": "M5vcrNqbMMdU2Y1VJEnto4PBWjzNlQHiTuVVn4jPLbLdqRV4JzjYxF3ApHbUXzha8nfFk0qwJH5POLPfnzcZJyLwyJJbjXiIwaF1436kir0LeFn-vQNF-bZCmudL68eFE0GyDO2-rlgVSM8hawqi2m9Xz57XMr5XsgfP1U7QTEU"}',
  otpToken: 'eyJraWQiOiIxNTUzMTMzMDA2IiwiZW5jIjoiQTI1NkNCQy1IUzUxMiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.aatVVSxuMmURQxfNfO_k6gz9PkW--htA2rZ5yDVauj-UKL6_gmzN2rzLlNM_cIPwLHocL4jJjs7Ne-Icc-O3AegpBO5QALE8HJPeebtSnkLCT42BiKrpF01dQW_1fdsI22UEmGqpXL0FFuHs0SyxWkRzR5n812VqeH1ZVsHdErsL_rG6OEThvDTcgy4pdXqmlE2clS2vGCnN-TkjZ7cxj12ioHmaxeWOh8pEGwUEXsFfdF5G0QnDQNjNsv6RahGO7nY51LXMwtj7Ce_yQHV-cbdaebtY5bi9bLVHQTSUnEcMrJiYvAibY_iWfhjeDikT6isRrowAZnZmJKkF5MG_GQ.5-eR-3JBsPzL_uZNH-MSUA.E0cjoWxxaesVJZhbebswoHaVAtLeF3sgiSrecSvHZVnbA9Px24zBgWeLh5BYohtTDN02hwKkGbgtMARgtASm6rE-U15qP9adh0j_Fl9nsG-UqBty4amijCsVLi2MrvJxE0dlpzCl7734F9DDbOadIJed9O7xL13_GM0XFERggKnZaTC70ec6BSVBKEaE_6Bo40sVeqxkDPjT839LmFFcoZw2GbCAKmrkHsDmR6ntE4v9OQkJt8tW9YUhDsrr1fs6WPFLUyLQxQtzLfhJ1yFYGFol9cvqtfdkMXkyDsTQoLNGLyXB5rwN9gjtjtSnDOn9Fq6s0XrErPeTCX0Nn3XXZOsNg_vxgjRR5xYFtpO-mqJVAMh_XJIDNuksyc_OmgQtkyQNnxYp02s0GX2ueHFdmvfFJCw8jArP2rQ4ktYspg2TqqkcUYNDq5csVNnzMG3_ZxoiqoRazWH8mkcncFGkrjPVnYljvUpJye4cYJfIbcCEsDVaaxxr2MRiwCwkX-_7i9_owzUdHSqyWAFsY31_7cv4lcetODdH_s1hHwpDLgUhHOfk1SkgbiSQcMbO0RgEF3iNmbJIeAoMA4qe8qeUzjly3QW88t-A15Vzfb8m1YQxoRvXOb3PfEH8G9crEOXvTOFCOy2--zf-GAxCHy1VmIbiRusWyxI8CUISMUSi6Cz-klfQEQM-XYTmA0FnH9R2rvSN8yq-vKGjsgBcW4jbUDKt0j7RhSOSEFR1s_Z2vaDjQuKjAo8cm5wtBadQQTQ-u9GYcKYZYArcSmrfkl6S1vPiLBx1PIQEdHwRXHuiaV--XPB0TDJG5y4HzHQPGm0oz2vL53CoHotptS-kMPlYtDhz_Ij_NNOdqw4dCbf-yy3Hd51V9eoleZ-HcCT4NCKY5Vv8rhwp2enP0rCv6qTUGlT9c7MrKvEkW0USfY2EkBVWBZWG6wvWg1TavYJBJ3VvoWugobbdT0_lmzQf5zb9uwfhEdAVY7MwUpvWt4iyTGDa80l2QbbRbmhv7R0zGC1C0mTrUNXkKvgdOXK92MF5S9BjD2cJtiHSR8av5cTAWTEIjvKtqBlu2egGBpcT0LRY9kNIwGA4m8nxj6hE7vSyUw.tBu06dR3GixUlFhqS5cztXI-jONhzwZAOq26Z8Xpnlo',
}

export class AuthService {
  public createOtp = jest.fn((clientId: string) => Promise.resolve(mockData.otpToken))
  public getKey = jest.fn((kid: string, use: string) => JWK.asKey(mockData.jweKey))
  public endSession = jest.fn((clientId: string) => Promise.resolve(true))
  public getCertificate = jest.fn((clientId: string) => {
    if (clientId.includes('CCV-SV')) {
      return Promise.resolve(null)
    }
    if (clientId.includes('CCV-CO')) {
      return Promise.resolve(mockData.certificado)
    }
    return Promise.reject({})
  })
}
