//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { LoggerStub } from '@services/loggerService/loggerStub'

describe('LoggerStub', () => {
  const logger = new LoggerStub('info')

  test('Trace es invocado correctamente', () => {
    logger.clearLogs()
    logger.trace('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('TRACE')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Debug es invocado correctamente', () => {
    logger.clearLogs()
    logger.debug('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('DEBUG')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Info es invocado correctamente', () => {
    logger.clearLogs()
    logger.info('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('INFO')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Warn es invocado correctamente', () => {
    logger.clearLogs()
    logger.warn('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('WARN')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Error es invocado correctamente', () => {
    logger.clearLogs()
    logger.error('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('ERROR')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Fatal es invocado correctamente', () => {
    logger.clearLogs()
    logger.fatal('Logger test')
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('FATAL')
    expect(logs[0].message).toEqual('Logger test')
  })

  test('Info en logstream loguea correctamente', () => {
    logger.clearLogs()
    const message = ':method :url HTTP/:http-version | 200 | :response-time ms | :res[content-length] | :remote-addr | :remote-user'
    logger.logStream(message)
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('INFO')
    expect(logs[0].message).toEqual(message)
  })

  test('Error en logstream loguea correctamente', () => {
    logger.clearLogs()
    logger.getExpressLogger()
    const message = ':method :url HTTP/:http-version | 500 | :response-time ms | :res[content-length] | :remote-addr | :remote-user'
    logger.logStream(message)
    const logs = logger.dumpLogs()
    expect(logs[0].level).toEqual('ERROR')
    expect(logs[0].message).toEqual(message)
  })
})
