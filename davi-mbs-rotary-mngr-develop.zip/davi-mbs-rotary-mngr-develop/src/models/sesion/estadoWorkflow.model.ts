//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { STATUS_ID } from '@services/workflowService/steps/stepData.model'

export class EstadoWorkflowData {
  /*
   * Atributos
   */
  public pasoActual: string = ''
  public infoCanal: any
  public formularioDatosPersonales: any
  public horaUltimaSimulacion: string = ''
  public horaUltimoEvaluador: string = ''

  /*
   * Metodo constructor (inicialización) de la clase EstadoWorkflowData
   */
  constructor(
    pasoActual: string,
    horaUltimaSimulacion: string,
    horaUltimoEvaluador: string,
    infoCanal: {
      canal: number
      esAliado: boolean
      idAliado: ''
    },
    formularioDatosPersonales = {
      codActividadEconomica: '',
      codActividadLaboral: '',
      codAsesor: '',
      empresa: '',
      ingresos: '',
      payloadEntrada: '',
    }
  ) {
    this.pasoActual = pasoActual
    this.infoCanal = infoCanal
    this.formularioDatosPersonales = formularioDatosPersonales
    this.horaUltimaSimulacion = horaUltimaSimulacion
    this.horaUltimoEvaluador = horaUltimoEvaluador
  }
}
