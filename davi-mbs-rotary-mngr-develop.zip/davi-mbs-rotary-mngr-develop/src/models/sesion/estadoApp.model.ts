//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class EstadoAppData {
  /*
   * Atributos
   */
  public llaveEncriptacion: string = ''
  public ip: string = ''

  /*
   * Metodo constructor (inicialización) de la clase EstadoAppData
   */
  constructor() {
    this.llaveEncriptacion = ''
    this.ip = ''
  }
}
