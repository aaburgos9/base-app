import moment from 'moment'
import { UTILITIES } from '~/utils/utilities'
import { WorkflowData } from '../workflowData.model'

//
// Copyright (C) 2022- Banco Davivienda S.A. y sus filiales.
//

export class GrabarInformacionSolicitudesModel {
  private data: any

  constructor() {
    this.data = {}
  }

  public setObject(sessionData: WorkflowData, parms: any) {
    const nroProceso = sessionData.sesion.grabarInfoSol.nroProceso
    let valorCuotaMensual
    let tasaMV
    let tasaEA
    let seguroVidaITPXMillon
    let valorFinalCredito
    let seguroDesempleo
    let valorAprobado = sessionData.sesion.evaluadorPCO.valorAprobado
    const valCanal = sessionData.sesion.workflow.infoCanal.canal
    const estadoCliente = sessionData.sesion.consultaClientePN.esCliente

    if (sessionData.sesion.consultaTasaSimulador.seguroAdquirido) {
      valorCuotaMensual =
        sessionData.sesion.consultaTasaSimulador.infoConSeguro.valorCuotaMensual
      tasaMV = sessionData.sesion.consultaTasaSimulador.infoConSeguro.tasaMV
      tasaEA = sessionData.sesion.consultaTasaSimulador.infoConSeguro.tasaEA
      seguroVidaITPXMillon =
        sessionData.sesion.consultaTasaSimulador.infoConSeguro
          .seguroVidaITPXMillon
      valorFinalCredito =
        sessionData.sesion.consultaTasaSimulador.infoConSeguro.valorFinalCredito
      seguroDesempleo =
        sessionData.sesion.consultaTasaSimulador.infoConSeguro.seguroDesempleo
    } else {
      valorCuotaMensual =
        sessionData.sesion.consultaTasaSimulador.infoSinSeguro.valorCuotaMensual
      tasaMV = sessionData.sesion.consultaTasaSimulador.infoSinSeguro.tasaMV
      tasaEA = sessionData.sesion.consultaTasaSimulador.infoSinSeguro.tasaEA
      seguroVidaITPXMillon =
        sessionData.sesion.consultaTasaSimulador.infoSinSeguro
          .seguroVidaITPXMillon
      valorFinalCredito =
        sessionData.sesion.consultaTasaSimulador.infoSinSeguro.valorFinalCredito
      seguroDesempleo =
        sessionData.sesion.consultaTasaSimulador.infoSinSeguro.seguroDesempleo
    }

    if (sessionData.sesion.evaluadorPCO.creditoSeleccionado) {
      valorCuotaMensual =
        sessionData.sesion.evaluadorPCO.creditoSeleccionado.cuotaMensual
          .valorCuota
      tasaMV =
        sessionData.sesion.evaluadorPCO.creditoSeleccionado.tasaInteres.mv
      tasaEA =
        sessionData.sesion.evaluadorPCO.creditoSeleccionado.tasaInteres.ea
      seguroVidaITPXMillon =
        sessionData.sesion.evaluadorPCO.valorCobroSeguroVida
          ? sessionData.sesion.evaluadorPCO.valorCobroSeguroVida
          : parms.factorSeguroVida
      valorFinalCredito =
        sessionData.sesion.evaluadorPCO.creditoSeleccionado.valorFinalCredito
      seguroDesempleo =
        sessionData.sesion.evaluadorPCO.creditoSeleccionado.cuotaMensual.tooltip
          .pagoMensual.valor
      valorAprobado = sessionData.sesion.evaluadorPCO.valorAprobado
    }

    let nombres
    let primerApellido
    let segundoApellido
    const actividadEconomica =
      sessionData.sesion.datosFormulario.actividadLaboral.codigo
    nombres = sessionData.sesion.consultaClientePN.nombres
    primerApellido = sessionData.sesion.consultaClientePN.primerApellido
    segundoApellido = sessionData.sesion.consultaClientePN.segundoApellido
    seguroVidaITPXMillon =
      sessionData.sesion.evaluadorPCO.valorCobroSeguroVida
        ? sessionData.sesion.evaluadorPCO.valorCobroSeguroVida
        : parms.factorSeguroVida
    let horaSimulacion
    let horaEvaluacionPrimerMotor
    let OTP
    if (
      nroProceso >= parms.grabarInformacionSolicitudes.numeroProcesoEvaluacion
    ) {
      horaSimulacion =
        parseInt(sessionData.sesion.workflow.horaUltimaSimulacion, 10) ||
        undefined
      horaEvaluacionPrimerMotor =
        parseInt(sessionData.sesion.workflow.horaUltimoEvaluador, 10) ||
        undefined
      OTP = sessionData.sesion.autenticacionLiviana?.data?.otp?.valTokenOTP
    }

    let empresaDondeTrabaja
    let ocupacionIndependiente
    if (nroProceso >= parms.grabarInformacionSolicitudes.numeroProcesoDeceval) {
      empresaDondeTrabaja = sessionData.sesion.datosFormulario.nombreEmpresa
      ocupacionIndependiente =
        sessionData.sesion.datosFormulario.actividadEconomica
    } else {
      empresaDondeTrabaja = sessionData.sesion.datosFormulario.nombreEmpresa
      ocupacionIndependiente =
        sessionData.sesion.datosFormulario.actividadEconomica
      horaEvaluacionPrimerMotor =
        sessionData.sesion.workflow.horaUltimoEvaluador
      horaSimulacion = sessionData.sesion.workflow.horaUltimaSimulacion
    }

    const opera = {
      sessionId: sessionData.sesion.clientId,
      // tslint:disable-next-line: object-literal-sort-keys
      canalId: sessionData.dataProducto.canalId,
      id: sessionData.dataProducto.moduloId,
      ip: sessionData.sesion.ip,
      moduleId: sessionData.dataProducto.moduloId,
      client: {
        documentClient: {
          number: sessionData.dataProducto.numeroDocumento,
          type: sessionData.dataProducto.tipoDocumento,
        },
        userId: sessionData.sesion.clientId,
      },
    }
    Object.assign(opera, { logger: parms.loggerVersion })
    const transaccionID = moment().unix()
    this.data = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              total: sessionData.sesion.total,
              // tslint:disable-next-line: object-literal-sort-keys
              canal: sessionData.dataProducto.canalId,
              idTransaccion: transaccionID.toString(),
            },
            // tslint:disable-next-line: object-literal-sort-keys
            Data: {
              idSesion: sessionData.dataProducto.sesionIdCanal,
              // tslint:disable-next-line: object-literal-sort-keys
              codIdioma: sessionData.dataProducto.codIdioma,
              valOrigen: sessionData.sesion.ip,
              codPais: sessionData.dataProducto.country,
              aplicacionOrigen: sessionData.dataProducto.canalId,
              ipOrigen: sessionData.sesion.ip,
              tipoIdentificacion: sessionData.dataProducto.tipoDocumento,
              nroIdentificacion: sessionData.dataProducto.numeroDocumento,
              // tslint:disable-next-line: object-shorthand-properties-first
              nombres,
              // tslint:disable-next-line: object-shorthand-properties-first
              primerApellido,
              // tslint:disable-next-line: object-shorthand-properties-first
              segundoApellido,
              nroSolicitud:
                sessionData.sesion.consultaPersistencia.nroSolicitud,
              // tslint:disable-next-line: object-shorthand-properties-first
              nroProceso,
              fechaProceso: UTILITIES.fechaYYYYMMDD(),
              horaProceso: UTILITIES.horaHHMMSS(),
              valorSolicitado: sessionData.sesion.grabarInfoSol.valorSolicitado,
              // tslint:disable-next-line: object-shorthand-properties-first
              valorAprobado,
              // tslint:disable-next-line: object-shorthand-properties-first
              valorCuotaMensual,
              plazoSolicitado: sessionData.sesion.grabarInfoSol.plazoCredito,
              tasaAprobadaMesVencido: tasaMV,
              tasaAprobadaEfectivaAnual: tasaEA,
              codigoProductoRprSolicitado: parms.grupoProductoRPRBuro,
              codigoSubproductoRprSolicitado: parms.grupoSubproductoRPRBuro,
              codigoProductoCarteraFm2000Solicitado:
                parms.grabarInformacionSolicitudes
                  .codigoProductoCarteraFm2000Solicitado,
              ingresoMensuales:
                sessionData.sesion.datosFormulario.ingresosMensuales,
              // tslint:disable-next-line: object-shorthand-properties-first
              actividadEconomica,
              ciudadResidencia: sessionData.sesion.consultaClientePN.ciudadDI,
              // tslint:disable-next-line: object-shorthand-properties-first
              empresaDondeTrabaja,
              tipoContrato:
                sessionData.sesion.datosFormulario.tipoContrato.codigo, // TODO:VALIDAR EL CODIGO DE TIPO DE CONTRATO
              decision: sessionData.sesion.evaluadorPCO.decisionCategory,
              causalNegacion1:
                sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud,
              causalNegacion2:
                sessionData.sesion.evaluadorPCO.causalDecisionSolicitud
                  .causalDecisionSolicitud2,
              causalNegacion3:
                sessionData.sesion.evaluadorPCO.causalDecisionSolicitud
                  .causalDecisionSolicitud3,
              causalNegacion4:
                sessionData.sesion.evaluadorPCO.causalDecisionSolicitud
                  .causalDecisionSolicitud4,
              causalNegacion5:
                sessionData.sesion.evaluadorPCO.causalDecisionSolicitud
                  .causalDecisionSolicitud5,
              montoMaximoContraOferta:
                sessionData.sesion.consultaTasaSimulador
                  ?.valorMontoContraOferta,
              ingresoFinal: sessionData.sesion.consultaClientePN.ingresos,
              motivoRechazoIngreso:
                sessionData.sesion.grabarInfoSol.motivoRechazo,
              numeroCredito: sessionData.sesion.crearSolicitud.numeroCredito,
              numeroSolicitudFm2000:
                parms.grabarInformacionSolicitudes.numeroSolicitudFm2000,
              oficinaCliente:
                sessionData.sesion.consultaClientePN.oficinaRadicacionCLI,
              destinoCredito: parms.destinoCredito,
              celular: sessionData.sesion.consultaClientePN.numeroCel,
              ip: sessionData.sesion.ip,
              agenteVendedor: sessionData.sesion.datosFormulario.codigoAsesor
                ? sessionData.sesion.datosFormulario.codigoAsesor
                : parms.agenteVendedor,
              factorpormillon: seguroVidaITPXMillon,
              periodicidadPago: parms.periodicidadPago,
              idDocumentoPagare:
                sessionData.sesion.crearPagareDigital.idPagareDigital,
              indicadorLibranza:
                sessionData.sesion.consultaPersistencia.indicadorLibranza,
              acierta: sessionData.sesion.evaluadorPCO.valorAcierta,
              tipoTasaFijaOVariable:
                sessionData.sesion.consultaPersistencia.tipoTasaFijaOVariable,
              spreed: sessionData.sesion.consultaPersistencia.spreed,
              valorFinalCreditoIncluidoCola: valorFinalCredito,
              GMF: sessionData.sesion.consultaPersistencia.gmf,
              fechaEvaluacion1erMotor: UTILITIES.fechaYYYYMMDD(),
              campana: sessionData.sesion.consultaPersistencia.campana,
              canalVentaOrigen:
                sessionData.sesion.consultaPersistencia.canalVentaOrigen,
              estadoDaviplata:
                sessionData.sesion.consultaPersistencia.estadoDaviplata,
              estadoDeLaSolicitud:
                sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud,
              valAceptado: sessionData.sesion.datosFormulario.valorAceptado,
              indicadorAceptacionSeguro: sessionData.sesion.seguroVoluntario
                .seguroAdquirido
                ? parms.grabarInformacionSolicitudes.indicadorConSeguro
                : parms.grabarInformacionSolicitudes.indicadorSinSeguro,
              fechaRtaSolicitudSeguroAdquirido: UTILITIES.fechaYYYYMMDD(),
              horaRtaSolicitudSeguroAdquirido: UTILITIES.horaHHMMSS(),
              indicadorCampana: '',
              valSeguro: seguroDesempleo,
              scorePrecioCliente:
                sessionData.sesion.consultaClientePN.scorePrecioCliente,
              codigoPromocion:
                parms.grabarInformacionSolicitudes.codigoPromocion,
              indicadorCliente: 'S',
              // tslint:disable-next-line: object-shorthand-properties-first
              ocupacionIndependiente,
              numTipoCuentaAsociada:
                sessionData.sesion.cuentaRotativo.tipoCuentaConfirmada,
              numNumeroCuentaAsociada:
                sessionData.sesion.cuentaRotativo.numeroCuentaConfirmada,
            },
          },
        },
        // tslint:disable-next-line: object-literal-sort-keys
        operation: opera,
      },
    }
  }

  public getObject() {
    return this.data
  }
}
