//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { UTILITIES } from '@utils/utilities'
import axios from 'axios'
import joi from 'joi'
import moment from 'moment'
import momentTimezone from 'moment-timezone'

const STEP: string = 'OTP0010'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    generarOtp: joi.boolean().required(),
    validarOtp: joi.boolean().required(),
    valorOtp: joi.string().required().allow(''),
  })
  .optional()

export class OTP0010 extends Step {
  private parmsData: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger
    // private persistence: IPersistenceService
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData

    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de obtención de parametros del step (OTP0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.OTP0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )

    if (reqPayload.generarOtp) {
      let responsegenerarOtp
      try {
        responsegenerarOtp = await this.generarOtp()
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al generar Otp: ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,

            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.OTP0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep GenerarOTP Error del micro > nextStep: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )
        return nextStep
        // throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      if (
        responsegenerarOtp.data.response.contextoRespuesta.resultadoTransaccion
          .valCaracterAceptacion !== 'B'
      ) {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,

            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: '',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE,
          stepId: STEP_ID.OTP0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep GenerarOTP error de Caracter  M > nextStep: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      }

      this.sessionData.otpServiceData.valIdTokenOTP =
        responsegenerarOtp.data.response.tokenGenerado.valIdTokenOTP
      this.sessionData.otpServiceData.valTokenOTP =
        responsegenerarOtp.data.response.tokenGenerado.valTokenOTP
      this.sessionData.otpServiceData.fechaExpiracion =
        responsegenerarOtp.data.response.tokenGenerado.fecExpiracion
    }

    if (reqPayload.validarOtp) {
      const fechaExpiracion = moment(
        this.sessionData.otpServiceData.fechaExpiracion
      ).tz(this.parmsData.zonaHoraria)
      const fechaActual = moment()
        .tz(this.parmsData.zonaHoraria)
        .format(this.parmsData.formatoFechaOpe)
      const diferencia = fechaExpiracion.diff(fechaActual, 'minutes')
      if (diferencia < 0) {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            message: STATUS_MSG.MSG_crrt_019,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: '',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE,
          stepId: STEP_ID.OTP0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep validarOtp vigencia OTP > nextStep: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      }
      let responseValidarOtp
      try {
        responseValidarOtp = await this.validarOtp(reqPayload.valorOtp)
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al validar Otp: ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      if (
        responseValidarOtp.data.response.contextoRespuesta.resultadoTransaccion
          .valCaracterAceptacion !== 'B'
      ) {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,

            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: '',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE,
          stepId: STEP_ID.OTP0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep validarOtp Caracter de aceptacion M > nextStep: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      }

      if (!responseValidarOtp.data.response.esValidacionExitosa) {
        this.sessionData.otpServiceData.numeroIntentos =
          this.sessionData.otpServiceData.numeroIntentos + 1
        // Lógica cantidad de intentos
        if (this.sessionData.otpServiceData.numeroIntentos >= 3) {
          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal:
                this.sessionData.sesion.presentacion.consumer?.appConsumer
                  ?.canalId,

              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: IDIOMA,
              message: STATUS_MSG.MSG_crrt_018,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.OTP0010,
          }
          this.logger.debug(
            `${STEP}:getNextStep validarOtp Supero la cantidad de intentos > nextStep: ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,

            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: IDIOMA,
            message: STATUS_MSG.MSG_crrt_020,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: '',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE,
          stepId: STEP_ID.OTP0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep validarOtp OTP incorrecto > nextStep: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      }
      this.sessionData.otpServiceData.otp = reqPayload.valorOtp
      this.sessionData.biometria.retoOtp.tokenOTP = reqPayload.valorOtp

      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,

          kind: this.sessionData.dataProducto.moduloId,
          lenguaje: IDIOMA,
          message: '',
          modulo: this.parmsData.kind,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.PROD0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep validarOtp validación Exitosa> nextStep: ${JSON.stringify(
          nextStep
        )}`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }

    this.sessionData.otpServiceData.otp = reqPayload.valorOtp

    nextStep = {
      clientId: this.getClientId(),
      payload: {
        canal: this.sessionData.dataProducto.canalId,

        kind: this.sessionData.dataProducto.moduloId,
        lenguaje: IDIOMA,
        message: '',
        modulo: this.parmsData.kind,
        pais: this.sessionData.dataProducto.country,
        redirectPostMessage: '',
        tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.OTP0010,
    }
    this.logger.debug(
      `${STEP}:getNextStep validarOtp OTP Generada > nextStep: ${JSON.stringify(
        nextStep
      )}`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

  private generarOtp = async () => {
    const endpoint = `${this.config.getVars().back.autLivianaRootPath}/${
      this.parmsData.generarOtp.pathService
    }` // otp/generar

    this.logger.debug(
      `${STEP}:generarOtp - Endpoint: ${endpoint}`,
      this.sessionData.sesion.clientId
    )

    const transaccionID = moment().unix()
    // tally
    // const fechaOpe = momentTimezone().tz(this.parmsData.zonaHoraria).format(this.parmsData.formatoFechaOpe)
    const fechaOpe = momentTimezone()
      .tz(this.parmsData.zonaHoraria)
      .format(this.parmsData.formatoFechaOpe)
    const fechaAct = momentTimezone()
      .tz(this.parmsData.zonaHoraria)
      .format(this.parmsData.formatoFecha)
    this.sessionData.otpServiceData.fechaGeneracionOtp = fechaAct
    this.sessionData.otpServiceData.horaGeneracionOtp =
      UTILITIES.horaHHMMSSSeparador()

    const payload = {
      payload: {
        auditoriaJuridico: false, // obtener de objeto para mas micros
        auditoriaOperaciones: true,
        datapower: {
          codCanal: this.sessionData.dataProducto.canalId,
          codPais: this.sessionData.dataProducto.country.toLowerCase(),
        },
        juridico: null,
        operaciones: {
          consumer: {
            appConsumer: {
              canalId: this.sessionData.dataProducto.canalId,
              id: this.sessionData.dataProducto.moduloId,
              sessionId: this.sessionData.sesion.clientId,
            },
            deviceConsumer: {
              id: this.sessionData.dataProducto.deviceConsumerId,
              ip: this.sessionData.sesion.ip,
              locale: this.parmsData.locale,
              terminalId: this.sessionData.dataProducto.terminalId,
              userAgent: this.sessionData.dataProducto.userAgent,
            },
          },
          documento: {
            numero: this.sessionData.dataProducto.numeroDocumento,
            tipo: this.sessionData.dataProducto.tipoDocumento,
          },
          messages: {
            idService: this.parmsData.generarOtp.idService,
            requestService: '',
            responseService: '',
          },
          operation: {
            operationDate: new Date().toISOString(),
            statusResponse: {
              status:
                this.parmsData.generarOtp.operaciones.operation.statusResponse
                  .status,
            },
            type: this.parmsData.generarOtp.operaciones.operation.type,
          },
        },
        service: {
          cliente: {
            codTipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
            valNumeroIdentificacion:
              this.sessionData.dataProducto.numeroDocumento,
          },
          contextoSolicitud: {
            consumidor: {
              aplicacion: {
                idAplicacion: this.parmsData.idAplicacion,
              },
              canal: {
                idCanal: this.sessionData.dataProducto.canalId,
                idHost: this.sessionData.sesion.ip,
              },
              idConsumidor: this.parmsData.generarOtp.CanalTXValue,
              terminal: {
                codUsuario: this.parmsData.codUsuario,
                idTerminal: this.sessionData.dataProducto.terminalId,
                valOrigenPeticion: this.sessionData.sesion.ip,
                valPerfil: this.parmsData.generarOtp.perfil,
              },
            },
            operacionCanal: {
              codIdioma: this.parmsData.codIdioma,
              codMoneda: this.parmsData.codMoneda,
              codPais: this.parmsData.generarOtp.country,
              fecOperacion: fechaOpe,
              idSesion: this.sessionData.sesion.clientId,
              idTransaccion: transaccionID,
              valJornada: 0,
            },
            servicio: {
              idServicio: this.parmsData.generarOtp.idService,
            },
          },
          infoNotificacion: {
            valTipoOTP: this.parmsData.generarOtp.tipoOtp,
          },
          listaParametrosAdicionales: {
            parametroAdicional: [
              {
                valLlave: this.parmsData.generarOtp.FechaTX,
                valValor: this.sessionData.otpServiceData.fechaGeneracionOtp,
              },
              {
                valLlave: this.parmsData.generarOtp.HoraTX,
                valValor: this.sessionData.otpServiceData.horaGeneracionOtp,
              },
              {
                valLlave: this.parmsData.generarOtp.TipoTX,
                valValor: this.parmsData.generarOtp.TipoTXValue,
              },
              {
                valLlave: this.parmsData.generarOtp.CanalTX,
                valValor: this.parmsData.generarOtp.CanalTXValue,
              },
            ],
          },
        },
        tokenDatapower: this.parmsData.generarOtp.tokenDatapower,
      },
    }

    this.logger.debug(
      `${STEP}:generarOtp - Payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any
    try {
      serviceData = await axios.post(endpoint, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }
    this.logger.debug(
      `${STEP}:getNextStep -  generar Otp response: ${JSON.stringify(
        serviceData.data.response
      )} `,
      this.sessionData.sesion.clientId
    )

    return serviceData
  }

  private validarOtp = async (valorOtp: string) => {
    const transaccionID = moment().unix()

    const endpoint = `${this.config.getVars().back.autLivianaRootPath}/${
      this.parmsData.validarOtp.pathService
    }` // otp/validar

    this.logger.debug(
      `${STEP}:validarOTP - Endpoint: ${endpoint}`,
      this.sessionData.sesion.clientId
    )

    const fechaOpe = momentTimezone()
      .tz(this.parmsData.zonaHoraria)
      .format(this.parmsData.formatoFechaOpe)

    const payload = {
      payload: {
        auditoriaJuridico: false, // obtener de objeto para mas micros
        auditoriaOperaciones: true,
        datapower: {
          codCanal: this.sessionData.dataProducto.canalId,
          codPais: this.sessionData.dataProducto.country.toLowerCase(),
        },
        juridico: null,
        operaciones: {
          consumer: {
            appConsumer: {
              canalId: this.sessionData.dataProducto.canalId,
              id: this.sessionData.dataProducto.moduloId,
              sessionId: this.sessionData.sesion.clientId,
            },
            deviceConsumer: {
              id: this.sessionData.dataProducto.deviceConsumerId,
              ip: this.sessionData.sesion.ip,
              locale: this.parmsData.locale,
              terminalId: this.sessionData.dataProducto.terminalId,
              userAgent: this.sessionData.dataProducto.userAgent,
            },
          },
          documento: {
            numero: this.sessionData.dataProducto.numeroDocumento,
            tipo: this.sessionData.dataProducto.tipoDocumento,
          },
          messages: {
            idService: this.parmsData.validarOtp.idService,
            requestService: '',
            responseService: '',
          },
          operation: {
            operationDate: new Date().toISOString(),
            statusResponse: {
              status:
                this.parmsData.validarOtp.operaciones.operation.statusResponse
                  .status,
            },
            type: this.parmsData.validarOtp.operaciones.operation.type,
          },
        },
        service: {
          cliente: {
            codTipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
            valNumeroIdentificacion:
              this.sessionData.dataProducto.numeroDocumento,
          },
          contextoSolicitud: {
            consumidor: {
              aplicacion: {
                idAplicacion: this.parmsData.idAplicacion,
              },
              canal: {
                idCanal: this.sessionData.dataProducto.canalId,
                idHost: this.sessionData.sesion.ip,
              },
              idConsumidor: this.parmsData.generarOtp.CanalTXValue,
              terminal: {
                codUsuario: this.parmsData.codUsuario,
                idTerminal: this.sessionData.dataProducto.terminalId,
                valOrigenPeticion: this.sessionData.sesion.ip,
                valPerfil: this.parmsData.generarOtp.perfil,
              },
            },
            operacionCanal: {
              codIdioma: this.parmsData.codIdioma,
              codMoneda: this.parmsData.codMoneda,
              codPais: this.parmsData.generarOtp.country,
              fecOperacion: fechaOpe,
              idSesion: this.sessionData.sesion.clientId,
              idTransaccion: transaccionID,
              valJornada: 0,
            },
            servicio: {
              idServicio: this.parmsData.generarOtp.idService,
            },
          },
          infoToken: {
            valIdTokenOTP: this.sessionData.otpServiceData.valIdTokenOTP,
            valTokenOTP: valorOtp,
          },
          listaParametrosAdicionales: {
            parametroAdicional: [
              {
                valLlave: this.parmsData.validarOtp.FechaTX,
                valValor: this.sessionData.otpServiceData.fechaGeneracionOtp,
              },
              {
                valLlave: this.parmsData.validarOtp.HoraTX,
                valValor: this.sessionData.otpServiceData.horaGeneracionOtp,
              },
              {
                valLlave: this.parmsData.validarOtp.TipoTX,
                valValor: this.parmsData.validarOtp.TipoTXValue,
              },
              {
                valLlave: this.parmsData.validarOtp.CanalTX,
                valValor: this.parmsData.validarOtp.CanalTXValue,
              },
            ],
          },
          valTipoOTP: this.parmsData.validarOtp.tipoOtp,
        },
        tokenDatapower: this.parmsData.validarOtp.tokenDatapower,
      },
    }

    this.logger.debug(
      `${STEP}:validarOTP - Payload: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any
    try {
      serviceData = await axios.post(endpoint, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }
    this.logger.debug(
      `${STEP}:getNextStep -  validar Otp response: ${JSON.stringify(
        serviceData.data.response
      )} `,
      this.sessionData.sesion.clientId
    )

    return serviceData
  }
}
