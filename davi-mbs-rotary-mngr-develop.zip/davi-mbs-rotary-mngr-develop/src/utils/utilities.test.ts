import { UTILITIES } from './utilities'

describe('Utilities', () => {
  const ingresos = [
    {
      principalIN: 'N',
      valorIN: '0',
    },
    {
      principalIN: 'Y',
      valorIN: '0',
    },
  ]

  const ingresosN = [
    {
      principalIN: 'N',
      valorIN: '0',
    },
    {
      principalIN: 'N',
      valorIN: '0',
    },
  ]

  const direccionesN = [
    { direccionPrincipalDI: 'N', direccion: 'calle 123' },
    { direccionPrincipalDI: 'N', direccion: 'calle 321' },
  ]

  const emailsN = [
    { correoPrincipalEM: 'N', emailEM: 'test@email.com' },
    { correoPrincipalEM: 'N', emailEM: 'test1@email.com' },
  ]

  const celularesN = [
    {
      celularPrincipalCL: 'N',
      numero: '123456',
    },
    {
      celularPrincipalCL: 'N',
      numero: '654321',
    },
  ]

  const direcciones = [
    { direccionPrincipalDI: 'Y', direccion: 'calle 123' },
    { direccionPrincipalDI: 'N', direccion: 'calle 321' },
  ]

  const emails = [
    { correoPrincipalEM: 'Y', emailEM: 'test@email.com' },
    { correoPrincipalEM: 'N', emailEM: 'test1@email.com' },
  ]

  const celulares = [
    {
      celularPrincipalCL: 'N',
      numero: '123456',
    },
    {
      celularPrincipalCL: 'Y',
      numero: '654321',
    },
  ]

  it('horaHHMMSS retorna la hora en el formato especificado', () => {
    expect(UTILITIES.horaHHMMSS()).toMatch(/(?:\d{1}|\d{2})(\d{2})(\d{2})/)
  })
  it('Buscar ingreso clientePn', () => {
    expect(UTILITIES.buscarIngresosPN(ingresos, false)).toBe(ingresos[1])
  })

  it('Buscar ingreso clientePn N', () => {
    expect(UTILITIES.buscarIngresosPN(ingresosN, true)).toBe(ingresosN[0])
  })

  it('Buscar direccion trae la direccion principal', () => {
    expect(UTILITIES.buscarDireccion(direcciones)).toBe(direcciones[0])
  })

  it('Buscar email PN trae el objeto con la direccion de email principal', () => {
    expect(UTILITIES.buscarEmailPn(emails)).toBe(emails[0])
  })

  it('Buscar celular cliente PN', () => {
    expect(UTILITIES.buscarCelularPn(celulares)).toBe(celulares[1])
  })

  it('Buscar direccion trae la direccion No principal', () => {
    expect(UTILITIES.buscarDireccion(direccionesN)).toBe(undefined)
  })

  it('Buscar email PN trae el objeto con la direccion de email No principal', () => {
    expect(UTILITIES.buscarEmailPn(emailsN)).toBe(undefined)
  })

  it('Buscar celular cliente PN No principal', () => {
    expect(UTILITIES.buscarCelularPn(celularesN)).toBe(undefined)
  })

  it('fechaYYYYMMDDTHHMMSS retorna la fecha en el formato esperado', () => {
    const expected = UTILITIES.fechaYYYYMMDDTHHMMSS()
    const match = /(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})$/
    expect(expected).toMatch(match)
  })
})
