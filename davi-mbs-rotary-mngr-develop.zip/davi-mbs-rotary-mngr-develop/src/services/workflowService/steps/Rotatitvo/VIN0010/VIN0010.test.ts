//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { PRODUCTO } from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { VIN0010 } from '@services/workflowService/steps/Rotatitvo/VIN0010/VIN0010'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'

import axios from 'axios'

const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        parmsServiceUrl: 'http://catalogo/v1',
      },
    }
  }
}

const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    numeroCuentaVincular: '05503125413411',
    tipoCuentaVincular: '01',
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.VIN0010,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const valParmsResponse = {
  data: {
    data: {
      sessionTimeout: '600000',
    },
    status: 200,
  },
}

const valParmsResponseAux = {
  data: {
    data: {
      sessionTimeout: '',
    },
    status: 200,
  },
}

const mockWfData = new WorkflowData(mockPresentacion)
const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)
const serviceUrls = {
  parametros: `http://catalogo/v1/parms/services.workflow.VIN0010?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO.CRRT}`,
}

let step: VIN0010
let nextStep: IStepData

describe('VIN0010', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para BYC0010
   *
   */

  test('Instancia correctamente del objeto VIN0010', () => {
    step = new VIN0010(stepData, mockWfData, config, logger)
    expect(step).toBeDefined()
  })

  test('Validación del objeto VIN0010 con payload correcto (no retorna mensaje de error)', () => {
    expect(step.isRequestValid()).toBeTruthy()
  })

  test('Validación del objeto VIN0010 con payload incorrecto (si retorna mensaje de error)', () => {
    const badStepData: IStepData = {
      clientId: 'abc123',
      payload: {
        bad: '',
      },
      stepId: STEP_ID.VIN0010,
    }
    const badStep = new VIN0010(badStepData, mockWfData, config, logger)
    expect(badStep.isRequestValid()).toBeFalsy()
    expect(badStep.getRequestValidationError().length).toBeGreaterThan(0)
  })

  /*
   *
   *  Verificacion del flujo para VIN0010
   *
   */
  test('Validación del getCurrentStep retorna valor del request', () => {
    expect(step.getCurrentStep()).toEqual(stepData.stepId)
  })

  test('VIN0010 => Presentación sin sessionTimeOut | consultaParametros', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new VIN0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })
  test('VIN0010 => Presentación con sessionTimeOut | consultaParametros', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new VIN0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  /*
   *
   *  Verificación de errores al llamar servicios
   *
   */

  test('VIN0010 => Cliente con error al consultar parametros -> Error 500 | CRRT', async (done) => {
    const valParmsResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new VIN0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('VIN0010 => Cliente con error en axios al consultar parametros -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new VIN0010(stepData, mockWfData, config, logger)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })
})
