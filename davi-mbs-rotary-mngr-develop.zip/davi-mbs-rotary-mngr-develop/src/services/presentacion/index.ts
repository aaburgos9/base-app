//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { INuevaSesion, IPresentacionRequest, } from '@services/presentacion/presentacion.model'

export interface IPresentacionService {
  crear(presentacionEncriptada: IPresentacionRequest): Promise<INuevaSesion>
}
