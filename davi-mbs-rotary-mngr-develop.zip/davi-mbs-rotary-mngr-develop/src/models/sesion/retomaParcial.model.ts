export class RetomaParcial {
  /*
   * Atributos
   */
  public status: boolean = false
  public nroSolicitud: string = ''

  /*
   * Metodo constructor (inicialización) de la clase RetomaParcial
   */
  constructor(status: false, nroSolicitud: string) {
    this.status = status
    this.nroSolicitud = nroSolicitud
  }
}
