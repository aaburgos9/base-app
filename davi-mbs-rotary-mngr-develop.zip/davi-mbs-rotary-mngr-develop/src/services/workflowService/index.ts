//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IStepData } from '@services/workflowService/steps/stepData.model'

export interface IWorkflowService {
  getNextStep(stepData: IStepData): Promise<IStepData>
}
