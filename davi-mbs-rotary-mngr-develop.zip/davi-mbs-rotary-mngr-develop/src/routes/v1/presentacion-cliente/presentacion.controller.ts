//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

/* LIBRERIAS Y DEPENDENCIAS */
import { TYPES } from '@config/ioc/types'
import { IResponse } from '@models/response.model'
import { ILogger } from '@services/loggerService'
import { IPresentacionService } from '@services/presentacion'
import { IPresentacionRequest } from '@services/presentacion/presentacion.model'
import * as express from 'express'
import { inject } from 'inversify'
import {
  controller,
  httpPost,
  interfaces,
  next,
  request,
  response,
} from 'inversify-express-utils'
import joi from 'joi'
import { presentacionRequestSchema } from './presentacion.model'

/* CONTROLADOR */
@controller('/presentacion-cliente')
export class PresentacionController implements interfaces.Controller {
  constructor(
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IPresentacionService)
    private presentacion: IPresentacionService
  ) {}

  /* METODO POST PARA ATENDER LA PRESENTACION DE CLIENTE */
  @httpPost('/')
  public async create(
    @request() req: express.Request,
    @response() res: express.Response,
    @next() nextFunc: express.NextFunction
  ) {
    const data = req.body
    this.logger.debug('PresentacionCliente rotativo: REQUEST => ', JSON.stringify(data))
    const validationResult = joi.validate(data, presentacionRequestSchema)
    if (validationResult.error) {
      // Si la validación de los datos de la solicitud falla, entonces retornar error 422
      this.logger.error(`POST /v1/presentacion-cliente - Formato de request invalido: ${validationResult.error}`)
      const httpResponse: IResponse = {
        data,
        errors: ['Invalid data on request'],
      }
      res.status(422).json(httpResponse)
      nextFunc()
      return
    }

    // El formato de los datos de la solicitud es el esperado, entonces continuar
    // con la creación de la presentacion de clientes
    const presentacionData: IPresentacionRequest = validationResult.value
    let sesionData
    try {
      sesionData = await this.presentacion.crear(presentacionData)
    } catch (error) {
      this.logger.error(`POST /v1/presentacion-cliente - Error al crear presentacion de cliente: ${error.message} / ${error.internalError.message}`)
      const httpResponse: IResponse = {
        data,
        errors: [error.message],
      }
      res.status(error.statusCode).json(httpResponse)
      nextFunc()
      return
    }

    // Si no hubo errores, responder la solicitud con 200
    const httpOkResponse: IResponse = {
      data: sesionData,
      errors: [],
    }
    res.json(httpOkResponse)
    nextFunc()
    return
  }
}
