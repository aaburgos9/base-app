//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface IPresentacionClientes {
  client?: {
    name?: string
    email?: string
    documentClient?: {
      type?: string
      number?: string
      expeditionCity?: string
      expeditionDate?: string
    }
    phoneNumber?: {
      countryId?: string
      number?: string
    }
  }
  consumer?: {
    appConsumer?: {
      id?: string
      sessionId?: string
      transactionId?: string
      canalId?: string
      terminalId?: string
      appVersion?: string
      soVersion?: string
    }
    deviceConsumer?: {
      id?: string
      userAgent?: string
      locale?: string
      sessionTimeout?: string
      inactiveInterval?: string
      phoneNumber?: string
    }
    genericData?: {
      dataItem?: IGenericDataItem[]
    }
  }
  linkrotativo?: string
  montoProducto?: string
  nombreProducto?: string
  module?: {
    id?: string
    country?: string
    language?: string
  }
  motorRSA?: {
    deviceRequest?: {
      deviceFingerPrint?: string
      devicePrint?: string
      deviceTokenCookie?: string
      httpAccept?: string
      httpAcceptEncoding?: string
      httpAcceptLanguage?: string
      httpReferrer?: string
      ipAddress?: string
      userAgent?: string
    }
    identificationData?: {
      orgNane?: string
      sessionId?: string
      userLanguage?: string
      username?: string
    }
    instanceId?: string
    messageHeader?: {
      apiType?: string
      requestId?: string
      requestType?: string
      timeStamp?: string
      version?: string
    }
    mobile?: {
      mobileInfoSdk?: string
      otherId?: string
    }
    securityHeader?: {
      callerCredential?: string
      callerId?: string
      method?: string
    }
  }
  partner?: {
    id?: string
    callbackUrl?: {
      denial?: string
      error?: string
      success?: string
    }
  }
  product?: {
    id?: string
    country?: string
  }
}

export interface IGenericDataItem {
  key?: string
  value?: string
}
