//
// Copyright (C) 2022 - Banco Davivienda S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { INuevaSesion, IPresentacionRequest, } from '@services/presentacion/presentacion.model'
import { PresentacionService } from '@services/presentacion/presentacionService'
import { createRequest, createResponse } from 'node-mocks-http'
import { PresentacionController } from './presentacion.controller'

jest.mock('@services/presentacion/presentacionService')

const mockConfigVars = {
  back: {
    authServiceUrl: 'http://mbaas/auth',
    persistenceServiceUrl: 'http://mbaas/persistence',
  },
  front: {
    url: 'http://mbaas/rotativo#',
  },
}
class MockConfig implements IConfig {
  public getVars = () => {
    return mockConfigVars
  }
}

describe('PresentacionController', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('debug')
  const persistence = new PersistenceService(config, logger)
  const auth = new AuthService(config)
  const crypto = new CryptoService(auth, logger)
  const presentacion = new PresentacionService(config, logger, persistence, auth, crypto)
  let presentacionController: PresentacionController

  const mockOtpToken = 'eyJhbGciOiJSUzI1NiIsImprdSI6Imh0dHBzOi8vdGVzdC5jbG91ZC5kYXYubmV0Ly53ZWxsLWtub3duL2p3a3MuanNvbiIsImtpZCI6IjE1NTE4MTc4MjkifQ.eyJhdWQiOiJEQVY6Q0xPVUQ6QVVUSCIsImV4cCI6IjE4Njg2Njc3NzkiLCJpYXQiOiIxNTUzMDkxNzc5IiwiaXNzIjoiREFWOkNMT1VEOkFVVEgiLCJzdWIiOiJhYmMxMjMiLCJ1c2UiOiJvIiwianRpIjoiYTlmODE5YzAtNGIxYi0xMWU5LThlYjItOTE1YTA0OTZlNTQ1In0.BiEUUmU8UMBJfWX5k6SXSW20zXC_P_HwLXf4UOVxIeLWPa4-1S6PCcSqjAFWOl5bgY5NdIDhUQWg4VCCY5tOLzwfun02QRqCX5sW8bmXg63p91MVKZwTL9-fkE2-Kb5ZM1cVqTSsKNfxhX3K0g_1zylPV53xvi_9nwoGtAsLszV_V6fZtydjAP9KtC_laBIiTL0ijx248W4LV7uYwGxjnBQTwK-mUoJKeoFp6IUXp75zlD0cBOu6KJGQgbnEFI6Igf71DSE-aE0_WUS7uVbHMhJ8uhyLfj3GJt9VjScKmHjeOptS6iOS1B7Zcri2D_mlcBIVj6fkqJQrFxyPMhkQmw'
  const mockPresentacion: IPresentacionRequest = {
    data: 'eyJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiMTU1MzEzMzAwNiIsImFsZyI6IlJTQS1PQUVQLTI1NiJ9.dotTb16DmWGha5TcfGP5bV5cnqjp6izjCAGG9gUWWF_7PWAhkndHbhFVh5znMeCfnbZyJE79BtRLFRK6o_pv1DKxTfr9M59SOPYDvYi6pFSHNuVfKaJYa4ZJDN6XCzDD5PZEhfgdjU6KKDnasrRSdHGpmn-dLTxV-tzqkB0yKVAPnPLn4-EGbQTxS1JrBvpzu1NhWEtHruVNXZebeWE6N8P-boAu0r64ZjXq9WjQ7nHVjHmi1tRE83xMSX5eLfYY_sk8iENED_i6cxtiBzItMOpYIyW-eMH-daNGaPmo5A86Z5-yZrsMqFLtmzEl66E8NQkJdH9Btwr_Hn0pG9NosA.0HTrGo6fy9a-aUFb5vvx-A.Pq5iQflS00QS9EE9oGU2q2mkC4sxfVu7dRLvJYpF40R8lruXCLjp-PNlUGjXPJNOJzUVfFRYTpxTGEoJxuaQ8qgxG1zHVnlkOsUcUulUFIlg1X7QhJv7T6r8rASHsQ0-cdtQuXeleVwmOl__tHPPcXwkHRh6zKFJtCFc0i1ysEoY0QQ_mWmxn_t9M4mqWnwNiRRbvmWV_6BbeZUI1KhUfPo8HiI3ce57qVbDFlB123KeZJOo8U4Kd_ZOwzrmzBdo-D7OjPcHkIhreNE4RrIGmA.5UyPqX8dIZO9iadUh9IIZDKbHb2UcDMuGz8C5kb7GJU',
  }

  test('Instancia correctamente', () => {
    presentacionController = new PresentacionController(logger, presentacion)
    expect(presentacionController).toBeDefined()
  })

  test('POST con body correcto retorna 200 y datos de sesion', async done => {
    // Preparacion de HTTP props
    const req = createRequest({body: mockPresentacion, method: 'POST', url: `/protraw/v1/presentacion-cliente`,})
    const res = createResponse()
    const next = () => {
      done()
    }

    // mock de presentacion
    const sessionData: INuevaSesion = {
      appUrl: `${mockConfigVars.front.url}/${mockOtpToken}`,
      clientId: 'abc123',
      otp: mockOtpToken,
    }
    /*presentacion.crear = jest.fn((p: IPresentacionClientes) => {
      return Promise.resolve(sessionData)
    })*/
    presentacion.crear = jest.fn((p: IPresentacionRequest) => {
      return Promise.resolve(sessionData)
    })

    // llamada a metodo y finalizacion de response
    try {
      await presentacionController.create(req, res, next)
      res.end()
      const data = JSON.parse(res._getData())
      expect(res._getStatusCode()).toEqual(200)
      expect(data.errors.length).toBe(0)
      expect(data.data).toEqual(sessionData)
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('POST con body invalido retorna error 422', async done => {
    // Preparacion de HTTP props
    const req = createRequest({body: { hola: 'mundo' }, method: 'POST', url: `/protraw/v1/presentacion-cliente`,})
    const res = createResponse()
    const next = () => {
      done()
    }

    // llamada a metodo y finalizacion de response
    try {
      await presentacionController.create(req, res, next)
      res.end()
      const data = JSON.parse(res._getData())
      expect(res._getStatusCode()).toEqual(422)
      expect(data.errors.length).toBe(1)
      expect(data.errors[0]).toEqual('Invalid data on request')
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('POST con body correcto y error al crear presentacion retorna error', async done => {
    // Preparacion de HTTP props
    const req = createRequest({body: mockPresentacion, method: 'POST', url: `/protraw/v1/presentacion-cliente`,})
    const res = createResponse()
    const next = () => {
      done()
    }

    // mock de presentacion
    const sessionError = new ServiceError(
      MBAAS_ERRORS.internal_server_error,
      new Error('ups-en-presentacion')
    )
    /*presentacion.crear = jest.fn((p: IPresentacionClientes) => {
      return Promise.reject(sessionError)
    })*/
    presentacion.crear = jest.fn((p: IPresentacionRequest) => {
      return Promise.reject(sessionError)
    })

    // llamada a metodo y finalizacion de response
    try {
      await presentacionController.create(req, res, next)
      res.end()
      const data = JSON.parse(res._getData())
      expect(res._getStatusCode()).toEqual(500)
      expect(data.errors.length).toBe(1)
      expect(data.errors[0]).toEqual('internal_server_error')
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })
})
