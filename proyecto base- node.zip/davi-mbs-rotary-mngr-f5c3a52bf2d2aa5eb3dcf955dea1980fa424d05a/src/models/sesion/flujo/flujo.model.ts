//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class FlujoData {
  /*
   * Atributos
   */
  public steprotativo000: boolean = false

  /*
   * Metodo constructor (inicialización) de la clase FlujoData
   */
  constructor(
    steprotativo000: boolean,
  ) {
    this.steprotativo000 = steprotativo000
  }
}
