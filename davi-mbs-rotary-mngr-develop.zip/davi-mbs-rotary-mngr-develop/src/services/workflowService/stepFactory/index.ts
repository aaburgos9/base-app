//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { WorkflowData } from '@models/workflowData.model'
import { IStep } from '@services/workflowService/steps/step'
import { IStepData } from '@services/workflowService/steps/stepData.model'

export interface IStepFactory {
  get(stepData: IStepData, sessionData: WorkflowData): IStep
}
