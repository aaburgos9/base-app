//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum STEP_ID {
  /**
   * MBaaS Boot
   */
  rotativo000 = 'rotativo000',

  /**
   * Pantalla:
   *
   * Autorizaciones
   */
  rotativo010 = 'rotativo010',

  /**
   * Pantalla:
   *
   * Autorizaciones
   */
  rotativo020 = 'rotativo020',
  rotativo00001 = 'rotativo00001',
  PENDIENTE = 'PENDIENTE',
}
