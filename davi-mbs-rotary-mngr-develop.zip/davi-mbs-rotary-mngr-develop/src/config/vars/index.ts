//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface IConfig {
  getVars: () => any
}
