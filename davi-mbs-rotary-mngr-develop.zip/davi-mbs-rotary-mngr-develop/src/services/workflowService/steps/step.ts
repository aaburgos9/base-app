//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import joi from 'joi'

export interface IStep {
  logger: ILogger
  config: IConfig
  sessionData: WorkflowData
  getNextStep(): Promise<IStepData>
  getClientId(): string
  getCurrentStep(): STEP_ID
  getRequestPayload(): any
  isRequestValid(): boolean
  getRequestValidationError(): string
}

export abstract class Step implements IStep {
  public config: IConfig
  public logger: ILogger
  public sessionData: WorkflowData
  private isRequestPayloadValid = true
  private requestPayloadError = ''
  private requestData: IStepData

  constructor(
    stepData: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger,
    validationSchema: joi.SchemaLike
  ) {
    this.requestData = stepData
    this.sessionData = sessionData
    this.config = config
    this.logger = logger

    // Validar payload
    const validationResult = joi.validate(stepData.payload, validationSchema)
    if (validationResult.error) {
      this.isRequestPayloadValid = false
      this.requestPayloadError = validationResult.error.message
    }
  }

  public abstract getNextStep(): Promise<IStepData>

  public getClientId = () => this.requestData.clientId
  public getCurrentStep = () => this.requestData.stepId
  public getRequestPayload = () => this.requestData.payload
  public isRequestValid = () => this.isRequestPayloadValid
  public getRequestValidationError = () => this.requestPayloadError
}
