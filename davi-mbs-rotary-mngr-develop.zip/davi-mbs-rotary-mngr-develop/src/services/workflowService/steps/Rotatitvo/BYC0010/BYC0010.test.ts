//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { PRODUCTO } from '@models/enums/productoPais.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { BYC0010 } from '@services/workflowService/steps/Rotatitvo/BYC0010/BYC0010'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'

import axios from 'axios'
import { GrabarInformacionSolicitudesModel } from '~/models/servicios/grabarInformacionSolicitudes'

const CANAL: string = '37'
const MODULO: string = 'CRRT'
const IDIOMA: string = 'ES'
const PAIS: string = 'CO'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        autLivianaEliminarPersistencia:
          'http://localhost:5080/autenticacionliviana/v1/eliminacionPersistenciaCredito',
        credito2NegocioService: 'http://localhost:5050/api/v1',
        parmsServiceUrl: 'http://catalogo/v1',
        persistenceServiceUrl: 'http://localhost:5003/persistence/v1',
        prevalidacionServiceUrl: 'http://localhost:5012/prevalidacion/v1',
        rotativoServiceUrl: 'http://rotativo/v1',
        soapWebService: 'http://localhost:6044/v1',
        validacionPreviaServiceUrl: 'http://localhost:6030/vpr/v1',
      },
    }
  }
}

const stepData: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    prevalidacion: true,
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.BYC0010,
}

const stepDataAtras: IStepData = {
  clientId: 'abc123',
  payload: {
    atras: false,
    prevalidacion: false,
  },
  status: STATUS_ID.NORMAL,
  stepId: STEP_ID.BYC0010,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const mockPresentacionAux: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '111222333',
      type: '01',
    },
    email: 'mariahelena@gmail.com',
    name: 'Maria del Carmen Helena',
  },
  consumer: {
    appConsumer: {
      canalId: '37',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4',
    },
  },
  module: {
    country: 'CO',
    id: 'CRRT',
  },
  partner: {
    callbackUrl: {
      error: 'https://www.davivienda.com/error',
      success: 'https://www.davivienda.com',
    },
  },
}

const valParmsResponse = {
  data: {
    data: {
      autLivianaEliminarPersistencia: {
        caracterAceptacionSvc: 'B',
        tipoOperacionLog: 'ELIMINAR_PERSISTENCIA_CREDITO',
      },
      codIdioma: 'ES',
      consultaClientePN: {
        tipoOperacionLog: 'CONSULTA_CLIENTE',
      },
      consultaPersistenciaCredito: {
        codMsgRespuesta: 4842,
        nuevaSolicitud: 'R',
        retomaSolicitud: 'V',
      },
      consultaProductos: {
        Data: {
          codProducto: '0',
          codSubProducto: '0',
          valCompania: '0',
          valIndicadorConsultarCertificadoCDTS: '0',
          valIndicadorConsultarCreditosFM: '0',
          valIndicadorConsultarCuentasAhorros: '1',
          valIndicadorConsultarCuentasCorrientes: '1',
          valIndicadorConsultarDabuenvida: '0',
          valIndicadorConsultarEstablecimientos: '0',
          valIndicadorConsultarFondosInversion: '0',
          valIndicadorConsultarTarjetasCreditoAmparadas: '0',
          valIndicadorConsultarTarjetasCreditoPropias: '0',
          valNumeroProducto: '0',
          valVinculacion: '0',
        },
        DataHeader: {
          jornada: '0',
          modoDeOperacion: '0',
          perfil: '0',
          total: '2235',
          usuario: 'MBaaS',
          versionServicio: '2.0.1',
        },
        caracterAceptacionSvc: 'B',
        codMsgRespuesta: 1011,
        cuentaAhorros: 'Cuenta de Ahorros',
        cuentaCorriente: 'Cuenta Corriente',
        idService: 'ConsultasProductos',
        keyService: 'eZm220',
        logger: 'v1',
        motivoRechazoConsultaProductos: '9',
        noBloqueoAhorros: '01',
        noBloqueoCorriente: '00',
        subProductosValidos: ['0001', '0002', '0008', '0029', '2001', '2081'],
        type: 'CONSULTA',
        urlServiceOption: '1',
        valCodigoProducto: 550,
        valIndicadorEmbargo: 0,
        vigenteAhorro: 1,
        vigenteCorriente: 1,
      },
      consultaRotativo: {
        Data: {
          codIdioma: 'co',
          codPais: 'co',
        },
        DataHeader: {
          jornada: '0',
          modoDeOperacion: '0',
          perfil: '0',
          total: '0',
          usuario: 'WEL',
          versionServicio: '1.0.0',
        },
        cantidadRotativos: 0,
        caracterAceptacionSvc: 'B',
        idService: 'ConsultarCreditosRotativoXCliente',
        keyService: 'KCI907',
        logger: 'V1',
        motivoRechazoRotativo: '8',
        type: 'CONSULTA',
        urlServiceOption: '2',
      },
      destinoCredito: '',
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        indicadorConSeguro: '',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '1',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      listasRestrictivas: {
        codigoSolicitud: 'SOLCREDIG',
        listasAsegurables: ['ASEGURADORA 1', 'ASEGURADORA 2'],
        motivoRechazoListas: '4',
        tipoOperacionLog: 'LISTAS_RESTRICTIVAS',
        tipoPersona: 'N',
        valRespuesta: ['S', 'I'],
        valRespuestaI: 'I',
      },
      locale: 'CO',
      loggerVersion: 'v1',
      periodicidadPago: 'M',
      productosEnMora: {
        data: {
          valProductoRrpSolicitado: '0140',
          valSubproductoRprSolicitado: '7001',
        },
        dataHeader: {
          jornada: '0',
          modoDeOperacion: '0',
          nombreOperacion: 'ValidacionProductosEnMora',
          perfil: '0',
          usuario: 'WEL',
          versionServicio: '1.0.0',
        },
        idService: 'ValidacionProductosEnMora',
        operaciones: {
          operation: {
            statusResponse: {
              status: 'OK',
            },
            type: 'VALIDACIONES_INGRESO',
          },
        },
      },
      sessionTimeout: '600000',
      terminalId: '370062',
      total: '370000',
    },
    status: 200,
  },
}

const valParmsResponseAux = {
  data: {
    data: {
      codIdioma: 'ES',
      consultaClientePN: {
        tipoOperacionLog: 'CONSULTA_CLIENTE',
      },
      consultaPersistenciaCredito: {
        codMsgRespuesta: 4842,
        nuevaSolicitud: 'R',
        retomaSolicitud: 'V',
      },
      destinoCredito: '',
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        indicadorConSeguro: '',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '3',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      listasRestrictivas: {
        codigoSolicitud: 'SOLCREDIG',
        listasAsegurables: ['ASEGURADORA 1', 'ASEGURADORA 2'],
        motivoRechazoListas: '4',
        tipoOperacionLog: 'LISTAS_RESTRICTIVAS',
        tipoPersona: 'N',
        valRespuesta: ['S', 'I'],
        valRespuestaI: 'I',
      },
      locale: 'CO',
      loggerVersion: 'v1',
      periodicidadPago: 'M',
      sessionTimeout: '',
      terminalId: '370062',
      total: '370000',
    },
    status: 200,
  },
}

const valParmsResponseAux2 = {
  data: {
    data: {
      codIdioma: 'ES',
      consultaClientePN: {
        tipoOperacionLog: 'CONSULTA_CLIENTE',
      },
      consultaPersistenciaCredito: {
        nuevaSolicitud: 'R',
        retomaSolicitud: 'V',
      },
      destinoCredito: '',
      grabarInformacionSolicitudes: {
        codigoProductoCarteraFm2000Solicitado: '0',
        codigoPromocion: '',
        indicadorConSeguro: '',
        indicadorSinSeguro: '',
        numeroProcesoDeceval: '6',
        numeroProcesoEvaluacion: '3',
        numeroProcesoGestionDocumental: '8',
        numeroProcesoOriginacion: '7',
        numeroProcesoValidacionIngreso: '6',
        numeroSolicitudFm2000: '0',
      },
      grupoProductoRPRBuro: '0150',
      grupoSubproductoRPRBuro: '3754',
      listasRestrictivas: {
        codigoSolicitud: 'SOLCREDIG',
        listasAsegurables: ['ASEGURADORA 1', 'ASEGURADORA 2'],
        motivoRechazoListas: '4',
        tipoOperacionLog: 'LISTAS_RESTRICTIVAS',
        tipoPersona: 'N',
        valRespuesta: ['S', 'I'],
        valRespuestaI: 'I',
      },
      locale: 'CO',
      loggerVersion: 'v1',
      periodicidadPago: 'M',
      sessionTimeout: '600000',
      terminalId: '370062',
      total: '370000',
    },
    status: 200,
  },
}

const valParmsResponseAREASGEOGRAFICAS = {
  data: {
    data: [
      {
        listaCiudades: [
          {
            codCiudad: '16991001',
            descCiudad: 'LETICIA',
            descDepto: 'AMAZONAS',
            viable: false,
          },
          {
            codCiudad: '16991001',
            descCiudad: 'LETICIA',
            descDepto: 'AMAZONAS',
            viable: false,
          },
          {
            codCiudad: '16991001',
            descCiudad: 'LETICIA',
            descDepto: 'AMAZONAS',
            viable: false,
          },
        ],
      },
    ],
  },
  status: 200,
}

const mockConsultaPersistenciaResponse = {
  data: {
    Response: {
      Data: {
        CupoAprobadoWhiteList: 0,
        FechaWhiteList: 0,
        GMF: 0,
        IndicadorAceptacionCliente: 0,
        PlazoAprobadoM1: 0,
        agenteVendedor: 405070,
        aplicacionOrigen: 37,
        capitalVtu: 0,
        causalNegacion1: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion2: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion3: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion4: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion5: 'VC058 - Contraoferta. Plazo Optimo',
        ciudadEntregaTarjeta: 0,
        ciudadResidencia: 0,
        codigoProductoCarteraFm2000Solicitado: 0,
        codigoProductoRprCuentaDesembolsar: 0,
        codigoProductoRprSolicitado: 140,
        codigoPromocion: '0',
        codigoSubproductoRprCuentaDesembolsar: 0,
        codigoSubproductoRprSolicitado: 7002,
        convenio: 0,
        decision: 'CNT',
        descripcionProductoDigital: 'Vehiculo Movil',
        factorPorMillon: 1158.33,
        fecFechaInicioSolicitudAnterior: 0,
        fecFechaRtaSolicitudSeguroAdquirido: 20230209,
        fecHoraRtaSolicitudSeguroAdquirido: 151416,
        fechaAutenticacion: '0',
        fechaEvaluacion1erMotor: 20230209,
        fechaIngresoEmpresaReportadaCliente: 0,
        fechaProceso: 20230209,
        fechaRegistroOTP: '0',
        fechaSimulacion: 20230209,
        grupoConvenio: 0,
        horaAutenticacion: '0',
        horaEvaluacionPrimerMotor: '0',
        horaProceso: 151416,
        horaRegistroOTP: '0',
        horaSimulacion: '0',
        idDocumentoPagare: 0,
        indUsoPVenta: '0',
        indicadorEstadoCompraC: 0,
        ingresoFinal: 0,
        ingresoMensuales: 3000000,
        interesVtu: 0,
        montoMaximoContraOferta: 0,
        nitEmpresaDondeTrabaja6: 0,
        nroIdentificacion: 1025874469,
        nroProceso: 3,
        nroSolicitud: 129136,
        numNitConvenio: '0',
        numeroCuentaDesembolsar: 0,
        ocupacionIndependiente: 0,
        oficinaCliente: 60,
        oficinaSelecRecogeCheque: 0,
        periocidadPago: 'M',
        plazoMaximoContraofertadoMotor: 0,
        plazoSolicitado: 0,
        porcentajeVtu: 0,
        riesgoConvenio: 0,
        rprCalificacionWhiteList: 0,
        scorePrecioCliente: 0,
        seguroVidaItpVtu: 0,
        spreed: 0,
        tasaAprobadaEfectivaAnual: 36.86,
        tasaAprobadaMesVencido: 2.6491,
        tipoContrato: 0,
        tipoIdentificacion: 1,
        totalVtu: 0,
        uRLProductoDigital: '/1/',
        valAceptado: 0,
        valCumulo: 0,
        valIndicadorAceptacionSeguro: 'N',
        valNumeroChequesRecoger: 0,
        valSeguro: 29179,
        valTotalObligacionesComprar: 0,
        valorAprobado: 0,
        valorCuotaMensual: 412000,
        valorFinalCreditoIncluidoCola: 11000000,
        valorGMFSimulacion: '0.00',
        valorMaximoContraofertadoMotor: 0,
        valorSolicitado: 0,
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: 0,
        idTransaccion: '2303082221',
        nombreOperacion: 'ConsultaPersistenciaCredito',
        total: 370019,
        ultimoMensaje: 1,
      },
    },
  },
}
const mockConsultaPersistenciaResponseFallido = {
  data: {
    Response: {
      Data: {
        CupoAprobadoWhiteList: 0,
        FechaWhiteList: 0,
        GMF: 0,
        IndicadorAceptacionCliente: 0,
        PlazoAprobadoM1: 0,
        agenteVendedor: 405070,
        aplicacionOrigen: 37,
        capitalVtu: 0,
        causalNegacion1: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion2: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion3: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion4: 'VC058 - Contraoferta. Plazo Optimo',
        causalNegacion5: 'VC058 - Contraoferta. Plazo Optimo',
        ciudadEntregaTarjeta: 0,
        ciudadResidencia: 0,
        codigoProductoCarteraFm2000Solicitado: 0,
        codigoProductoRprCuentaDesembolsar: 0,
        codigoProductoRprSolicitado: 140,
        codigoPromocion: '0',
        codigoSubproductoRprCuentaDesembolsar: 0,
        codigoSubproductoRprSolicitado: 7002,
        convenio: 0,
        decision: 'CNT',
        descripcionProductoDigital: 'Vehiculo Movil',
        factorPorMillon: 1158.33,
        fecFechaInicioSolicitudAnterior: 0,
        fecFechaRtaSolicitudSeguroAdquirido: 20230209,
        fecHoraRtaSolicitudSeguroAdquirido: 151416,
        fechaAutenticacion: '0',
        fechaEvaluacion1erMotor: 20230209,
        fechaIngresoEmpresaReportadaCliente: 0,
        fechaProceso: 20230209,
        fechaRegistroOTP: '0',
        fechaSimulacion: 20230209,
        grupoConvenio: 0,
        horaAutenticacion: '0',
        horaEvaluacionPrimerMotor: '0',
        horaProceso: 151416,
        horaRegistroOTP: '0',
        horaSimulacion: '0',
        idDocumentoPagare: 0,
        indUsoPVenta: '0',
        indicadorEstadoCompraC: 0,
        ingresoFinal: 0,
        ingresoMensuales: 3000000,
        interesVtu: 0,
        montoMaximoContraOferta: 0,
        nitEmpresaDondeTrabaja6: 0,
        nroIdentificacion: 1025874469,
        nroProceso: 3,
        nroSolicitud: 129136,
        numNitConvenio: '0',
        numeroCuentaDesembolsar: 0,
        ocupacionIndependiente: 0,
        oficinaCliente: 60,
        oficinaSelecRecogeCheque: 0,
        periocidadPago: 'M',
        plazoMaximoContraofertadoMotor: 0,
        plazoSolicitado: 0,
        porcentajeVtu: 0,
        riesgoConvenio: 0,
        rprCalificacionWhiteList: 0,
        scorePrecioCliente: 0,
        seguroVidaItpVtu: 0,
        spreed: 0,
        tasaAprobadaEfectivaAnual: 36.86,
        tasaAprobadaMesVencido: 2.6491,
        tipoContrato: 0,
        tipoIdentificacion: 1,
        totalVtu: 0,
        uRLProductoDigital: '/1/',
        valAceptado: 0,
        valCumulo: 0,
        valIndicadorAceptacionSeguro: 'N',
        valNumeroChequesRecoger: 0,
        valSeguro: 29179,
        valTotalObligacionesComprar: 0,
        valorAprobado: 0,
        valorCuotaMensual: 412000,
        valorFinalCreditoIncluidoCola: 11000000,
        valorGMFSimulacion: '0.00',
        valorMaximoContraofertadoMotor: 0,
        valorSolicitado: 0,
      },
      DataHeader: {
        caracterAceptacion: 'M',
        codMsgRespuesta: 4842,
        idTransaccion: '2309271305',
        msgRespuesta: 'Cliente supera intentos negados',
        nombreOperacion: 'ConsultaPersistenciaCredito',
        total: 370046,
        ultimoMensaje: 1,
      },
    },
  },
}

const mockListasRestrictivasResponse = {
  data: {
    data: {
      Data: {
        valInformacionAdicional: 'LISTA INFORMATIVA',
        valRespuesta: 'S',
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: '0',
        idTransaccion: '1657304099041',
        nombreOperacion: 'ConsultaCentralizadorListasRestrictivas',
        total: '1',
        ultimoMensaje: '1',
      },
    },
  },
}

const mockListasRestrictivasResponseFallido = {
  data: {
    data: {
      Data: {
        valInformacionAdicional: 'LISTA INFORMATIVA',
        valRespuesta: 'S',
      },
      DataHeader: {
        caracterAceptacion: 'M',
        codMsgRespuesta: '0',
      },
    },
  },
}

const mockListasRestrictivasResponseFallidovalInformacionAdicionalI = {
  data: {
    data: {
      Data: {
        valInformacionAdicional: 'ASEGURADORA 1',
        valRespuesta: 'I',
      },
    },
  },
}

const mockConsultaClienteResponse = {
  data: {
    data: {
      Data: {
        datos_PN: {
          actLaborales: [
            {
              actLaboralAL: 'EMPLEADO',
              desctipoidentificacionAL: 'CEDULA DE CIUDADANIA',
              fechaInicioAL: '1900/01/01 00:00:00',
              nroIdentificacionAL: '1002620215',
              provienenotrosingresosAL: null,
              tipoAL: 'Laboral',
              tipoContratoAL: 'E',
              tipoIdentificacionAL: '01',
            },
          ],
          act_economicas: [],
          activosPropiedadesVehiculos: [
            {
              ciudadInmueblePV: null,
              codigoTipoPV: '3',
              descTipoIdentificacionPV: 'CEDULA DE CIUDADANIA',
              direccionInmueblePV: null,
              marcaVehiculoPV: null,
              matriculaInmobiliariaPV: null,
              modeloVehiculoPV: null,
              nroIdentificacionPV: '1002620215',
              placaVehiculoPV: null,
              reservaDominioVehPV: null,
              saldoHipotecaPV: null,
              tipoIdentificacionPV: '01',
              tipoPV: 'Otros Activos',
              tipodeInmueblePV: null,
              valorComercialPV: '250000000',
            },
          ],
          celulares: [
            {
              activoCL: 'Y',
              celularPrincipalCL: 'Y',
              descTipoIdentificacionCL: 'CEDULA DE CIUDADANIA',
              nroIdentificacionCL: '1002620215',
              numeroCL: '3186710315',
              tipoCL: 'Cellphone',
              tipoIdentificacionCL: '01',
              tipoTelefonoCL: '03',
            },
            {
              activoCL: 'Y',
              celularPrincipalCL: 'N',
              descTipoIdentificacionCL: 'CEDULA DE CIUDADANIA',
              nroIdentificacionCL: '1002620215',
              numeroCL: '3224319019',
              tipoCL: 'Cellphone',
              tipoIdentificacionCL: '01',
              tipoTelefonoCL: '03',
            },
          ],
          cliente: {
            accionistaDaviviendaCLI: 'N',
            anoinicVidaLaboralCLI: null,
            autenticacionUsuarioCLI: null,
            autenticadoCLI: null,
            cargopoliticoaltonivelotropaisCLI: 'N',
            ciudadaniaAmericanaCLI: null,
            cliEntregaBienEnFiduciaCLI: 'N',
            clienteDaviplata: 'N',
            clienteDavivaloresCLI: '4',
            clienteFiduciaria: 'N',
            clientePEPSCLI: 'N',
            cuentaDECEVALCLI: null,
            declaraRentaCLI: null,
            descTipoIdentificacionCLI: 'CEDULA DE CIUDADANIA',
            directormiembro2anosCLI: 'N',
            esContratistaEstadoCLI: 'N',
            estadoCLI: '1',
            estadoCivilCLI: null,
            estadoExoneradoCLI: null,
            fechaActInformacionClienteCLI: '2023/06/23 05:00:00',
            fechaExpedicionCLI: '2014/09/14 00:00:00',
            fechaNacimientoCLI: '1996/08/30 00:00:00',
            fechaVinculacionCLI: '2023/06/23 00:00:00',
            flagEntidadPublicaCLI: 'N',
            flagPoliticaExpuesto2CLI: 'N',
            flagPoliticaExpuestoCLI: 'N',
            flagRelntoGrupoBolivarCLI: 'N',
            flagTradingElectronico: 'N',
            funcionarioPublicoCLI: null,
            impactadoFATCACLI: 'N',
            indClienteEstablecimCLI: null,
            indicadorExistenciaCLI: null,
            indicadorPNCNCLI: null,
            intervenDeProyectoCLI: 'N',
            lugarExpedicionCLI: '16911001000',
            lugarNacimientoCLI: '16911001000',
            manejaRecursosPublCLI: null,
            mas122DiasPromUSAult3anosCLI: null,
            mas180DiasUSAUltAFiscalCLI: null,
            metodoDeAutenticacion: 'BIOMÉTRICO',
            modEntregaInfoAnualCostoCLI: '04',
            modalEntreInfoAnualCostoCLI: '04',
            nacionalidadAmericanaCLI: null,
            nacionalidadCLI: null,
            nivelEducacionCLI: null,
            nombresCLI: 'CINDY CAROLINA',
            nroIdentificacionCLI: '1002620215',
            nroPersonasCargoCLI: null,
            oficinaRadicacionCLI: '3078',
            ordenanteCLI: 'N',
            origenCLI: null,
            otraNacionalidadCLI: null,
            paisNacimientoCLI: '169',
            pasaporteAmericanoCLI: null,
            perfilRiesgoInversionCLI: null,
            portafolioPersonaNatural: '05',
            primerApellidoCLI: 'ACOSTA',
            profesionCLI: null,
            retefuenteCLI: '02',
            saludoCLI: 'SEÑORA',
            segmentoColorCLI: null,
            segmentoComercialCLI: '00',
            segmentoInversionCLI: null,
            segundoApellidoCLI: 'CARVAJAL',
            sexoCLI: 'F',
            subsegmentoComercialCLI: '00',
            tarjetaVerdeCLI: null,
            tieneResidLegalOtroPaisCLI: 'N',
            tipoCLI: 'CLIENTE',
            tipoIdentificacionCLI: '01',
            tokenCLI: 'N',
            totalActivosCLI: '250000000',
            totalEgresosCLI: '5000000',
            totalIngresosCLI: '25897000',
            totalPasivosCLI: '1000000',
            twitterCLI: null,
            usuarioCreaClienteCLI: null,
            valAutorizaTratDatosCLI: 'Y',
            valClasificacionTribUSACLI: 'Individuo/empresari Cta Propia',
            valInvestiJudicialesPregCLI: 'N',
            valManejaCampanaPolFlagCLI: 'N',
            valNombreDecImpCLI: 'Y',
            vincGrupoBolivarCLI: null,
            viviendaCLI: null,
          },
          consulta_cliente_pn_ejecutivos: [],
          direcciones: [
            {
              ciudadDI: '16911001',
              claseDireccionDI: 'RESIDENCIA CLIENTE',
              codTipoDireccionDI: '01',
              codigoClaseDireccionDI: '01',
              departamentoDI: '16911',
              descTipoIdentificacionDI: 'CEDULA DE CIUDADANIA',
              direccionDI: 'KR 118 B 26 D 13 CASA',
              direccionPrincipalDI: 'N',
              municipioDI: '16911001000',
              nroIdentificacionDI: '1002620215',
              paisDI: '169',
              tipoDireccionDI: 'RESIDENCIA CLIENTE',
              tipoIdentificacionDI: '01',
            },
            {
              ciudadDI: '16911001',
              claseDireccionDI: 'OFICINA CLIENTE',
              codTipoDireccionDI: '02',
              codigoClaseDireccionDI: '02',
              departamentoDI: '16911',
              descTipoIdentificacionDI: 'CEDULA DE CIUDADANIA',
              direccionDI: 'AC 26 50 H 2 PI 10',
              direccionPrincipalDI: 'Y',
              municipioDI: '16911001000',
              nroIdentificacionDI: '1002620215',
              paisDI: '169',
              tipoDireccionDI: 'OFICINA CLIENTE',
              tipoIdentificacionDI: '01',
            },
            {
              ciudadDI: '16941206',
              claseDireccionDI: 'RESIDENCIA CLIENTE',
              codTipoDireccionDI: '01',
              codigoClaseDireccionDI: '01',
              departamentoDI: '16941',
              descTipoIdentificacionDI: 'CEDULA DE CIUDADANIA',
              direccionDI: 'MZ 25 25 25',
              direccionPrincipalDI: 'N',
              municipioDI: '16941206000',
              nroIdentificacionDI: '1002620215',
              paisDI: '169',
              tipoDireccionDI: 'RESIDENCIA CLIENTE',
              tipoIdentificacionDI: '01',
            },
          ],
          egresos: [
            {
              descTipoIdentificacionEG: 'CEDULA DE CIUDADANIA',
              descripcion: null,
              montoEG: '5000000',
              nroIdentificacionEG: '1002620215',
              tipoEG: 'Otros Egresos',
              tipoIdentificacionEG: '01',
            },
          ],
          emails: [
            {
              claseCelularEM: 'E-MAIL',
              correoPrincipalEM: 'N',
              descTipoIdentificacionEM: 'CEDULA DE CIUDADANIA',
              emailEM: 'aldaragu_03@hotmail.com',
              estadoEmailEM: 'ACTIVA',
              nroIdentificacionEM: '1002620215',
              tipo: 'Email',
              tipoIdentificacionEM: '01',
            },
            {
              claseCelularEM: 'E-MAIL',
              correoPrincipalEM: 'Y',
              descTipoIdentificacionEM: 'CEDULA DE CIUDADANIA',
              emailEM: 'pruebaslabdavi@gmail.com',
              estadoEmailEM: 'ACTIVA',
              nroIdentificacionEM: '1002620215',
              tipo: 'Email',
              tipoIdentificacionEM: '01',
            },
          ],
          empleos: [
            {
              descTipoIdentificacionEM: 'CEDULA DE CIUDADANIA',
              fechaIngresoEM: null,
              nitEmpresaEM: null,
              nombreEmpresaEM: null,
              nroIdentificacionEM: '1002620215',
              tipoContratoEM: null,
              tipoIdentificacionEM: '01',
            },
          ],
          hobbies: [],
          ingresos: [
            {
              actEconomicaIN: '00010',
              antigLaboralIN: '1482',
              codActLaboralIN: 'E',
              codTipoContratoIN: null,
              codigoTipoIN: '1',
              desActEconomicaIN:
                'ASALARIADOS: PERSONAS NATURALES Y SUCESIONES ILÍQUIDAS, CUYOS INGRESOS PROVENGAN DE LA RELACIÓN LABORAL, LEGAL O REGLAMENTARIA O QUE TENGAN SU ORIGEN EN ELLA.',
              descTipoIdentificacionIN: 'CEDULA DE CIUDADANIA',
              fechaInicioIN: '1900/01/01 00:00:00',
              nombreEmpresaIN: 'Global',
              nroIdentificacionIN: '1002620215',
              principalIN: 'Y',
              tipoActLaboralIN: 'EMPLEADO',
              tipoContratoIN: 'E',
              tipoIN: 'Salario Mensual',
              tipoIdentificacionIN: '01',
              valorIN: '25897000',
            },
          ],
          monedas: [],
          notas: [],
          operacionesInternacionales: [],
          pasivosCreditos: [],
          puestosTrabajo: [
            {
              descTipoIdentificacionPT: 'CEDULA DE CIUDADANIA',
              divisionPT: 'Siebel Administration - Davivienda',
              nroIdentificacionPT: '1002620215',
              puestoTrabajoPT: 'Administrador Siebel - Davivienda',
              tipoIdentificacionPT: '01',
            },
          ],
          referencias: [],
          relaciones: [],
          responsfiscales: [],
          telefonos: [
            {
              activoTL: 'Y',
              ciudadTL: '16911001000',
              descTipoIdentificacionTL: 'CEDULA DE CIUDADANIA',
              indicativoTL: '6',
              nroIdentificacionTL: '1002620215',
              numeroTL: '5678924',
              telefonoPpalTL: 'Y',
              tipoIdentificacionTL: '01',
              tipoTL: 'Telephone',
              tipoTelefonoTL: '02',
            },
          ],
        },
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: '0',
        msgRespuesta: '',
        nombreOperacion: 'consultarClientePNF3',
        total: '1',
        ultimoMensaje: '1',
      },
    },
  },
}

const mockConsultaClienteResponseFallido = {
  data: {
    data: {
      Data: {
        datos_PN: {
          actLaborales: [
            {
              actLaboralAL: 'EMPLEADO',
              desctipoidentificacionAL: 'CEDULA DE CIUDADANIA',
              fechaInicioAL: '1900/01/01 00:00:00',
              nroIdentificacionAL: '1002620215',
              provienenotrosingresosAL: null,
              tipoAL: 'Laboral',
              tipoContratoAL: 'E',
              tipoIdentificacionAL: '01',
            },
          ],
          act_economicas: [],
          activosPropiedadesVehiculos: [
            {
              ciudadInmueblePV: null,
              codigoTipoPV: '3',
              descTipoIdentificacionPV: 'CEDULA DE CIUDADANIA',
              direccionInmueblePV: null,
              marcaVehiculoPV: null,
              matriculaInmobiliariaPV: null,
              modeloVehiculoPV: null,
              nroIdentificacionPV: '1002620215',
              placaVehiculoPV: null,
              reservaDominioVehPV: null,
              saldoHipotecaPV: null,
              tipoIdentificacionPV: '01',
              tipoPV: 'Otros Activos',
              tipodeInmueblePV: null,
              valorComercialPV: '250000000',
            },
          ],
          celulares: [],
          cliente: {},
          consulta_cliente_pn_ejecutivos: [],
          direcciones: [],
          egresos: [
            {
              descTipoIdentificacionEG: 'CEDULA DE CIUDADANIA',
              descripcion: null,
              montoEG: '5000000',
              nroIdentificacionEG: '1002620215',
              tipoEG: 'Otros Egresos',
              tipoIdentificacionEG: '01',
            },
          ],
          emails: [],
          empleos: [
            {
              descTipoIdentificacionEM: 'CEDULA DE CIUDADANIA',
              fechaIngresoEM: null,
              nitEmpresaEM: null,
              nombreEmpresaEM: null,
              nroIdentificacionEM: '1002620215',
              tipoContratoEM: null,
              tipoIdentificacionEM: '01',
            },
          ],
          hobbies: [],
          ingresos: [
            {
              actEconomicaIN: '00010',
              antigLaboralIN: '1482',
              codActLaboralIN: 'E',
              codTipoContratoIN: null,
              codigoTipoIN: '1',
              desActEconomicaIN:
                'ASALARIADOS: PERSONAS NATURALES Y SUCESIONES ILÍQUIDAS, CUYOS INGRESOS PROVENGAN DE LA RELACIÓN LABORAL, LEGAL O REGLAMENTARIA O QUE TENGAN SU ORIGEN EN ELLA.',
              descTipoIdentificacionIN: 'CEDULA DE CIUDADANIA',
              fechaInicioIN: '1900/01/01 00:00:00',
              nombreEmpresaIN: 'Global',
              nroIdentificacionIN: '1002620215',
              principalIN: 'Y',
              tipoActLaboralIN: 'EMPLEADO',
              tipoContratoIN: 'E',
              tipoIN: 'Salario Mensual',
              tipoIdentificacionIN: '01',
              valorIN: '25897000',
            },
          ],
          monedas: [],
          notas: [],
          operacionesInternacionales: [],
          pasivosCreditos: [],
          puestosTrabajo: [
            {
              descTipoIdentificacionPT: 'CEDULA DE CIUDADANIA',
              divisionPT: 'Siebel Administration - Davivienda',
              nroIdentificacionPT: '1002620215',
              puestoTrabajoPT: 'Administrador Siebel - Davivienda',
              tipoIdentificacionPT: '01',
            },
          ],
          referencias: [],
          relaciones: [],
          responsfiscales: [],
          telefonos: [
            {
              activoTL: 'Y',
              ciudadTL: '16911001000',
              descTipoIdentificacionTL: 'CEDULA DE CIUDADANIA',
              indicativoTL: '6',
              nroIdentificacionTL: '1002620215',
              numeroTL: '5678924',
              telefonoPpalTL: 'Y',
              tipoIdentificacionTL: '01',
              tipoTL: 'Telephone',
              tipoTelefonoTL: '02',
            },
          ],
        },
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: '0',
        msgRespuesta: '',
        nombreOperacion: 'consultarClientePNF3',
        total: '1',
        ultimoMensaje: '1',
      },
    },
  },
}

const mockGrabarInfoSolicitudesResponse = {
  data: {
    data: {
      Data: {
        nroSolicitud: 155249,
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: 0,
        idTransaccion: '2306141743',
        nombreOperacion: 'GrabacionInformacionSolicitudes',
        total: 370070,
        ultimoMensaje: 1,
      },
    },
  },
}

const valPersistenceResponse = [
  {
    listaCiudades: [
      {
        codCiudad: '16911001',
        descCiudad: 'BOGOTA, D.C.',
        descDepto: 'BOGOTA, D.C.',
        viable: false,
      },
      {
        codCiudad: '16991263',
        descCiudad: 'EL ENCANTO',
        descDepto: 'AMAZONAS',
        viable: false,
      },
    ],
  },
]

const mockconsultaClienteMoraResponse = {
  data: {
    codError: null,
    messageError: null,
    response: {
      response: {
        data: null,
        dataHeader: {
          caracterAceptacion: 'B',
          codMsgRespuesta: 0,
          idTransaccion: '1689090675',
          msgRespuesta: 'No Esta en Mora',
          nombreOperacion: 'ValidacionProductosEnMora',
          total: 0,
          ultimoMensaje: 1,
        },
      },
    },
  },
}

const mockconsultaProductosResponse = {
  data: {
    res: {
      Response: {
        Data: {
          Registros: {
            Registro: [
              {
                valCantidadBolsillos: 0,
                valClaseManejo: 1,
                valCodigoProducto: 550,
                valCodigoSubProducto: '0001',
                valCompania: '0045',
                valFechaApertura: '20230412',
                valIndicadorBloqueTradicional: 0,
                valIndicadorBloqueoProducto: '01',
                valIndicadorBolsillo: 0,
                valIndicadorCliente: 1,
                valIndicadorEmbargo: 0,
                valIndicadorFondosCongeladosEmbargo: 0,
                valIndicadorSegundaClave: 0,
                valIndicadorTarjetaCreditoAmparada: 0,
                valIndicadorTarjetaDebito: 9,
                valNumeroPortafolio: '0000',
                valNumeroProducto: '0550098101145286',
                valTarjeta: '000000000000',
                valTipoPortafolio: '000000000000000001',
                valVigencia: 1,
                valVinculacion: 550,
              },
            ],
          },
          valActividadEconomica: 9820,
          valCantidadRegistros: 2,
          valCiudad: 16911001000,
          valClaseEmpresa: 0,
          valCuentaExcenta: 0,
          valDireccion: 'KR 55 30 5',
          valFechaNacimiento: '19900405',
          valIndMsgActualizacion: 0,
          valIndicadorClienteEspecial: 0,
          valLlaveCodigoProducto: 560,
          valLlaveCodigoSubProducto: 2001,
          valLlaveCompania: 45,
          valLlaveNumeroProducto: '0560098160025148',
          valLlaveVinculacion: 560,
          valNaturalezaJuridica: 'N',
          valNombres: 'HERNAN',
          valNumeroIdentificacion: 1030580935,
          valPrimerApellido: 'TORRES',
          valRetefuente: 2,
          valTelefono: '7589685',
          valTipoIdentificacion: 1,
          valTipoNoDeseado: 0,
        },
        DataHeader: {
          caracterAceptacion: 'B',
          codMsgRespuesta: 0,
          idTransaccion: '79351818',
          nombreOperacion: 'ConsultasProductos',
          total: 2235,
          ultimoMensaje: 1,
        },
      },
    },
  },
}

const mockconsultaRotativoResponse = {
  data: {
    res: {
      Response: {
        Data: {
          numCantidadRotativos: 0,
          numNumeroIdentificacion: 1002620147,
          numNumeroSolicitud: 1,
          numTipoIdentificacion: 1,
        },
        DataHeader: {
          caracterAceptacion: 'B',
          codMsgRespuesta: 0,
          idTransaccion: '235475445',
          nombreOperacion: 'ConsultarCreditosRotativoXCliente',
          total: 0,
        },
      },
    },
  },
}

const mockAutentificacionLivianaEliminarResponse = {
  data: {
    data: {
      Data: {
        codigoRespuesta: '0',
        descripcionRespuesta: '',
      },
      DataHeader: {
        caracterAceptacion: 'B',
        codMsgRespuesta: '0000',
        idTransaccion: '1669649524',
        msgRespuesta: '',
        nombreOperacion: 'EliminacionPersistenciaCredito',
        total: '1',
        ultimoMensaje: '1',
      },
    },
  },
}

const mockWfData = new WorkflowData(mockPresentacion)
const mockWfDataAux = new WorkflowData(mockPresentacionAux)
const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)
const serviceUrls = {
  autenticacionliviana:
    'http://localhost:5080/autenticacionliviana/v1/eliminacionPersistenciaCredito',
  clienteMora: 'http://localhost:6030/vpr/v1/validacion-moras',
  consultaClientePN:
    'http://localhost:5012/prevalidacion/v1/consultarClientePN',
  consultaPersistencia: 'http://localhost:5050/api/v1/service',
  grabarInformacionSolicitudes: 'http://localhost:5050/api/v1/grabar',
  listasRestrictivas:
    'http://localhost:5012/prevalidacion/v1/consultarListasRestrictivas',
  parametros: `http://catalogo/v1/parms/services.workflow.BYC0010?canal=${CANAL}&modulo=${MODULO}&lenguaje=${IDIOMA}&pais=${PAIS}&kind=${PRODUCTO.CRRT}`,
  parametrosCiudades:
    'http://localhost:5003/persistence/v1/data/parms/AREASGEOGRAFICAS',
  soapService: 'http://localhost:6044/v1/soap-service',
}

let step: BYC0010
let nextStep: IStepData

describe('BYC0010', () => {
  /*
   *
   *  Verificación de instancia de objetos y payload para BYC0010
   *
   */

  test('Instancia correctamente del objeto BYC0010', () => {
    step = new BYC0010(stepData, mockWfData, config, logger, persistence)
    expect(step).toBeDefined()
  })

  test('Validación del objeto BYC0010 con payload correcto (no retorna mensaje de error)', () => {
    expect(step.isRequestValid()).toBeTruthy()
  })

  test('Validación del objeto BYC0010 con payload incorrecto (si retorna mensaje de error)', () => {
    const badStepData: IStepData = {
      clientId: 'abc123',
      payload: {
        bad: '',
      },
      stepId: STEP_ID.BYC0010,
    }
    const badStep = new BYC0010(
      badStepData,
      mockWfData,
      config,
      logger,
      persistence
    )
    expect(badStep.isRequestValid()).toBeFalsy()
    expect(badStep.getRequestValidationError().length).toBeGreaterThan(0)
  })

  /*
   *
   *  Verificacion del flujo para BYC0010
   *
   */
  test('Validación del getCurrentStep retorna valor del request', () => {
    expect(step.getCurrentStep()).toEqual(stepData.stepId)
  })

  test('BYC0010 => Flujo atras', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepDataAtras, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación con sessionTimeOut', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      mockWfDataAux.flujo.stepBYC0010 = true
      step = new BYC0010(stepData, mockWfDataAux, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Ok| ConsultaCLiente Ok| Flujo OK', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponse)
      }
      if (url === serviceUrls.clienteMora) {
        return Promise.resolve(mockconsultaClienteMoraResponse)
      }
      if (url === serviceUrls.soapService) {
        return Promise.resolve(mockconsultaProductosResponse)
      }
      if (url === serviceUrls.soapService) {
        return Promise.resolve(mockconsultaRotativoResponse)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.autenticacionliviana) {
        return Promise.resolve(mockAutentificacionLivianaEliminarResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Error maximo negaciones', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponseFallido)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas caracterAceptacion M', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponseFallido)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Ok| ConsultaCLiente Error validacion datos', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponseFallido)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.autenticacionliviana) {
        return Promise.resolve(mockAutentificacionLivianaEliminarResponse)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(nextStep).toBeDefined()
      done()
    } catch (err) {
      expect(err).toBeFalsy()
    }
  })

  // test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Mal ValRespesta N| ConsultaCLiente Ok| | GrabaInformacionSolicitudes Ok|', async (done) => {
  //   axios.get = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.parametros) {
  //       return Promise.resolve(valParmsResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   axios.post = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.consultaPersistencia) {
  //       return Promise.resolve(mockConsultaPersistenciaResponse)
  //     }
  //     if (url === serviceUrls.listasRestrictivas) {
  //       return Promise.resolve(mockListasRestrictivasResponseFallido)
  //     }
  //     if (url === serviceUrls.consultaClientePN) {
  //       return Promise.resolve(mockConsultaClienteResponseFallido)
  //     }
  //     if (url === serviceUrls.grabarInformacionSolicitudes) {
  //       return Promise.resolve(mockGrabarInfoSolicitudesResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   persistence.getData = jest.fn((kind: string, k: string) =>
  //     Promise.resolve(valPersistenceResponse)
  //   )

  //   try {
  //     step = new BYC0010(stepData, mockWfData, config, logger, persistence)
  //     nextStep = await step.getNextStep()
  //     expect(nextStep).toBeDefined()
  //     done()
  //   } catch (err) {
  //     expect(err).toBeFalsy()
  //   }
  // })

  // test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Mal ValRespesta I - listas Asegurables| ConsultaCLiente Ok| | GrabaInformacionSolicitudes Ok|', async (done) => {
  //   axios.get = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.parametros) {
  //       return Promise.resolve(valParmsResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   axios.post = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.consultaPersistencia) {
  //       return Promise.resolve(mockConsultaPersistenciaResponse)
  //     }
  //     if (url === serviceUrls.listasRestrictivas) {
  //       return Promise.resolve(
  //         mockListasRestrictivasResponseFallidovalInformacionAdicionalI
  //       )
  //     }
  //     if (url === serviceUrls.consultaClientePN) {
  //       return Promise.resolve(mockConsultaClienteResponse)
  //     }
  //     if (url === serviceUrls.grabarInformacionSolicitudes) {
  //       return Promise.resolve(mockGrabarInfoSolicitudesResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   persistence.getData = jest.fn((kind: string, k: string) =>
  //     Promise.resolve(valPersistenceResponse)
  //   )

  //   try {
  //     step = new BYC0010(stepData, mockWfData, config, logger, persistence)
  //     nextStep = await step.getNextStep()
  //     expect(nextStep).toBeDefined()
  //     done()
  //   } catch (err) {
  //     expect(err).toBeFalsy()
  //   }
  // })

  // test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Mal ValRespesta N| ConsultaCLiente Ok| | GrabaInformacionSolicitudes Ok => if seguroAdquirido true|', async (done) => {
  //   axios.get = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.parametros) {
  //       return Promise.resolve(valParmsResponseAux)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   axios.post = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.consultaPersistencia) {
  //       return Promise.resolve(mockConsultaPersistenciaResponse)
  //     }
  //     if (url === serviceUrls.listasRestrictivas) {
  //       return Promise.resolve(mockListasRestrictivasResponseFallido)
  //     }
  //     if (url === serviceUrls.consultaClientePN) {
  //       return Promise.resolve(mockConsultaClienteResponse)
  //     }
  //     if (url === serviceUrls.grabarInformacionSolicitudes) {
  //       return Promise.resolve(mockGrabarInfoSolicitudesResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   persistence.getData = jest.fn((kind: string, k: string) =>
  //     Promise.resolve(valPersistenceResponse)
  //   )

  //   try {
  //     mockWfData.sesion.consultaTasaSimulador.seguroAdquirido = true
  //     mockWfData.sesion.evaluadorPCO = {
  //       causalNegacion1: '',
  //       causalNegacion2: '',
  //       causalNegacion3: '',
  //       causalNegacion4: '',
  //       causalNegacion5: '',
  //       creditoSeleccionado: {
  //         cuotaMensual: {
  //           tooltip: {
  //             pagoMensual: {
  //               valor: '',
  //             },
  //           },
  //           valorCuota: '',
  //         },
  //         seguroVidaITPXMillon: '',
  //         tasaInteres: {
  //           ea: '',
  //           mv: '',
  //         },
  //         valorCredito: '',
  //         valorFinalCredito: '',
  //       },
  //       decision: '',
  //       montoMaximoContraoferta: '0',
  //       plazoAprobado: '0',
  //       valorAcierta: '',
  //     }

  //     step = new BYC0010(stepData, mockWfData, config, logger, persistence)
  //     nextStep = await step.getNextStep()
  //     expect(nextStep).toBeDefined()
  //     done()
  //   } catch (err) {
  //     expect(err).toBeFalsy()
  //   }
  // })

  // test('BYC0010 => Presentación sin sessionTimeOut | ConsultaPersistencia Ok| | ListasRestrictivas Mal ValRespesta N| ConsultaCLiente Ok| | GrabaInformacionSolicitudes Ok => numeroProcesoDeceval |', async (done) => {
  //   axios.get = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.parametros) {
  //       return Promise.resolve(valParmsResponseAux2)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   axios.post = jest.fn().mockImplementation((url: string, data: any) => {
  //     if (url === serviceUrls.consultaPersistencia) {
  //       return Promise.resolve(mockConsultaPersistenciaResponse)
  //     }
  //     if (url === serviceUrls.listasRestrictivas) {
  //       return Promise.resolve(mockListasRestrictivasResponseFallido)
  //     }
  //     if (url === serviceUrls.consultaClientePN) {
  //       return Promise.resolve(mockConsultaClienteResponse)
  //     }
  //     if (url === serviceUrls.grabarInformacionSolicitudes) {
  //       return Promise.resolve(mockGrabarInfoSolicitudesResponse)
  //     }
  //     return Promise.reject('url-no-esperada')
  //   })

  //   persistence.getData = jest.fn((kind: string, k: string) =>
  //     Promise.resolve(valPersistenceResponse)
  //   )

  //   try {
  //     mockWfData.sesion.consultaClientePN.esCliente = true
  //     mockWfData.sesion.seguroVoluntario.seguroAdquirido = true
  //     mockWfData.sesion.consultaTasaSimulador.valorPlazoContraOferta = 'test'
  //     mockWfData.sesion.consultaTasaSimulador.seguroAdquirido = true
  //     mockWfData.sesion.evaluadorPCO = {
  //       causalNegacion1: '',
  //       causalNegacion2: '',
  //       causalNegacion3: '',
  //       causalNegacion4: '',
  //       causalNegacion5: '',
  //       creditoSeleccionado: {
  //         cuotaMensual: {
  //           tooltip: {
  //             pagoMensual: {
  //               valor: '',
  //             },
  //           },
  //           valorCuota: '',
  //         },
  //         seguroVidaITPXMillon: '',
  //         tasaInteres: {
  //           ea: '',
  //           mv: '',
  //         },
  //         valorCredito: '',
  //         valorFinalCredito: '',
  //       },
  //       decision: '',
  //       montoMaximoContraoferta: '0',
  //       plazoAprobado: '0',
  //       valorAcierta: '',
  //     }

  //     step = new BYC0010(stepData, mockWfData, config, logger, persistence)
  //     nextStep = await step.getNextStep()
  //     expect(nextStep).toBeDefined()
  //     done()
  //   } catch (err) {
  //     expect(err).toBeFalsy()
  //   }
  // })

  /*
   *
   *  Verificación de errores al llamar servicios
   *
   */

  test('BYC0010 => Cliente con error al consultar parametros -> Error 500 | CRRT', async (done) => {
    const valParmsResponseAuxError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAuxError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar parametros -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementationOnce((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar parametros lsitaCiudades key AREASGEOGRAFICAS -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error al consultar consultaPersistencia -> Error 500 | CRRT', async (done) => {
    const consultaPersistenciaError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(consultaPersistenciaError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar consultaPersistencia -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error al consultar listrasRestrictivas -> Error 500 | CRRT', async (done) => {
    const listrasRestrictivasError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(listrasRestrictivasError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar listrasRestrictivas -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error al consultar clientePN -> Error 500 | CRRT', async (done) => {
    const consultaClienteError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(consultaClienteError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar clientePN -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error al consultar grabarInformacionSolicitudes -> Error 500 | CRRT', async (done) => {
    const grabarInformacionSolicitudesError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponseFallido)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(grabarInformacionSolicitudesError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar grabarInformacionSolicitudes -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponseAux2)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponseFallido)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error al consultar autLivianaEliminarPersistencia -> Error 500 | CRRT', async (done) => {
    const autLivianaEliminarPersistenciaError = {
      data: {
        data: {},
        errors: ['internal_server_error'],
      },
      status: 404,
    }

    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponseFallido)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.autenticacionliviana) {
        return Promise.resolve(autLivianaEliminarPersistenciaError)
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })

  test('BYC0010 => Cliente con error en axios al consultar autLivianaEliminarPersistencia -> Error 500 ', async (done) => {
    axios.get = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.parametros) {
        return Promise.resolve(valParmsResponse)
      }
      if (url === serviceUrls.parametrosCiudades) {
        return Promise.resolve(valParmsResponseAREASGEOGRAFICAS)
      }
      return Promise.reject('url-no-esperada')
    })

    axios.post = jest.fn().mockImplementation((url: string, data: any) => {
      if (url === serviceUrls.consultaPersistencia) {
        return Promise.resolve(mockConsultaPersistenciaResponse)
      }
      if (url === serviceUrls.listasRestrictivas) {
        return Promise.resolve(mockListasRestrictivasResponse)
      }
      if (url === serviceUrls.consultaClientePN) {
        return Promise.resolve(mockConsultaClienteResponseFallido)
      }
      if (url === serviceUrls.grabarInformacionSolicitudes) {
        return Promise.resolve(mockGrabarInfoSolicitudesResponse)
      }
      if (url === serviceUrls.autenticacionliviana) {
        return Promise.reject(new Error('internal_server_error'))
      }
      return Promise.reject('url-no-esperada')
    })

    try {
      step = new BYC0010(stepData, mockWfData, config, logger, persistence)
      nextStep = await step.getNextStep()
      expect(step).toBeDefined()
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError.message).toContain('internal_server_error')
      done()
    }
  })
})
