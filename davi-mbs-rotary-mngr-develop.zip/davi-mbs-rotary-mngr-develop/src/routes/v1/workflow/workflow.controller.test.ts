//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { StepFactory } from '@services/workflowService/stepFactory/stepFactory'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { WorkflowService } from '@services/workflowService/workflowService'
import { createRequest, createResponse } from 'node-mocks-http'
import { PRODUCTO } from '~/models/enums/productoPais.enum'
import { WorkflowController } from './workflow.controller'

jest.mock('@services/auth/authService')
jest.mock('@services/crypto/cryptoService')
jest.mock('@services/workflowService/workflowService')
jest.mock('@services/persistence/persistenceService')
jest.mock('@services/workflowService/stepFactory/stepFactory')

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {
        authServiceUrl: 'http://mbaas/auth',
      },
    }
  }
}

describe('WorkflowController', () => {
  const config = new MockConfig()
  const logger = new LoggerStub('debug')
  const persistence = new PersistenceService(config, logger)
  const auth = new AuthService(config)
  const crypto = new CryptoService(auth, logger)
  const steps = new StepFactory(config, logger, persistence)
  const workflow = new WorkflowService(logger, persistence, steps, crypto, auth)

  const workflowController = new WorkflowController(logger, workflow)

  test('POST workflow/ con body correcto retorna 200 y proximo paso', async (done) => {
    const clientId = 'cb4c4a20-44fd-11e9-bedb-89ea0cfca12f'
    const body = {
      clientId,
      module: '',
      payload: 'jwe',
      stepId: STEP_ID.BYC0010,
    }

    // Preparacion de HTTP props
    const req = createRequest({
      body,
      method: 'POST',
      url: `/pgprntngw/v1/workflow`,
    })
    const res = createResponse()
    const next = () => {
      done()
    }

    // mock de workflow
    const nextStep: IStepData = {
      clientId,
      module: PRODUCTO.CRRT,
      payload: {},
      stepId: STEP_ID.BYC0010,
    }
    workflow.getNextStep = jest.fn((stepData: IStepData) =>
      Promise.resolve(nextStep)
    )
    // llamada a metodo y finalizacion de response
    await workflowController.create(req, res, next)
    res.end()

    const data = JSON.parse(res._getData())
    expect(res._getStatusCode()).toEqual(200)
    expect(data.errors.length).toBe(0)
    expect(data.data).toEqual(nextStep)
  })

  test('POST workflow/ con body invalido retorna error 422', async (done) => {
    const clientId = 'cb4c4a20-44fd-11e9-bedb-89ea0cfca12f'
    const body = {
      clientId,
      stepId: STEP_ID.BYC0010,
    }

    // Preparacion de HTTP props
    const req = createRequest({
      body,
      method: 'POST',
      url: `/pgprntngw/v1/workflow`,
    })
    const res = createResponse()
    const next = () => {
      const a = 1
    }

    // llamada a metodo y finalizacion de response
    await workflowController.create(req, res, next)
    res.end()

    const data = JSON.parse(res._getData())
    expect(res._getStatusCode()).toEqual(422)
    expect(data.errors.length).toBe(1)
    expect(data.errors).toContain('invalid_data_on_request')
    done()
  })

  test('POST workflow/ con error de mbaas al llamar workflow retorna status code', async (done) => {
    const clientId = 'cb4c4a20-44fd-11e9-bedb-89ea0cfca12f'
    const body = {
      clientId,
      module: '',
      payload: 'jwe',
      stepId: STEP_ID.BYC0010,
    }

    // Preparacion de HTTP props
    const req = createRequest({
      body,
      method: 'POST',
      url: `/pgprntngw/v1/workflow`,
    })
    const res = createResponse()
    const next = () => {
      const a = 1
    }

    // mock de workflow
    const mError = new ServiceError(
      MBAAS_ERRORS.invalid_data_format,
      new Error('upss-en-workflow')
    )
    workflow.getNextStep = jest.fn((stepData: IStepData) =>
      Promise.reject(mError)
    )

    // llamada a metodo y finalizacion de response
    await workflowController.create(req, res, next)
    res.end()

    const data = JSON.parse(res._getData())
    expect(res._getStatusCode()).toEqual(422)
    expect(data.errors.length).toBe(1)
    expect(data.errors).toContain('invalid_data_format')
    done()
  })

  test('POST workflow/ con otro error al llamar workflow retorna error 500', async (done) => {
    const clientId = 'cb4c4a20-44fd-11e9-bedb-89ea0cfca12f'
    const body = {
      clientId,
      payload: 'jwe',
      stepId: STEP_ID.BYC0010,
    }

    // Preparacion de HTTP props
    const req = createRequest({
      body,
      method: 'POST',
      url: `/pgprntngw/v1/workflow`,
    })
    const res = createResponse()
    const next = () => {
      const a = 1
    }

    // mock de workflow
    workflow.getNextStep = jest.fn((stepData: IStepData) =>
      Promise.reject(new Error('upss-desconocido'))
    )

    // llamada a metodo y finalizacion de response
    await workflowController.create(req, res, next)
    res.end()

    const data = JSON.parse(res._getData())
    expect(res._getStatusCode()).toEqual(500)
    expect(data.errors.length).toBe(1)
    expect(data.errors).toContain('internal_server_error')
    done()
  })

  test('GET workflow/ retorna 200', async (done) => {
    // Preparacion de HTTP props
    const req = createRequest({
      method: 'GET',
      url: `/pgprntngw/v1/workflow`,
    })
    const res = createResponse()
    const next = () => {
      done()
    }

    // llamada a metodo y finalizacion de response
    await workflowController.ping(req, res, next)
    res.end()

    const data = JSON.parse(res._getData())
    expect(res._getStatusCode()).toEqual(200)
    expect(data.errors.length).toBe(0)
    expect(data.data).toEqual('ok ping')
  })
})
