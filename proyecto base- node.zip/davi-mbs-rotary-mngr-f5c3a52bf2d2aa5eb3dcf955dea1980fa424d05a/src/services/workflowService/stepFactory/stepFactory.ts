//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { inject, provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IStep } from '@services/workflowService/steps/step'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { IStepFactory } from '.'

// Importar Pasos
import { BeneficiosCaracteristicasStep } from '@services/workflowService/steps/Rotatitvo/beneficiosCaracteristicasStep/beneficiosCaracteristicasStep'

// Final importar Pasos

@provide(TYPES.IStepFactory, true)
export class StepFactory implements IStepFactory {
  constructor(
    @inject(TYPES.IConfig) private config: IConfig,
    @inject(TYPES.ILogger) private logger: ILogger
  ) {}

  public get(stepData: IStepData, sessionData: WorkflowData): IStep {
    switch (stepData.stepId) {
      // Paso MBaaS boot
      case STEP_ID.rotativo000:
        return new BeneficiosCaracteristicasStep(stepData, sessionData, this.config, this.logger)
      default:
        return new BeneficiosCaracteristicasStep(stepData, sessionData, this.config, this.logger)
    }
  }
}
