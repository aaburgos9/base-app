//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IWorkflowService } from '..'
import { IPresentacionClientes } from '../../../models/sesion/presentacionClientes.model'
import { WorkflowData } from '../../../models/workflowData.model'
import { IStepData } from '../steps/stepData.model'
import { STEP_ID } from '../steps/stepId.enum'

const mockStep: IStepData = {
  clientId: 'abc123',
  payload: {},
  stepId: STEP_ID.rotativo000,
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      expeditionCity: '16911001',
      expeditionDate: '15/12/2000',
      number: '1234567890',
      type: '01',
    },
    email: 'usuario@correo.com',
    name: 'Helena Maria Lopez Perez',
    phoneNumber: {
      countryId: '57',
      number: '3124451512',
    },
  },
  consumer: {
    appConsumer: {
      appVersion: '',
      canalId: '',
      id: '',
      sessionId: '',
      soVersion: '',
      terminalId: '',
      transactionId: '',
    },
    deviceConsumer: {
      id: '',
      inactiveInterval: '300000',
      locale: '',
      phoneNumber: '',
      sessionTimeout: '300000',
      userAgent: '',
    },
    genericData: {
      dataItem: [{ key: 'tokenFrontend', value: 'abcd-1234-efgh-5678' }],
    },
  },
  partner: {
    callbackUrl: {
      error: 'http://some-url.com/error',
      success: 'http://some-url.com/ok',
    },
    id: 'P1',
  },
  product: {
    country: 'CO',
    id: 'rotativo',
  },
}

const mockWorkflowData = new WorkflowData(mockPresentacion , '', 0)

export class WorkflowService implements IWorkflowService {
  public getNextStep = jest.fn((stepData: IStepData) =>
    Promise.resolve(mockStep)
  )
}
