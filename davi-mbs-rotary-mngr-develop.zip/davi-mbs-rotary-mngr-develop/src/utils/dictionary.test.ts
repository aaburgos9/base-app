//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { Dictionary, IDictionary } from './dictionary'

describe('Dictionary', () => {
  let dict: IDictionary<number>

  test('instancia correctamente', () => {
    dict = new Dictionary<number>()
    expect(dict).toBeDefined()
    expect(dict.count()).toBe(0)
    expect(dict.values().length).toEqual(0)
    expect(dict.keys().length).toEqual(0)
  })

  test('set agrega items nuevos correctamente', () => {
    dict.set('n1', 0)
    expect(dict.count()).toBe(1)

    const vals = dict.values()
    expect(vals.length).toEqual(1)
    expect(vals[0]).toEqual(0)

    const keys = dict.keys()
    expect(keys.length).toEqual(1)
    expect(keys[0]).toEqual('n1')
  })

  test('set modifica items existentes correctamente', () => {
    dict.set('n1', 1)
    expect(dict.count()).toBe(1)

    const vals = dict.values()
    expect(vals.length).toEqual(1)
    expect(vals[0]).toEqual(1)
  })

  test('get de item existente lo retorna correctamente', () => {
    const item = dict.get('n1')
    expect(item).toBe(1)
  })

  test('get de item inexistente retorna nulo', () => {
    expect(dict.get('n0')).toBeUndefined()
  })

  test('containsKey de key existente retorna true', () => {
    expect(dict.containsKey('n1')).toBeTruthy()
  })

  test('containsKey de key inexistente retorna false', () => {
    expect(dict.containsKey('n0')).toBeFalsy()
  })

  test('remove de item existente lo elimina correctamente', () => {
    const initialCount = dict.count()

    // primero agrego item a eliminar
    dict.set('n2', 2)
    expect(dict.count()).toBe(initialCount + 1)
    expect(dict.get('n2')).toEqual(2)

    // ahora remuevo el item
    const item = dict.remove('n2')
    expect(item).toEqual(2)
    expect(dict.count()).toBe(initialCount)
    expect(dict.get('n2')).toBeUndefined()
  })

  test('remove de item inexistente no hace nada', () => {
    const initialCount = dict.count()

    // intento remover un item inexistente
    const item = dict.remove('n0')
    expect(item).toBeUndefined()
    expect(dict.count()).toBe(initialCount)
  })
})
