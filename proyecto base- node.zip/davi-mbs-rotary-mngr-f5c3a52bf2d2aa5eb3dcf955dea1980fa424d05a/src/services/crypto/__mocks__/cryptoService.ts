//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export class CryptoService {
  public encryptJwe = jest.fn((encryptKey: string, payload: any) => Promise.resolve(''))
  public decryptJwe = jest.fn((jweToken: any) => Promise.resolve(''))
}
