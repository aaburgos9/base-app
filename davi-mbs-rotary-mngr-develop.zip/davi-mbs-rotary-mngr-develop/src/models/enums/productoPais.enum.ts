//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum PAIS {
  CO = 'CO',
}

export enum PRODUCTO {
  CRRT = 'CRRT',
}

export enum PRODUCTO_PAIS_CANAL {
  CRRT_CO = 'CRRT_CO',
}
