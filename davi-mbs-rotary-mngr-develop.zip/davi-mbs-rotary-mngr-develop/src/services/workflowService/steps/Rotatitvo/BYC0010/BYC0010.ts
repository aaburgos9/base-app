//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IConfig } from '@config/vars'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { GrabarInformacionSolicitudesModel } from '@models/servicios/grabarInformacionSolicitudes'
import { WorkflowData } from '@models/workflowData.model'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence'
import {
  consumoResponseB,
  consumoResponseM,
} from '@services/workflowService/steps/Rotatitvo/BYC0010/BYC0010MockData'
import { Step } from '@services/workflowService/steps/step'
import {
  IStepData,
  STATUS_ID,
  STATUS_MSG,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import axios from 'axios'
import joi, { any } from 'joi'
import moment from 'moment'
import { KIND } from '~/models/enums/kind.enum'
import { UTILITIES } from '~/utils/utilities'

const STEP: string = 'BYC0010'
const IDIOMA: string = 'ES'
const PRODUCTO: string = 'CRRT'

const inputSchema = joi
  .object()
  .keys({
    aceptoRetoma: joi.boolean().optional().allow(''),
    atras: joi.boolean().required(),
    prevalidacion: joi.boolean().required(),
    rechazoRetoma: joi.boolean().optional().allow(''),
  })
  .optional()

export class BYC0010 extends Step {
  private parmsData: any = {}
  private listaCiudadesCon: any = {}

  constructor(
    currentStep: IStepData,
    sessionData: WorkflowData,
    config: IConfig,
    logger: ILogger,
    private persistence: IPersistenceService
  ) {
    super(currentStep, sessionData, config, logger, inputSchema)
  }

  /**
   *
   * Funcion getNextStep
   *
   */
  public getNextStep = async () => {
    const reqPayload = this.getRequestPayload()
    let nextStep: IStepData
    this.logger.debug(
      `${STEP}:getNextStep - reqPayload: ${JSON.stringify(reqPayload)} `,
      this.sessionData.sesion.clientId
    )

    // Lógica de obtención de parametros del step (BYC0010)
    try {
      this.parmsData = await this.getParms(
        'services.workflow.BYC0010',
        `canal=${this.sessionData.sesion.presentacion.consumer?.appConsumer?.canalId}&modulo=${this.sessionData.sesion.presentacion.module?.id}&lenguaje=${IDIOMA}&pais=${this.sessionData.sesion.presentacion.module?.country}&kind=${PRODUCTO}`
      )
    } catch (error) {
      this.logger.error(
        `${STEP}:getNextStep - error al obtener parametros: ${JSON.stringify(
          error
        )} `,
        this.sessionData.sesion.clientId
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    if (reqPayload.prevalidacion === false && reqPayload.atras === false) {
      this.sessionData.flujo.stepBYC0010 = true

      this.logger.debug(
        `${STEP}:getNextStep - estado control de flujo: `,
        this.sessionData.flujo.stepBYC0010
      )
      // Flujo: Segundo llamado del Front para pasar a la siguiente pantalla INFO0010
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          ciudadResidencia:
            this.sessionData.sesion.consultaClientePN.ciudadConDepartamento,
          direccionPrincipal:
            this.sessionData.sesion.consultaClientePN.direccionDI,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.INFO0010,
      }
      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      return nextStep
    }
    this.logger.debug(
      `${STEP}:getNextStep - parametros obtenidos: ${JSON.stringify(
        this.parmsData
      )} `,
      this.sessionData.sesion.clientId
    )
    // Lógica de obtención de parametros key AREASGEOGRAFICAS
    try {
      this.listaCiudadesCon = await this.persistence.getData(
        'parms',
        'AREASGEOGRAFICAS'
      )
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    this.logger.debug(
      `${STEP}:getNextStep - parametros listaCiudadesCon KEY AREASGEOGRAFICAS obtenidos: ${JSON.stringify(
        this.listaCiudadesCon
      )} `,
      this.sessionData.sesion.clientId
    )
    this.sessionData.sesion.grabarInfoSol.estadoDeLaSolicitud =
      this.parmsData.grabarInformacionSolicitudes.estadoPendiente
    this.sessionData.sesion.listasRestrictivas.tipoOperacionLog =
      this.parmsData.listasRestrictivas.tipoOperacionLog
    this.sessionData.sesion.listasRestrictivas.tipoPersona =
      this.parmsData.listasRestrictivas.tipoPersona
    this.sessionData.sesion.total = this.parmsData.total
    this.sessionData.sesion.listasRestrictivas.codigoSolicitud =
      this.parmsData.listasRestrictivas.codigoSolicitud
    this.sessionData.dataProducto.terminalId = this.parmsData.terminalId
    this.sessionData.dataProducto.locale = this.parmsData.locale
    this.sessionData.dataProducto.codIdioma = this.parmsData.codIdioma
    this.sessionData.sesion.grabarInfoSol.nroProceso =
      this.parmsData.grabarInformacionSolicitudes.numeroProcesoValidacionIngreso
    this.sessionData.sesion.consultaClientePN.tipoOperacionLog =
      this.parmsData.consultaClientePN.tipoOperacionLog

    // Lógica de establecer instante de expiración de la sesión
    let sessionTimeout = Number(this.parmsData.sessionTimeout)

    if (!sessionTimeout || isNaN(sessionTimeout)) {
      sessionTimeout = 1000 * 60 * 15 // Default 15 minutos
    }

    this.sessionData.sesion.expiracionSesion = new Date(
      Date.now() + sessionTimeout
    ).toISOString()
    // Lógica del step
    // validacion si ya recorrio el flujo previamente
    if (!this.sessionData.flujo.stepBYC0010) {
      let resultListasRest: any
      let resultConsultaClientPN: any
      let resultConsultaPersistencia: any
      let retomaValida: boolean

      // Flujo: Validacion de sesion retoma
      let resulRetoma: WorkflowData
      const key = `${this.sessionData.dataProducto.tipoDocumento}-${this.sessionData.dataProducto.numeroDocumento}`
      const kind = this.parmsData.kindRetoma
      try {
        resulRetoma = await this.persistence.getData(kind, key)

        this.logger.debug(
          `${STEP}: getNextStep - consulta sesion de retoma: ${key}, del kind: ${kind})`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.debug(
          `${STEP}: getNextStep - Fallo en la consulta de retoma: ${key}, del kind: ${kind})} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      retomaValida = false
      if (!(resulRetoma === null)) {
        // Flujo: Cliente con retoma
        if (resulRetoma instanceof Array) {
          resulRetoma = resulRetoma[0]
        }
        // si hay retoma parcial evita validar retoma real
        if (!resulRetoma.retomaParcial.status) {
          // tslint:disable: radix
          const vigenciaRetoma = this.parmsData.vigenciaRetoma * 60000
          const ahoraRetoma = new Date(new Date()).getTime()
          const ultimaRetoma = new Date(resulRetoma.flujo.fechaRetoma).getTime()

          const checkRetoma = Math.abs(ahoraRetoma - ultimaRetoma)
          this.sessionData.sesion.consultaPersistencia.nroSolicitudRetoma =
            resulRetoma.sesion.consultaPersistencia.nroSolicitud

          if (checkRetoma > vigenciaRetoma) {
            // Retoma no vigente , eliminar retoma
            // Eliminar datos de la retoma
            // tslint:disable-next-line: no-shadowed-variable
            const key = `${this.sessionData.dataProducto.tipoDocumento}-${this.sessionData.dataProducto.numeroDocumento}`
            try {
              await this.persistence.deleteData(KIND.RETOMA, key)

              this.logger.debug(
                `${STEP}: getNextStep - Eliminacion sesion de retoma: ${key}, del kind: ${kind})`,
                this.sessionData.sesion.clientId
              )
            } catch (error) {
              this.logger.debug(
                `${STEP}: getNextStep - Fallo en la Eliminacion de retoma: ${key}, del kind: ${kind})} `,
                this.sessionData.sesion.clientId
              )
              throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
            }

            /// Eliminacion PersistenciaCredito
            this.sessionData.sesion.consultaPersistencia.nroSolicitud =
              this.sessionData.sesion.consultaPersistencia.nroSolicitudRetoma
            try {
              const resultGrabarInfo =
                await this.autLivianaEliminarPersistencia()

              this.logger.debug(
                `${STEP}:getNextStep - Retoma autLivianaEliminarPersistencia ${JSON.stringify(
                  resultGrabarInfo
                )}`,
                this.sessionData.sesion.clientId
              )
            } catch (error) {
              this.logger.error(
                `${STEP}:getNextStep - Retoma error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
                  error
                )} `,
                this.sessionData.sesion.clientId
              )
              throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
            }
            retomaValida = false
          } else {
            retomaValida = true
            this.sessionData.flujo.clienteEnRetoma =
              resulRetoma.flujo.clienteEnRetoma
            this.sessionData.sesion.clientId = resulRetoma.sesion.clientId
            this.logger.debug(
              `${STEP}: getNextStep - Retoma valida `,
              this.sessionData.sesion.clientId
            )
          }
        } else {
          this.sessionData.retomaParcial.status =
            resulRetoma.retomaParcial.status
          this.sessionData.retomaParcial.nroSolicitud =
            resulRetoma.retomaParcial.nroSolicitud
          this.sessionData.flujo.clienteEnRetoma =
            resulRetoma.flujo.clienteEnRetoma
        }
      }

      // consumo ConsultaPersistencia
      try {
        resultConsultaPersistencia = await this.consultarPersistenciaCredito()
        this.sessionData.sesion.consultaPersistencia.nroSolicitud =
          resultConsultaPersistencia?.data?.Data?.nroSolicitud
            ? resultConsultaPersistencia?.data?.Data?.nroSolicitud
            : this.sessionData.retomaParcial.nroSolicitud
        // this.sessionData.sesion.consultaPersistencia.nroSolicitud = resultConsultaPersistencia?.data?.Data?.nroSolicitud
        this.logger.debug(
          `${STEP}:getNextStep - consultarPersistenciaCredito ${JSON.stringify(
            resultConsultaPersistencia
          )}`,
          this.sessionData.sesion.clientId
        )
        if (this.sessionData.sesion.consultaPersistencia.nroSolicitud) {
          // el status cambia en INFO0010
          this.sessionData.retomaParcial.status = this.sessionData.flujo
            .clienteEnRetoma
            ? false
            : true
          this.sessionData.retomaParcial.nroSolicitud =
            this.sessionData.sesion.consultaPersistencia.nroSolicitud

          if (!this.sessionData.flujo.clienteEnRetoma) {
            // Persistir datos de la retoma, para usar retoma parcial
            const keyP = `${this.sessionData.dataProducto.tipoDocumento}-${this.sessionData.dataProducto.numeroDocumento}`
            try {
              await this.persistence.setData(
                KIND.RETOMA,
                keyP,
                this.sessionData
              )
            } catch (error) {
              throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
            }
          }
        }

        if (
          resultConsultaPersistencia.data.DataHeader.caracterAceptacion ===
            'M' &&
          resultConsultaPersistencia.data.DataHeader.codMsgRespuesta ===
            this.parmsData.consultaPersistenciaCredito.codMsgRespuesta
        ) {
          // this.sessionData.sesion.evaluadorPCO.valorAprobado = result.data.ValorAprobado
          this.sessionData.sesion.grabarInfoSol.motivoRechazo =
            this.parmsData.consultaPersistenciaCredito.motivoRechazoNegaciones
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoPendiente
          this.sessionData.sesion.grabarInfoSol.nroProceso =
            this.parmsData.grabarInformacionSolicitudes.numeroProcesoValidacionIngreso

          try {
            const resultGrabarInfo = await this.grabarInformacionSolicitudes()

            this.logger.debug(
              `${STEP}:getNextStep - RetomaParcial - Credito negado - grabarInformacionSolicitudes ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - RetomaParcial - Credito negado- error al consumir grabarInformacionSolicitudes ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }
          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_013,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > Cliente supera intentos negados: ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )
          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir consultarPersistenciaCredito ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      // consumo listasRestrictivas
      try {
        resultListasRest = await this.consultaListasRestrictivas()

        this.logger.debug(
          `${STEP}:getNextStep - consultaListasRestrictivas ${JSON.stringify(
            resultListasRest
          )}`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir consultaListasRestrictivas ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
      // control respuesta caracter M
      if (resultListasRest.data.DataHeader.caracterAceptacion === 'M') {
        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_004,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.BYC0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > Error listasRestrictivas, caracter de aceptacion M: ${JSON.stringify(
            nextStep
          )}`,
          this.sessionData.sesion.clientId
        )
        return nextStep
      }

      // Consumo ConsultaClientPN

      try {
        resultConsultaClientPN = await this.consultaClientePN()

        this.logger.debug(
          `${STEP}:getNextStep - consultaClientePN ${JSON.stringify(
            resultConsultaClientPN
          )}`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir consultaClientePN ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      // Validacion Datos minimos 360
      if (
        !resultConsultaClientPN.data.Data.datos_PN.cliente.sexoCLI ||
        !UTILITIES.buscarIngresosPN(
          resultConsultaClientPN?.data?.Data?.datos_PN?.ingresos,
          true
        )?.codActLaboralIN ||
        !UTILITIES.buscarIngresosPN(
          resultConsultaClientPN?.data?.Data?.datos_PN?.ingresos,
          true
        )?.actEconomicaIN ||
        !UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.ciudadDI ||
        !UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.departamentoDI ||
        !resultConsultaClientPN.data.Data.datos_PN.cliente.fechaNacimientoCLI ||
        !resultConsultaClientPN.data.Data.datos_PN.cliente.nombresCLI ||
        !UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.direccionDI ||
        !UTILITIES.buscarEmailPn(
          resultConsultaClientPN.data.Data.datos_PN.emails
        )?.emailEM ||
        !UTILITIES.buscarCelularPn(
          resultConsultaClientPN.data.Data.datos_PN.celulares
        )?.numeroCL ||
        !resultConsultaClientPN.data.Data.datos_PN.cliente.oficinaRadicacionCLI
      ) {
        // se persiste motivoRechazo 2
        this.sessionData.sesion.grabarInfoSol.motivoRechazo =
          this.parmsData.consultaClientePN.motivoRechazoInformacioCliente
        this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
          this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
        /// GrabarInformacionSolicitudes
        try {
          const resultGrabarInfo = await this.grabarInformacionSolicitudes()

          this.logger.debug(
            `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        /// Eliminacion PersistenciaCredito
        try {
          const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

          this.logger.debug(
            `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_003,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.BYC0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
          this.sessionData.sesion.clientId
        )
        this.logger.debug(
          `${STEP}:getNextStep > BYC0010 - Flujo: Cliente con datos minimos validacion360 incompletos  (Postmessage)`,
          this.sessionData.sesion.clientId
        )
        return nextStep
      }

      // Persitencia resultado consumo ConsultaClientePN
      this.sessionData.sesion.consultaClientePN.sexoCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.sexoCLI
      this.sessionData.sesion.consultaClientePN.departamentoDI =
        UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.departamentoDI
      this.sessionData.sesion.consultaClientePN.fechaExpedicionCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.fechaExpedicionCLI
      this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.fechaNacimientoCLI
      this.sessionData.sesion.consultaClientePN.nombres =
        resultConsultaClientPN.data.Data.datos_PN.cliente.nombresCLI
      this.sessionData.sesion.consultaClientePN.primerApellido =
        resultConsultaClientPN.data.Data.datos_PN.cliente.primerApellidoCLI
      this.sessionData.sesion.consultaClientePN.segundoApellido =
        resultConsultaClientPN.data.Data.datos_PN.cliente.segundoApellidoCLI
      this.sessionData.sesion.consultaClientePN.ingresos =
        UTILITIES.buscarIngresosPN(
          resultConsultaClientPN?.data?.Data?.datos_PN?.ingresos,
          true
        )?.valorIN
      this.sessionData.sesion.consultaClientePN.oficinaRadicacionCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.oficinaRadicacionCLI
      this.sessionData.sesion.consultaClientePN.valIngresoEspecialistaCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.valIngresoEspecialistaCLI
      this.sessionData.sesion.consultaClientePN.lugarExpedicionCLI =
        resultConsultaClientPN.data.Data.datos_PN.cliente.lugarExpedicionCLI
      this.sessionData.sesion.consultaClientePN.email = UTILITIES.buscarEmailPn(
        resultConsultaClientPN.data.Data.datos_PN.emails
      )?.emailEM
      this.sessionData.sesion.consultaClientePN.direccionDI =
        UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.direccionDI
      this.sessionData.sesion.consultaClientePN.ciudadDI =
        UTILITIES.buscarDireccion(
          resultConsultaClientPN.data.Data.datos_PN.direcciones
        )?.ciudadDI
      this.sessionData.sesion.consultaClientePN.numeroCel =
        UTILITIES.buscarCelularPn(
          resultConsultaClientPN.data.Data.datos_PN.celulares
        )?.numeroCL
      // Homlogacion de id de cuidad
      const listaCiudades = this.listaCiudadesCon[0].listaCiudades
      listaCiudades.forEach(
        (element: {
          codCiudad: string
          descDepto: string
          descCiudad: string
        }) => {
          if (
            element.codCiudad ===
            this.sessionData.sesion.consultaClientePN.ciudadDI
          ) {
            this.sessionData.sesion.consultaClientePN.ciudadConDepartamento = `${element.descCiudad} - ${element.descDepto}`
            this.sessionData.sesion.consultaClientePN.ciudad =
              element.descCiudad
            this.sessionData.sesion.consultaClientePN.departamento =
              element.descDepto
          }
          if (
            this.sessionData.sesion.consultaClientePN.lugarExpedicionCLI.includes(
              element.codCiudad
            )
          ) {
            this.sessionData.sesion.consultaClientePN.ciudadExpedicion =
              element.descCiudad
          }
        }
      )

      // Validacion rechazo listrasRestrictivas
      if (
        !this.parmsData.listasRestrictivas.valRespuesta.includes(
          resultListasRest.data.Data.valRespuesta
        )
      ) {
        // se persiste motivoRechazo 4
        this.sessionData.sesion.grabarInfoSol.motivoRechazo =
          this.parmsData.listasRestrictivas.motivoRechazoListas
        this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
          this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
        /// GrabarInformacionSolicitudes
        try {
          const resultGrabarInfo = await this.grabarInformacionSolicitudes()

          this.logger.debug(
            `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        /// Eliminacion PersistenciaCredito
        try {
          const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

          this.logger.debug(
            `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_005,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.BYC0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
          this.sessionData.sesion.clientId
        )
        this.logger.debug(
          `${STEP}:getNextStep > BYC0010 - Flujo validacion listaRestrictiva rechazado - motivoRechazo 4`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      } else if (
        resultListasRest.data.Data.valRespuesta ===
          this.parmsData.listasRestrictivas.valRespuestaI &&
        this.parmsData.listasRestrictivas.listasAsegurables.includes(
          resultListasRest.data.Data.valInformacionAdicional
        )
      ) {
        // se persiste motivoRechazo 3
        this.sessionData.sesion.grabarInfoSol.motivoRechazo =
          this.parmsData.listasRestrictivas.motivoRechazoAsegurabilidad
        this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
          this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
        /// GrabarInformacionSolicitudes
        try {
          const resultGrabarInfo = await this.grabarInformacionSolicitudes()

          this.logger.debug(
            `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        /// Eliminacion PersistenciaCredito
        try {
          const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

          this.logger.debug(
            `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_002,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: 'appFinish',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.MENSAJE_POST,
          stepId: STEP_ID.BYC0010,
        }

        this.logger.debug(
          `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
          this.sessionData.sesion.clientId
        )
        this.logger.debug(
          `${STEP}:getNextStep > BYC0010 - Flujo validacion listaRestrictiva rechazado - Lista Asegurabilidad`,
          this.sessionData.sesion.clientId
        )

        return nextStep
      }
      // Validacion productos en Mora
      try {
        const result = await this.consultaProductosEnMora()

        this.logger.debug(
          `${STEP}:getNextStep - consultaProductosEnMora ${JSON.stringify(
            result
          )}`,
          this.sessionData.sesion.clientId
        )

        if (result.data === 1) {
          // se persiste motivoRechazo 16
          this.sessionData.sesion.grabarInfoSol.motivoRechazo =
            this.parmsData.productosEnMora.motivoRechazoClienteMora
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
          /// GrabarInformacionSolicitudes
          try {
            const resultGrabarInfo = await this.grabarInformacionSolicitudes()

            this.logger.debug(
              `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }
          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_007,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          /// Eliminacion PersistenciaCredito
          try {
            const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

            this.logger.debug(
              `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }
          this.logger.debug(
            `${STEP}:getNextStep > Tiene Productos en mora: ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )
          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir consultaProductosEnMora ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      this.logger.debug(
        `${STEP}:getNextStep > No Tiene Productos en mora:`,
        this.sessionData.sesion.clientId
      )

      // ConsultaProductos

      try {
        const resultconsultaProd = await this.consultaProductos()

        this.logger.debug(
          `${STEP}:getNextStep - ConsultaProductos ${JSON.stringify(
            resultconsultaProd
          )}`,
          this.sessionData.sesion.clientId
        )
        if (!resultconsultaProd) {
          // Flujo: Error Clientes sin registros

          // se persiste motivoRechazo 9
          this.sessionData.sesion.grabarInfoSol.motivoRechazo =
            this.parmsData.consultaProductos.motivoRechazoConsultaProductos
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
          /// GrabarInformacionSolicitudes
          try {
            const resultGrabarInfo = await this.grabarInformacionSolicitudes()

            this.logger.debug(
              `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }

          /// Eliminacion PersistenciaCredito
          try {
            const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

            this.logger.debug(
              `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }

          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_011,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > ConsultaProductos: Clientes sin registros ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }
        // logger prueba
        this.logger.debug(
          `${STEP}:getNextStep - ConsultaProductos: cuentas validas ${JSON.stringify(
            this.sessionData.sesion.consultaProducto.registros
          )} `,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir ConsultaProductos ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      // GrabarInformacionSolicitudes
      this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
        this.parmsData.grabarInformacionSolicitudes.estadoPendiente

      if (!this.sessionData.flujo.clienteEnRetoma) {
        try {
          const resultGrabarInfo = await this.grabarInformacionSolicitudes()
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoPendiente
          this.logger.debug(
            `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
              resultGrabarInfo
            )}`,
            this.sessionData.sesion.clientId
          )
        } catch (error) {
          this.logger.error(
            `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
              error
            )} `,
            this.sessionData.sesion.clientId
          )
          throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
        }
      }
      this.logger.debug(
        `${STEP}:getNextStep - grabarInformacionSolicitudes No se consume en retoma `,
        this.sessionData.sesion.clientId
      )
      // ConsultaRotativo

      try {
        const resultConsultaRotativo = await this.consultaRotativo()

        this.logger.debug(
          `${STEP}:getNextStep - consultaRotativo ${JSON.stringify(
            resultConsultaRotativo
          )}`,
          this.sessionData.sesion.clientId
        )
        if (!resultConsultaRotativo) {
          // Flujo: Error Clientes con creditos rotativos

          // se persiste motivoRechazo 8
          this.sessionData.sesion.grabarInfoSol.motivoRechazo =
            this.parmsData.consultaRotativo.motivoRechazoRotativo
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoNoUtilizado
          /// GrabarInformacionSolicitudes
          try {
            const resultGrabarInfo = await this.grabarInformacionSolicitudes()

            this.logger.debug(
              `${STEP}:getNextStep - grabarInformacionSolicitudes ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir grabarInformacionSolicitudes ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }

          /// Eliminacion PersistenciaCredito

          try {
            const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

            this.logger.debug(
              `${STEP}:getNextStep - autLivianaEliminarPersistencia ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }

          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_008,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > consultaRotativo: Clientes con creditos rotativos ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )

          return nextStep
        }
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - error al consumir consultaRotativo ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      if (retomaValida) {
        // control de flujo
        this.sessionData.flujo.stepBYC0010 = true
        this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
          this.parmsData.grabarInformacionSolicitudes.estadoPendiente
        this.logger.debug(
          `${STEP}:getNextStep - estado control de flujo: `,
          this.sessionData.flujo.stepBYC0010
        )
        // control retoma inicio
        this.sessionData.sesionRetoma = resulRetoma.sesion

        nextStep = {
          clientId: this.getClientId(),
          payload: {
            canal: this.sessionData.dataProducto.canalId,
            kind: this.sessionData.dataProducto.moduloId,
            lenguaje: this.sessionData.dataProducto.codIdioma,
            message: STATUS_MSG.MSG_crrt_012,
            modulo: this.parmsData.kind,
            pais: this.sessionData.dataProducto.country,
            redirectPostMessage: '',
            tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          },
          status: STATUS_ID.RETOMA,
          stepId: STEP_ID.BYC0010,
        }
        this.logger.debug(
          `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
          this.sessionData.sesion.clientId
        )
        this.logger.debug(
          `${STEP}:getNextStep > BYC0010 - Flujo Retoma: se redirecciona PopUp Retoma`,
          this.sessionData.sesion.clientId
        )
        return nextStep

        // control retoma fin
      }
    }

    if (reqPayload.aceptoRetoma) {
      const datosRetoma = this.sessionData.sesionRetoma

      // control consumoEvaluador dentro de la retoma
      try {
        const result = await this.consumoEvaluador(datosRetoma)

        this.logger.debug(
          `${STEP}:getNextStep - Retoma consumoEvaluador ${JSON.stringify(
            result
          )}`,
          this.sessionData.sesion.clientId
        )
        // persistir en sesion los datos de consumo evaluador
        this.sessionData.sesion.evaluadorPCO.causalDecisionSolicitud =
          result.data.CausalDecisionSolicitud
        this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud =
          result.data.CodigoCausalDecisionSolicitud
        this.sessionData.sesion.evaluadorPCO.decisionCategory =
          result.data.DecisionCategory
        this.sessionData.sesion.evaluadorPCO.valorAprobado =
          result.data.ValorAprobado
        this.sessionData.sesion.evaluadorPCO.valorCobroSeguroVida =
          result.data.ValorCobroSeguroVida
        this.sessionData.sesionRetoma.evaluadorPCO.valorAprobado =
          result.data.ValorAprobado

        if (result.data.CaracterAceptacion === 'M') {
          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_004,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > Retoma Error consumoEvaluador, caracter de aceptacion M: ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )
          return nextStep
        }

        if (result.data.DecisionCategory === 'NEG') {
          this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
            this.parmsData.grabarInformacionSolicitudes.estadoNegado
          this.sessionData.sesion.evaluadorPCO.valorAprobado =
            result.data.ValorAprobado
          this.sessionData.sesion.grabarInfoSol.nroProceso =
            this.parmsData.grabarInformacionSolicitudes.numeroProcesoEvaluacion

          try {
            const resultGrabarInfo = await this.grabarInformacionSolicitudes()

            this.logger.debug(
              `${STEP}:getNextStep - Retoma - Credito negado - grabarInformacionSolicitudes ${JSON.stringify(
                resultGrabarInfo
              )}`,
              this.sessionData.sesion.clientId
            )
          } catch (error) {
            this.logger.error(
              `${STEP}:getNextStep - Retoma - Credito negado- error al consumir grabarInformacionSolicitudes ${JSON.stringify(
                error
              )} `,
              this.sessionData.sesion.clientId
            )
            throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
          }
          nextStep = {
            clientId: this.getClientId(),
            payload: {
              canal: this.sessionData.dataProducto.canalId,
              kind: this.sessionData.dataProducto.moduloId,
              lenguaje: this.sessionData.dataProducto.codIdioma,
              message: STATUS_MSG.MSG_crrt_010,
              modulo: this.parmsData.kind,
              pais: this.sessionData.dataProducto.country,
              redirectPostMessage: 'appFinish',
              tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
            },
            status: STATUS_ID.MENSAJE_POST,
            stepId: STEP_ID.BYC0010,
          }

          this.logger.debug(
            `${STEP}:getNextStep > Retoma Credito Negado: ${JSON.stringify(
              nextStep
            )}`,
            this.sessionData.sesion.clientId
          )
          return nextStep
        }
        // nuevo seteo de retoma
        this.sessionData.sesionRetoma.app.llaveEncriptacion =
          this.sessionData.sesion.app.llaveEncriptacion
        this.sessionData.sesionRetoma.ip = this.sessionData.sesion.ip
        this.sessionData.sesionRetoma.presentacion =
          this.sessionData.sesion.presentacion
        this.sessionData.sesion = this.sessionData.sesionRetoma
        this.sessionData.retomaParcial.status = false
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - Retoma error al consumir consumoEvaluador ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
      this.logger.debug(
        `${STEP}:getNextStep > Retoma Aprobado consumoEvaluador `,
        this.sessionData.sesion.clientId
      )

      this.sessionData.sesion.grabarInfoSol.nroProceso =
        this.parmsData.grabarInformacionSolicitudes.numeroProcesoEvaluacion
      this.sessionData.sesion.grabarInfoSol.estadosDeLaSolicitud =
        this.parmsData.grabarInformacionSolicitudes.estadoAprobado
      try {
        const resultGrabarInfo = await this.grabarInformacionSolicitudes()

        this.logger.debug(
          `${STEP}:getNextStep - Retoma - Credito aprobado- grabarInformacionSolicitudes ${JSON.stringify(
            resultGrabarInfo
          )}`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - Retoma error al consumir grabarInformacionSolicitudes ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
      this.sessionData.flujo.stepBYC0010 = true

      this.logger.debug(
        `${STEP}:getNextStep - estado control de flujo: `,
        this.sessionData.flujo.stepBYC0010
      )
      // Flujo: se redirecciona step FELI0010
      nextStep = {
        clientId: this.getClientId(),
        payload: {
          canal: this.sessionData.dataProducto.canalId,
          kind: this.sessionData.dataProducto.moduloId,
          lenguaje: this.sessionData.dataProducto.codIdioma,
          message: '',
          modulo: this.parmsData.kind,
          pais: this.sessionData.dataProducto.country,
          redirectPostMessage: '',
          tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
          valorAprobado: this.sessionData.sesion.evaluadorPCO.valorAprobado,
          valorCobroSeguroVida:
            this.sessionData.sesion.evaluadorPCO.valorCobroSeguroVida,
          // tslint:disable-next-line: object-literal-sort-keys
          decisionCategory:
            this.sessionData.sesion.evaluadorPCO.decisionCategory,
          codigoCausalDecisionSolicitud:
            this.sessionData.sesion.evaluadorPCO.codigoCausalDecisionSolicitud
              .codigoCausalDecisionSolicitud1,
          causalDecisionSolicitud:
            this.sessionData.sesion.evaluadorPCO.causalDecisionSolicitud,
        },
        status: STATUS_ID.NORMAL,
        stepId: STEP_ID.FELI0010,
      }

      this.logger.debug(
        `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
        this.sessionData.sesion.clientId
      )
      this.logger.debug(
        `${STEP}:getNextStep > BYC0010 - Flujo Retoma se redirecciona step FELI0010`,
        this.sessionData.sesion.clientId
      )

      return nextStep
    }
    if (reqPayload.rechazoRetoma) {
      // Flujo: Eliminacion de sesion retoma

      const key = `${this.sessionData.dataProducto.tipoDocumento}-${this.sessionData.dataProducto.numeroDocumento}`
      const kind = this.parmsData.kindRetoma
      try {
        await this.persistence.deleteData(kind, key)

        this.logger.debug(
          `${STEP}: getNextStep - Eliminacion sesion de retoma: ${key}, del kind: ${kind})`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.debug(
          `${STEP}: getNextStep - Fallo en la Eliminacion de retoma: ${key}, del kind: ${kind})} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }

      /// Eliminacion PersistenciaCredito
      this.sessionData.sesion.consultaPersistencia.nroSolicitud =
        this.sessionData.sesion.consultaPersistencia.nroSolicitudRetoma

      try {
        const resultGrabarInfo = await this.autLivianaEliminarPersistencia()

        this.logger.debug(
          `${STEP}:getNextStep - Retoma autLivianaEliminarPersistencia ${JSON.stringify(
            resultGrabarInfo
          )}`,
          this.sessionData.sesion.clientId
        )
      } catch (error) {
        this.logger.error(
          `${STEP}:getNextStep - Retoma error al consumir autLivianaEliminarPersistencia ${JSON.stringify(
            error
          )} `,
          this.sessionData.sesion.clientId
        )
        throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
      }
    }

    // Flujo: Prevalidaciones Exitosas
    nextStep = {
      clientId: this.getClientId(),
      payload: {
        canal: this.sessionData.dataProducto.canalId,
        kind: this.sessionData.dataProducto.moduloId,
        lenguaje: this.sessionData.dataProducto.codIdioma,
        message: '',
        modulo: this.parmsData.kind,
        pais: this.sessionData.dataProducto.country,
        redirectPostMessage: '',
        tokenFrontend: this.sessionData.dataProducto.tokenFrontend,
      },
      status: STATUS_ID.NORMAL,
      stepId: STEP_ID.BYC0010,
    }

    this.logger.debug(
      `${STEP}:getNextStep > nextStep: ${JSON.stringify(nextStep)}`,
      this.sessionData.sesion.clientId
    )
    this.logger.debug(
      `${STEP}:getNextStep > BYC0010 - Flujo validacionPrevias Exitoso`,
      this.sessionData.sesion.clientId
    )

    return nextStep
  }

  /**
   *
   * LLAMADA A SERVICIO DE PARAMETROS
   *
   */

  private getParms = async (nodo: string, filtros: any) => {
    const endpointUrl = `${
      this.config.getVars().back.parmsServiceUrl
    }/parms/${nodo}?${filtros}`

    this.logger.debug(
      `${STEP}:getParms - get: ${JSON.stringify(endpointUrl)}`,
      this.sessionData.sesion.clientId
    )

    let serviceData: any

    try {
      serviceData = await axios.get(endpointUrl)
    } catch (error) {
      this.logger.error(
        `${STEP}:getParms - nodo: ${nodo} - filtros: ${filtros} - error: ${error}`
      )
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (serviceData.data.errors && serviceData.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(serviceData.data.errors))
      )
    }

    const valParmsSvc = serviceData.data.data

    this.logger.debug(
      `${STEP}:getParms - Response: ${JSON.stringify(valParmsSvc)}`,
      this.sessionData.sesion.clientId
    )

    return valParmsSvc
  }

  private consultaListasRestrictivas = async () => {
    this.logger.debug(
      'consultaListasRestrictivas',
      this.sessionData.sesion.clientId
    )

    let resultListasRest: any
    const endpointUrl = `${
      this.config.getVars().back.prevalidacionServiceUrl
    }/consultarListasRestrictivas`

    let appConsumerObject: any = ''
    let deviceConsumerObject: any = ''
    let modulo: any = ''

    if (this.sessionData.sesion.presentacion.consumer) {
      this.sessionData.dataProducto.sesionIdCanal =
        this.sessionData.sesion.clientId
      appConsumerObject = {
        canalId: this.sessionData.dataProducto.canalId,
        id: this.sessionData.dataProducto.moduloId,
        sessionId: this.sessionData.dataProducto.sesionIdCanal,
        terminalId: this.sessionData.dataProducto.terminalId,
        transactionId: this.sessionData.dataProducto.transactionId,
      }
      ;(deviceConsumerObject = {
        id: this.sessionData.dataProducto.deviceConsumerId,
        inactiveInterval: this.sessionData.dataProducto.inactiveInterval,
        locale: this.parmsData.locale,
        sessionTimeout: this.parmsData.sessionTimeout,
        userAgent: this.sessionData.dataProducto.userAgent,
      }),
        (modulo = {
          country: this.sessionData.dataProducto.country,
          id: this.sessionData.dataProducto.moduloId,
        })
    }
    const transaccionID = moment().unix()

    const payload = {
      codigoSolicitud: this.parmsData.listasRestrictivas.codigoSolicitud,
      documento: {
        numero: this.sessionData.dataProducto.numeroDocumento,
        tipo: this.sessionData.dataProducto.tipoDocumento,
      },
      idTransaccion: transaccionID.toString(),
      ip: this.sessionData.sesion.ip,
      presentacionCliente: {
        consumer: {
          appConsumer: appConsumerObject,
          deviceConsumer: deviceConsumerObject,
        },
        module: modulo,
      },
      sessionIdWf: this.sessionData.sesion.clientId,
      tipoOperacionLog:
        this.sessionData.sesion.listasRestrictivas.tipoOperacionLog,
      tipoPersona: this.sessionData.sesion.listasRestrictivas.tipoPersona,
      total: this.sessionData.sesion.total,
    }

    try {
      resultListasRest = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultListasRest.data.errors &&
      resultListasRest.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultListasRest.data.errors))
      )
    }

    const listasRes = resultListasRest.data.data
    this.logger.debug(
      `${STEP}:listasRestrictivas - Response: ${JSON.stringify(listasRes)}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: listasRes,
    }
  }

  private consultaClientePN = async () => {
    this.logger.debug('consultarClientePN', this.sessionData.sesion.clientId)

    let resultClientePN: any
    const endpointUrl = `${
      this.config.getVars().back.prevalidacionServiceUrl
    }/consultarClientePN`

    let appConsumerObject: any = ''
    let deviceConsumerObject: any = ''
    let modulo: any = ''

    if (this.sessionData.sesion.presentacion.consumer) {
      this.sessionData.dataProducto.sesionIdCanal =
        this.sessionData.sesion.clientId
      appConsumerObject = {
        canalId: this.sessionData.dataProducto.canalId,
        id: this.sessionData.dataProducto.moduloId,
        sessionId: this.sessionData.dataProducto.sesionIdCanal,
        terminalId: this.sessionData.dataProducto.terminalId,
        transactionId: this.sessionData.dataProducto.transactionId,
      }
      ;(deviceConsumerObject = {
        id: this.sessionData.dataProducto.deviceConsumerId,
        inactiveInterval: this.sessionData.dataProducto.inactiveInterval,
        locale: this.parmsData.locale,
        sessionTimeout: this.parmsData.sessionTimeout,
        userAgent: this.sessionData.dataProducto.userAgent,
      }),
        (modulo = {
          country: this.sessionData.dataProducto.country,
          id: this.sessionData.dataProducto.moduloId,
        })
    }
    const transaccionID = moment().unix()

    const payload = {
      documento: {
        numero: this.sessionData.dataProducto.numeroDocumento,
        tipo: this.sessionData.dataProducto.tipoDocumento,
      },
      idTransaccion: transaccionID.toString(),
      ip: this.sessionData.sesion.ip,
      presentacionCliente: {
        consumer: {
          appConsumer: appConsumerObject,
          deviceConsumer: deviceConsumerObject,
        },
        module: modulo,
      },
      sessionIdWf: this.sessionData.sesion.clientId,
      tipoOperacionLog:
        this.sessionData.sesion.consultaClientePN.tipoOperacionLog,
      total: this.sessionData.sesion.total,
    }

    try {
      resultClientePN = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (resultClientePN.data.errors && resultClientePN.data.errors.length > 0) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultClientePN.data.errors))
      )
    }

    const clientePNRes = resultClientePN.data.data
    this.logger.debug(
      `${STEP}:ConsultaClientePN - Response: ${JSON.stringify(clientePNRes)}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: clientePNRes,
    }
  }

  private grabarInformacionSolicitudes = async () => {
    this.logger.debug(
      'grabarInformacionSolicitudes',
      this.sessionData.sesion.clientId
    )

    let resultGrabarRest: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/grabar`

    // prueba modelo GrabarInformacionSolicitudesModel
    const payload = new GrabarInformacionSolicitudesModel()
    await payload.setObject(this.sessionData, this.parmsData)
    await payload.getObject()
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - request: ${JSON.stringify(
        payload
      )}`,
      this.sessionData.sesion.clientId
    )
    try {
      resultGrabarRest = await axios.post(endpointUrl, payload.getObject())
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultGrabarRest.data.errors &&
      resultGrabarRest.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultGrabarRest.data.errors))
      )
    }

    const grabarRes = resultGrabarRest.data
    this.logger.debug(
      `${STEP}:grabarInformacionSolicitudes - Response: ${JSON.stringify(
        grabarRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: grabarRes,
    }
  }

  private consultarPersistenciaCredito = async () => {
    this.logger.debug(
      'consultarPersistenciaCredito',
      this.sessionData.sesion.clientId
    )

    let resultConsultaPersis: any
    const endpointUrl = `${
      this.config.getVars().back.credito2NegocioService
    }/service`

    const transaccionID = moment().unix()
    const payloadData = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              total: this.sessionData.sesion.total,
              // tslint:disable-next-line: object-literal-sort-keys
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: transaccionID.toString(),
            },
            // tslint:disable-next-line: object-literal-sort-keys
            Data: {
              idSesion: this.sessionData.dataProducto.sesionIdCanal,
              // tslint:disable-next-line: object-literal-sort-keys
              codIdioma: this.sessionData.dataProducto.codIdioma,
              valOrigen: this.sessionData.sesion.ip,
              codPais: this.sessionData.dataProducto.country,
              aplicacionOrigen: this.sessionData.dataProducto.canalId,
              ipOrigen: this.sessionData.sesion.ip,
              tipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
              nroIdentificacion: this.sessionData.dataProducto.numeroDocumento,
              tipoConsulta: this.sessionData.flujo.clienteEnRetoma
                ? this.parmsData.consultaPersistenciaCredito.retomaSolicitud
                : this.parmsData.consultaPersistenciaCredito.nuevaSolicitud,
              codigoProductoRPRsolicitado: this.parmsData.grupoProductoRPRBuro,
              codigoSubproductoRPRsolicitado:
                this.parmsData.grupoSubproductoRPRBuro,
            },
          },
        },
        // tslint:disable-next-line: object-literal-sort-keys
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          // tslint:disable-next-line: object-literal-sort-keys
          canalId: this.sessionData.dataProducto.canalId,
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          moduleId: this.sessionData.dataProducto.moduloId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          logger: this.parmsData.loggerVersion,
        },
      },
    }

    try {
      resultConsultaPersis = await axios.post(endpointUrl, payloadData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultConsultaPersis.data.errors &&
      resultConsultaPersis.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultConsultaPersis.data.errors))
      )
    }

    const persistenciaRes = resultConsultaPersis.data.Response
    this.logger.debug(
      `${STEP}:consultarPersistenciaCredito - Response: ${JSON.stringify(
        persistenciaRes
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: persistenciaRes,
    }
  }

  private consultaProductosEnMora = async () => {
    this.logger.debug(
      'consultaProductosEnMora',
      this.sessionData.sesion.clientId
    )

    let consultaMoraRest: any

    const endpointUrl = `${
      this.config.getVars().back.validacionPreviaServiceUrl
    }/validacion-moras`

    const payload = {
      payload: {
        auditoriaJuridico: false, // obtener de objeto para mas micros
        auditoriaOperaciones: true,
        datapower: {
          codCanal: this.sessionData.dataProducto.canalId,
          codPais: this.sessionData.dataProducto.country.toLowerCase(),
        },
        juridico: null,
        operaciones: {
          consumer: {
            appConsumer: {
              canalId: this.sessionData.dataProducto.canalId,
              id: this.sessionData.dataProducto.moduloId,
              sessionId: this.sessionData.sesion.clientId,
            },
            deviceConsumer: {
              id: this.sessionData.dataProducto.deviceConsumerId,
              ip: this.sessionData.sesion.ip,
              locale: this.parmsData.locale,
              terminalId: this.sessionData.dataProducto.terminalId,
              userAgent: this.sessionData.dataProducto.userAgent,
            },
          },
          documento: {
            numero: this.sessionData.dataProducto.numeroDocumento,
            tipo: this.sessionData.dataProducto.tipoDocumento,
          },
          messages: {
            idService: this.parmsData.productosEnMora.idService,
            requestService: '',
            responseService: '',
          },
          operation: {
            operationDate: new Date().toISOString(),
            statusResponse: {
              status:
                this.parmsData.productosEnMora.operaciones.operation
                  .statusResponse.status,
            },
            type: this.parmsData.productosEnMora.operaciones.operation.type,
          },
        },
        service: {
          request: {
            data: {
              codIdioma: this.parmsData.codIdioma,
              codPais: this.sessionData.dataProducto.country,
              codTipoIdentificacion:
                this.sessionData.dataProducto.tipoDocumento,
              idSesion: this.sessionData.sesion.clientId,
              valIpOrigen: this.sessionData.sesion.ip,
              valNumeroIdentificacion:
                this.sessionData.dataProducto.numeroDocumento,
              valOrigen: this.sessionData.sesion.ip,
              valProductoRrpSolicitado:
                this.parmsData.productosEnMora.data.valProductoRrpSolicitado,
              valSubproductoRprSolicitado:
                this.parmsData.productosEnMora.data.valSubproductoRprSolicitado,
            },
            dataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: moment().unix(),
              jornada: this.parmsData.productosEnMora.dataHeader.jornada,
              modoDeOperacion:
                this.parmsData.productosEnMora.dataHeader.modoDeOperacion,
              nombreOperacion:
                this.parmsData.productosEnMora.dataHeader.nombreOperacion,
              perfil: this.parmsData.productosEnMora.dataHeader.perfil,
              total: '',
              usuario: this.parmsData.productosEnMora.dataHeader.usuario,
              versionServicio:
                this.parmsData.productosEnMora.dataHeader.versionServicio,
            },
          },
        },
        // tokenDatapower: "vj7M3+1J8d7HDb3ekQSYcsqpDJ827DX8xm986WmaGQ=" // muy posiblemente no sea necesario
      },
    }

    try {
      consultaMoraRest = await axios.post(endpointUrl, payload)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      consultaMoraRest.data.codError ||
      parseInt(consultaMoraRest.data.status, 10) === 500
    ) {
      {
        throw new ServiceError(
          MBAAS_ERRORS.internal_server_error,
          new Error(JSON.stringify(consultaMoraRest.data.errors))
        )
      }
    }

    const consultaMoraSalida = {
      // caracterAceptacion : consultaMoraRest.data.response.response.dataHeader.caracterAceptacion,
      codMsgRespuesta:
        consultaMoraRest.data.response.response.dataHeader.codMsgRespuesta,
      // msgRespuesta : consultaMoraRest.data.response.response.dataHeader.msgRespuesta.trim()
    }

    this.logger.debug(
      `${STEP}:consultaProductosEnMora - Response: ${JSON.stringify(
        consultaMoraSalida
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: consultaMoraRest.data.response.response.dataHeader.codMsgRespuesta,
    }
  }

  private consultaProductos = async () => {
    this.logger.debug('consultaProductos', this.sessionData.sesion.clientId)

    let resultConsultaProd: any
    const endpointUrl = `${
      this.config.getVars().back.soapWebService
    }/soap-service`

    const transaccionID = moment().unix()
    const payloadData = {
      payload: {
        idService: this.parmsData.consultaProductos.idService,
        keyService: this.parmsData.consultaProductos.keyService,
        operation: {
          canalId: this.sessionData.dataProducto.canalId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          logger: this.parmsData.consultaProductos.logger,
          moduleId: this.sessionData.dataProducto.moduloId,
          sessionId: this.sessionData.sesion.clientId,
          type: this.parmsData.consultaProductos.type,
        },
        service: {
          Request: {
            Data: {
              codProducto: this.parmsData.consultaProductos.Data.codProducto,
              codSubProducto:
                this.parmsData.consultaProductos.Data.codSubProducto,
              valCompania: this.parmsData.consultaProductos.Data.codSubProducto,
              valIndicadorConsultarCertificadoCDTS:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarCertificadoCDTS,
              valIndicadorConsultarCreditosFM:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarCreditosFM,
              valIndicadorConsultarCuentasAhorros:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarCuentasAhorros,
              valIndicadorConsultarCuentasCorrientes:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarCuentasCorrientes,
              valIndicadorConsultarDabuenvida:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarDabuenvida,
              valIndicadorConsultarEstablecimientos:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarEstablecimientos,
              valIndicadorConsultarFondosInversion:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarFondosInversion,
              valIndicadorConsultarTarjetasCreditoAmparadas:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarTarjetasCreditoAmparadas,
              valIndicadorConsultarTarjetasCreditoPropias:
                this.parmsData.consultaProductos.Data
                  .valIndicadorConsultarTarjetasCreditoPropias,
              valNumeroIdentificacion:
                this.sessionData.dataProducto.numeroDocumento,
              valNumeroProducto:
                this.parmsData.consultaProductos.Data.valNumeroProducto,
              valTipoIdentificacion:
                this.sessionData.dataProducto.tipoDocumento,
              valVinculacion:
                this.parmsData.consultaProductos.Data.valVinculacion,
            },
            DataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: transaccionID.toString(),
              jornada: this.parmsData.consultaProductos.DataHeader.jornada,
              modoDeOperacion:
                this.parmsData.consultaProductos.DataHeader.modoDeOperacion,
              nombreOperacion: this.parmsData.consultaProductos.idService,
              perfil: this.parmsData.consultaProductos.DataHeader.perfil,
              total: this.parmsData.consultaProductos.DataHeader.total,
              usuario: this.parmsData.consultaProductos.DataHeader.usuario,
              versionServicio:
                this.parmsData.consultaProductos.DataHeader.versionServicio,
            },
          },
        },
        urlServiceOption: this.parmsData.consultaProductos.urlServiceOption,
      },
    }

    try {
      resultConsultaProd = await axios.post(endpointUrl, payloadData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultConsultaProd.data.errors &&
      resultConsultaProd.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultConsultaProd.data.errors))
      )
    }

    const productosRes = resultConsultaProd.data.res.Response
    this.logger.debug(
      `${STEP}:consultaProductos - Response: ${JSON.stringify(productosRes)}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio = productosRes.DataHeader.caracterAceptacion
    if (
      estadoServicio ===
        this.parmsData.consultaProductos.caracterAceptacionSvc &&
      !(
        productosRes.DataHeader.codMsgRespuesta ===
        this.parmsData.consultaProductos.codMsgRespuesta
      )
    ) {
      estatus = true
      const contenedorRegistros: any[] = productosRes.Data.Registros.Registro
      const parmssubProductosValidos: any[] =
        this.parmsData.consultaProductos.subProductosValidos
      this.sessionData.sesion.consultaProducto.registros.splice(0)

      contenedorRegistros.forEach((registro) => {
        const cuentaValida = [registro].find(
          (value: {
            valIndicadorBloqueoProducto: string
            valVigencia: string
            valCodigoSubProducto: string
            valIndicadorEmbargo: string
          }) =>
            ((value.valVigencia ===
              this.parmsData.consultaProductos.vigenteAhorro &&
              value.valIndicadorBloqueoProducto ===
                this.parmsData.consultaProductos.noBloqueoAhorros) ||
              (value.valVigencia ===
                this.parmsData.consultaProductos.vigenteCorriente &&
                value.valIndicadorBloqueoProducto ===
                  this.parmsData.consultaProductos.noBloqueoCorriente)) &&
            parmssubProductosValidos.includes(value.valCodigoSubProducto) &&
            value.valIndicadorEmbargo ===
              this.parmsData.consultaProductos.valIndicadorEmbargo
        )

        if (cuentaValida) {
          this.sessionData.sesion.consultaProducto.registros.push({
            numeroCuenta: registro.valNumeroProducto,
            tipoCuenta:
              registro.valCodigoProducto ===
              this.parmsData.consultaProductos.valCodigoProducto
                ? this.parmsData.consultaProductos.cuentaAhorros // Cuenta de Ahorros
                : this.parmsData.consultaProductos.cuentaCorriente, // Cuenta Corriente
          })
        }
      })

      if (!this.sessionData.sesion.consultaProducto.registros[0]) {
        estatus = false
      }
    }
    return estatus
  }

  private consultaRotativo = async () => {
    this.logger.debug('consultaRotativo', this.sessionData.sesion.clientId)

    let resultConsultaRot: any
    const endpointUrl = `${
      this.config.getVars().back.soapWebService
    }/soap-service`
    const transaccionID = moment().unix()
    const payloadData = {
      payload: {
        idService: this.parmsData.consultaRotativo.idService,
        keyService: this.parmsData.consultaRotativo.keyService,
        operation: {
          canalId: this.sessionData.dataProducto.canalId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.sessionData.sesion.clientId,
          },
          id: this.sessionData.dataProducto.moduloId,
          ip: this.sessionData.sesion.ip,
          logger: this.parmsData.consultaRotativo.logger,
          moduleId: this.sessionData.dataProducto.moduloId,
          sessionId: this.sessionData.sesion.clientId,
          type: this.parmsData.consultaRotativo.type,
        },
        service: {
          Request: {
            Data: {
              codIdioma: this.parmsData.consultaRotativo.Data.codIdioma,
              codPais: this.parmsData.consultaRotativo.Data.codPais,
              idSesion: this.sessionData.sesion.clientId,
              ipOrigen: this.sessionData.sesion.ip,
              numNumeroIdentificacion:
                this.sessionData.dataProducto.numeroDocumento,
              numNumeroSolicitud:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              numTipoIdentificacion:
                this.sessionData.dataProducto.tipoDocumento,
              valOrigen: this.sessionData.sesion.ip,
            },
            DataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: transaccionID.toString(),
              jornada: this.parmsData.consultaRotativo.DataHeader.jornada,
              modoDeOperacion:
                this.parmsData.consultaRotativo.DataHeader.modoDeOperacion,
              nombreOperacion: this.parmsData.consultaRotativo.idService,
              perfil: this.parmsData.consultaRotativo.DataHeader.perfil,
              total: this.parmsData.consultaRotativo.DataHeader.total,
              usuario: this.parmsData.consultaRotativo.DataHeader.usuario,
              versionServicio:
                this.parmsData.consultaRotativo.DataHeader.versionServicio,
            },
          },
        },
        urlServiceOption: this.parmsData.consultaRotativo.urlServiceOption,
      },
    }

    try {
      resultConsultaRot = await axios.post(endpointUrl, payloadData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultConsultaRot.data.errors &&
      resultConsultaRot.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultConsultaRot.data.errors))
      )
    }

    const rotativoRes = resultConsultaRot.data.res.Response
    this.logger.debug(
      `${STEP}:consultaRotativo - Response: ${JSON.stringify(rotativoRes)}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio = rotativoRes.DataHeader.caracterAceptacion
    const cantidadRotativos = rotativoRes.Data?.numCantidadRotativos
    if (
      estadoServicio ===
        this.parmsData.consultaProductos.caracterAceptacionSvc &&
      cantidadRotativos === this.parmsData.consultaRotativo.cantidadRotativos
    ) {
      estatus = true
    }
    return estatus
  }

  private autLivianaEliminarPersistencia = async () => {
    this.logger.debug(
      'autLivianaEliminarPersistencia',
      this.sessionData.sesion.clientId
    )

    let resultEliminarPersistencia: any
    const endpointUrl = `${
      this.config.getVars().back.autLivianaEliminarPersistencia
    }`
    const transaccionID = moment().unix()
    const payloadData = {
      documento: {
        numero: this.sessionData.dataProducto.numeroDocumento,
        tipo: this.sessionData.dataProducto.tipoDocumento,
      },
      idTransaccion: transaccionID.toString(),
      ip: this.sessionData.sesion.ip,
      numeroSolicitud:
        this.sessionData.sesion.consultaPersistencia.nroSolicitud,
      presentacionCliente: {
        consumer: {
          appConsumer: {
            canalId: this.sessionData.dataProducto.canalId,
            id: this.sessionData.dataProducto.moduloId,
            sessionId: this.sessionData.sesion.clientId,
            terminalId: this.sessionData.dataProducto.terminalId,
            transactionId: this.sessionData.dataProducto.transactionId,
          },
          deviceConsumer: {
            id: this.sessionData.dataProducto.deviceConsumerId,
            inactiveInterval: this.sessionData.dataProducto.inactiveInterval,
            locale: this.parmsData.locale,
            sessionTimeout: this.parmsData.sessionTimeout,
            userAgent: this.sessionData.dataProducto.userAgent,
          },
        },
        module: {
          country: this.sessionData.dataProducto.country,
          id: this.sessionData.dataProducto.moduloId,
        },
      },
      sessionIdWf: this.sessionData.sesion.clientId,
      tipoOperacionLog:
        this.parmsData.autLivianaEliminarPersistencia.tipoOperacionLog,
      total: this.sessionData.sesion.total,
    }

    try {
      resultEliminarPersistencia = await axios.post(endpointUrl, payloadData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    if (
      resultEliminarPersistencia.data.errors &&
      resultEliminarPersistencia.data.errors.length > 0
    ) {
      throw new ServiceError(
        MBAAS_ERRORS.internal_server_error,
        new Error(JSON.stringify(resultEliminarPersistencia.data.errors))
      )
    }

    const eliminarPersistenciaRes = resultEliminarPersistencia.data.data
    this.logger.debug(
      `${STEP}:autLivianaEliminarPersistencia - Response: ${JSON.stringify(
        eliminarPersistenciaRes
      )}`,
      this.sessionData.sesion.clientId
    )

    let estatus: boolean = false
    const estadoServicio = eliminarPersistenciaRes.DataHeader.caracterAceptacion
    const cantidadRotativos = eliminarPersistenciaRes.Data?.numCantidadRotativos
    if (
      estadoServicio ===
      this.parmsData.autLivianaEliminarPersistencia.caracterAceptacionSvc
    ) {
      estatus = true
    }
    return estatus
  }
  private consumoEvaluador = async (datosRetoma: any) => {
    // tslint:disable: object-literal-sort-keys
    this.logger.debug(
      'Retoma consumoEvaluador',
      this.sessionData.sesion.clientId
    )

    let consumoEvaluadorRest: any

    const endpointUrl = `${
      this.config.getVars().back.consumoEvaluador
    }/evaluador`
    // tslint:disable: variable-name
    let IngresosEmpleado = 0
    let IngresosIndependiente = 0
    let IngresosPensionado = 0

    if (datosRetoma.datosFormulario.actividadLaboral.codigo === 'E') {
      IngresosEmpleado = datosRetoma.datosFormulario.ingresosMensuales
    }
    if (datosRetoma.datosFormulario.actividadLaboral.codigo === 'I') {
      IngresosIndependiente = datosRetoma.datosFormulario.ingresosMensuales
    }
    if (datosRetoma.datosFormulario.actividadLaboral.codigo === 'P') {
      IngresosPensionado = datosRetoma.datosFormulario.ingresosMensuales
    }

    const payload = {
      payload: {
        service: {
          Request: {
            DataHeader: {
              canal: this.sessionData.dataProducto.canalId,
              idTransaccion: moment().unix(),
              total:
                this.parmsData.consumoEvaluador.service.Request.DataHeader
                  .total,
            },
            DVSolicitud: {
              NumeroSolicitud:
                this.sessionData.sesion.consultaPersistencia.nroSolicitud,
              NumeroSolicitantes:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .NumeroSolicitantes,
              NumeroProductosSolicitados:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .NumeroProductosSolicitados,
              FechaSolicitud: new Date().toISOString().slice(0, 10),
              Agente: datosRetoma.datosFormulario.codigoAsesor
                ? datosRetoma.datosFormulario.codigoAsesor
                : '0',
              Canal:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .Canal,
              FlagCampanaFirme:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagCampanaFirme, // check valor
              EstadoOportunidad:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .EstadoOportunidad,
              GrupoProductoRPRBuro:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .GrupoProductoRPRBuro,
              GrupoSubproductoRPRBuro:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .GrupoSubproductoRPRBuro,
              FlagFraudeVendedor:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagFraudeVendedor, // check valor
              FlagFraudeCentroNegocio:
                this.parmsData.consumoEvaluador.service.Request.DVSolicitud
                  .FlagFraudeCentroNegocio, // check valor
            },
            DVSolicitante: {
              Solicitante: {
                CiudadResidencia:
                  this.sessionData.sesion.consultaClientePN.ciudadDI,
                DeptoResidencia:
                  this.sessionData.sesion.consultaClientePN.departamentoDI,
                EsFuncionarioBanco:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.EsFuncionarioBanco,
                FechaExpCedula:
                  this.sessionData.sesion.consultaClientePN.fechaExpedicionCLI,
                NumeroIdentificacion:
                  this.sessionData.dataProducto.numeroDocumento,
                PrimerApellido:
                  this.sessionData.sesion.consultaClientePN.primerApellido,
                TipoIdentificacion: this.sessionData.dataProducto.tipoDocumento,
                TipoPersona:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.TipoPersona,
                TipoSolicitante:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.TipoSolicitante,
                FlagFraudeCliente:
                  this.parmsData.consumoEvaluador.service.Request.DVSolicitante
                    .Solicitante.FlagFraudeCliente,
                FechaNacimiento:
                  this.sessionData.sesion.consultaClientePN.fechaNacimientoCLI,
                Declarado: {
                  // asignado segun logica
                  IngresosEmpleado,
                  IngresosIndependiente,
                  IngresosPensionado,
                },
                Analitica: {
                  Ingreso:
                    this.sessionData.sesion.consultaClientePN
                      .valIngresoEspecialistaCLI,
                },
                ActividadLaboral: {
                  ActividadLaboral:
                    datosRetoma.datosFormulario.actividadLaboral.codigo,
                  FlagPrincipal:
                    this.parmsData.consumoEvaluador.service.Request
                      .DVSolicitante.Solicitante.ActividadLaboral.FlagPrincipal,
                  TipoContrato: this.sessionData.sesion.consultaClientePN
                    .tipoContratoAL
                    ? this.sessionData.sesion.consultaClientePN.tipoContratoAL
                    : '0', // check
                  FlagFraudeEmpresa:
                    this.parmsData.consumoEvaluador.service.Request
                      .DVSolicitante.Solicitante.FlagFraudeEmpresa,
                },
              },
            },
            DVProductos: {
              Producto: {
                CodIdProducto:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.CodIdProducto,
                Tipo: this.parmsData.consumoEvaluador.service.Request
                  .DVProductos.Producto.Tipo,
                Amortizacion:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Amortizacion,
                Moneda:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Moneda,
                TipoTasa:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.TipoTasa,
                PlazoSolicitado:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.PlazoSolicitado,
                MontoSolicitado:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.MontoSolicitado,

                Catalogo: {
                  PlazoMinimo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.PlazoMinimo,
                  PlazoMaximo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.PlazoMaximo,
                  MontoMinimo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.MontoMinimo,
                  MontoMaximo:
                    this.parmsData.consumoEvaluador.service.Request.DVProductos
                      .Producto.Catalogo.MontoMaximo,
                },
                Familia:
                  this.parmsData.consumoEvaluador.service.Request.DVProductos
                    .Producto.Familia,
                N1: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N1,
                N2: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N2,
                N3: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N3,
                N4: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N4,
                N5: this.parmsData.consumoEvaluador.service.Request.DVProductos
                  .Producto.N5,
              },
            },
          },
        },
        operation: {
          sessionId: this.sessionData.sesion.clientId,
          canalId: this.sessionData.dataProducto.canalId,
          id: this.parmsData.consumoEvaluador.operation.id,
          ip: this.sessionData.sesion.ip,
          moduleId: this.parmsData.consumoEvaluador.operation.moduleId,
          client: {
            documentClient: {
              number: this.sessionData.dataProducto.numeroDocumento,
              type: this.sessionData.dataProducto.tipoDocumento,
            },
            userId: this.parmsData.consumoEvaluador.operation.client.userId,
          },
        },
      },
    }
    this.logger.debug(
      `${STEP}:Consumo Evaluador - request: ${JSON.stringify(payload)}`,
      this.sessionData.sesion.clientId
    )

    try {
      consumoEvaluadorRest = this.parmsData.mockingData.consumoEvaluador
        ? datosRetoma.datosFormulario.ingresosMensuales > 5000000
          ? consumoResponseB
          : consumoResponseM
        : await axios.post(endpointUrl, payload)
      // consumoEvaluadorRest = await axios.post(endpointUrl, payload)
      // consumoEvaluadorRest = reqPayload.ingresosMensuales > 5000000 ? consumoResponseB: consumoResponseM
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }
    /*
    if (
      consumoEvaluadorRest.data.codError || consumoEvaluadorRest.data.messageError.statusCode === 500
    ) {
      {
        throw new ServiceError(
          MBAAS_ERRORS.internal_server_error,
          new Error(JSON.stringify(consumoEvaluadorRest.data.errors))
        )
      }
    } */

    const consumoEvaluadorSalida =
      consumoEvaluadorRest.data.payload.service.Response.DataHeader
        .caracterAceptacion === 'M'
        ? {
            CaracterAceptacion:
              consumoEvaluadorRest.data.payload.service.Response.DataHeader
                .caracterAceptacion,
          }
        : {
            CaracterAceptacion:
              consumoEvaluadorRest.data.payload.service.Response.DataHeader
                .caracterAceptacion,
            DecisionCategory:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.DecisionSolicitud.DecisionCategory,
            ValorAprobado:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.DecisionSolicitud.DecisionCategory === 'APR'
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].Aprobacion
                    .MontoAprobado
                : 0,
            ValorCobroSeguroVida:
              this.parmsData.consumoEvaluador.valorCobroSeguroVida,
            CodigoCausalDecisionSolicitud:
              consumoEvaluadorRest.data.payload.service.Response.WorkingStorage
                .PNOutputPCO.Producto[0].PoliticasProd.SortedReasonCodeTable.I1,
            CausalDecisionSolicitud: {
              causalDecisionSolicitud1:
                consumoEvaluadorRest.data.payload.service.Response
                  .WorkingStorage.PNOutputPCO.DecisionSolicitud
                  .DecisionCategory === 'NEG'
                  ? consumoEvaluadorRest.data.payload.service.Response
                      .WorkingStorage.PNOutputPCO.DecisionSolicitud
                      .SortedReasonCodeTable.I1
                  : '',
              causalDecisionSolicitud2: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I2
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I2
                : '',
              causalDecisionSolicitud3: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I3
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I3
                : '',
              causalDecisionSolicitud4: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I4
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I4
                : '',
              causalDecisionSolicitud5: consumoEvaluadorRest.data.payload
                .service.Response.WorkingStorage.PNOutputPCO.Producto[0]
                .PoliticasProd.SortedReasonCodeTable.I5
                ? consumoEvaluadorRest.data.payload.service.Response
                    .WorkingStorage.PNOutputPCO.Producto[0].PoliticasProd
                    .SortedReasonCodeTable.I5
                : '',
            },
          }

    this.logger.debug(
      `${STEP}:Consumo Evaluador - Response: ${JSON.stringify(
        consumoEvaluadorSalida
      )}`,
      this.sessionData.sesion.clientId
    )

    return {
      codMessageError: '',
      data: consumoEvaluadorSalida,
    }
  }
}
