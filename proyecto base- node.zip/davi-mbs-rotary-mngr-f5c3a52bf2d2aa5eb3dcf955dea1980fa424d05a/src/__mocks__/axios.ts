//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export default {
  delete: jest.fn(() => Promise.resolve({ data: null, status: 200 })),
  get: jest.fn(() => Promise.resolve({ data: null, status: 200 })),
  post: jest.fn(() => Promise.resolve({ data: null, status: 200 })),
  put: jest.fn(() => Promise.resolve({ data: null, status: 200 })),
}
