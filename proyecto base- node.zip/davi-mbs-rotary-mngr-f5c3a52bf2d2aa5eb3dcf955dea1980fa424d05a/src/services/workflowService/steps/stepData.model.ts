//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { PRODUCTO } from '~/models/enums/productoPais.enum'

export enum STATUS_ID {
  FINAL_PROCESO = 0, // NO SE USA EN DAVIPLATA
  NORMAL = 1,
  MENSAJE_CALLBACK = 2,
  MENSAJE = 3,
  RETOMA = 4,
  MENSAJE_POST = 5,
  MENSAJE_CANGURO = 6, // NO SE USA EN DAVIPLATA (ejemplo pop up de seguro)
  MENSAJE_BIOMETRIA = 7, // BIOMETRIA DACTILAR NO SE USA EN DAVIPLATA
  MENSAJE_CLAVE_CREADA = 8, // CLAVE CREADA
}

export enum STATUS_MSG {
  MSG_rotativo_001 = 'catREG_MSG_SESION_EXPIRADA', // Sesion expirada
  MSG_rotativo_002 = 'catREG_MSG_DEF_001', // Error del servidor y error por defecto
  MSG_rotativo_003 = 'catREG_MSG_MAXINTENTOSOTP', // OTP invalido sin posibilidad de intentos
  MSG_rotativo_004 = 'catREG_MSG_REG_NOEXITO', // Respuesta N Q Listas Restrictivas
  MSG_rotativo_005 = 'catREG_MSG_FECHA_EXP_ERRADA', // Respuesta Listas CIFIN
  MSG_rotativo_006 = 'catREG_MSG_NOMBRE_NO_COINCIDE', // Respuesta Listas Nombre no coincide con el del documento
  MSG_rotativo_007 = 'catREG_MSG_CLAVECREADA', // clave creada
  MSG_rotativo_008 = 'catREG_MSG_FECHA_NAC_VACIA', // Fecha nacimiento menor vacia
}

export interface IStepData {
  clientId: string
  module?: PRODUCTO
  stepId: STEP_ID
  payload: any
  status?: STATUS_ID
}
