//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { ESTADO_SESION } from '@models/enums/estadoSesion.enum'
import { KIND } from '@models/enums/kind.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { AuthService } from '@services/auth/authService'
import { CryptoService } from '@services/crypto/cryptoService'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { StepFactory } from '@services/workflowService/stepFactory/stepFactory'
import {
  IStepData,
  STATUS_ID,
} from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { PRODUCTO } from '~/models/enums/productoPais.enum'
import { MockStep } from './stepFactory/__mocks__/mockStep'
import { WorkflowService } from './workflowService'

jest.mock('@services/auth/authService')
jest.mock('@services/crypto/cryptoService')
jest.mock('@services/workflowService/stepFactory/stepFactory')
jest.mock('@services/persistence/persistenceService')

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {},
    }
  }
}

describe('WorkflowService', () => {
  let workflowService: WorkflowService
  let workflowServiceAux: WorkflowService
  const config = new MockConfig()
  const logger = new LoggerStub('info')
  const persistence = new PersistenceService(config, logger)
  const persistenceAux = new PersistenceService(config, logger)
  const auth = new AuthService(config)
  const crypto = new CryptoService(auth, logger)
  const cryptoAux = new CryptoService(auth, logger)
  const steps = new StepFactory(config, logger)
  const encKey =
    '{"kty": "RSA","kid": "1553133006","use": "enc","alg": "RSA-OAEP-256","key_ops": ["encrypt","wrap","verify"],"e": "AQAB","n": "lEkhmX7QqUGzA0efqo6tmdhLN0RwvNGIjZmDOE4DXuZjFGNWHrTlbNhqUXebwuRRHJBxM3JB-C0s2Fd6qvI9oduYs1dQBBUtiDeH6TUvYmdTlLDBytCGDUN4Aup5G6S3CEeSOmboi48CroVmMqAE1FXLQEF35bgFSdyt_87B5bqIfLTvcna8FQ2OT7O_wlQcmt4OtOAVxRtDm1cr92A8VfhXZ_fgb7aKQBhmULt22_dHcjc2bylCj0cjfBeKAf_UDgDHNK324B_kipurcMvY53sMWzKemweIsb1UnRKAKX68b6QXa5xu-VjuS3obo7to4DIBIBpXAtdHQJeYSKXBqw","d": "O80abcrE392NEh-KdsA_prGh89H4HU3rYh-s2cIsfdMv1gMRsiSF-dV1WxF_kaN-SqS94l-L10hws3bkE5jJ3kKvXHQz4tGfoTWz7Ar05xyAipCWNvLNfP_eoF5rJQjSf9ZNVJw34EB2dmd6BaSfDfrjkzBT6CLEjzseOPHrJHftfIBw5LoBlhreo6sgzg_AtD_s9zvMQvyUdAAyFEdpmweRtqwO0VatfETArAj7r7mG0T_PMpx1m4tR1rD_LA0fmt_OlGzNiYKdu3oXpkup1kuGItANetz4-nJq2s0Ok02CMABo4Bt3433oYSrKgIhwmjSidZ1RNUl5gJDI5nY00Q","p": "2egk333r7XFzY6G5g3_5DjjFCDBmPJb0D_GTgcFICPyGOyfHUjf9N63zOg4TEEt50osXk75ZlUa_ya7rXSkgCrE88sv8ii1_zJzxclHMie9bJQcAgDKvqs-9hfMEveUHkFYD_tbPEX0NxGMz3EY8GQNhhAx3hi7AZatK-omOsPU","q": "rjVF36tJyr6GV48jvq3Jd_-4lIqNJc7avwnctkaB6g-ljhPtUg3nogGIDrXnnSrBnwd87Sb7uf3Dcs99NZLhasnkiOoQlHInc9Pw0qjB-cWb3EOme6yu2SRucnYjSX_W87aSKLuBBTyykoFcAWGxICSsGgaP5pi_HmQrVySghB8","dp": "nh76QsLZJF-i37VHLMj8LPm84Ahe57CSQc-Gvi1G3F6B-QMQe_Ts5i5vxLzZ0IU0TTdpUGhcERpZqTwoxl1FRvz9wSGMi6ggiJWKDu6UgbMSbHf8QQqGtmgwmraRxkofhvkjxRSTBZm9F7j0tO6yRWRSqsNxKAlcy2nU6qBOztE","dq": "np-PYhw7csqM1MlXSNZBLmzAizClWRnDAFRgjfAhdxiMLJRkcWSL124BjzN_FBLMfpt42w-2AiLYhn_7iH6Xln8DAs_uDNzso4EGNSrIhT-zrZpDyzTveHS9xKdhdhlbhkplR4WD81rTVqdHOVLUz2nU81WqTdQjoe6fsBd_uQ0","qi": "M5vcrNqbMMdU2Y1VJEnto4PBWjzNlQHiTuVVn4jPLbLdqRV4JzjYxF3ApHbUXzha8nfFk0qwJH5POLPfnzcZJyLwyJJbjXiIwaF1436kir0LeFn-vQNF-bZCmudL68eFE0GyDO2-rlgVSM8hawqi2m9Xz57XMr5XsgfP1U7QTEU"}'
  let mockEncPayload = ''

  const encHelper = async (payload: any) => {
    return await crypto.encryptJwe(encKey, JSON.stringify(payload))
  }

  const mockPresentacion: IPresentacionClientes = {
    client: {
      documentClient: {
        expeditionCity: '16911001',
        expeditionDate: '15/12/2000',
        number: '1234567890',
        type: '01',
      },
      email: 'usuario@correo.com',
      name: 'Helena Maria Lopez Perez',
      phoneNumber: {
        countryId: '57',
        number: '3124451512',
      },
    },
    consumer: {
      appConsumer: {
        canalId: '',
        id: '',
        sessionId: '',
        terminalId: '',
        transactionId: '',
      },
      deviceConsumer: {
        id: '',
        inactiveInterval: '300000',
        locale: '',
        sessionTimeout: '300000',
        userAgent: '',
      },
      genericData: {
        dataItem: [{ key: 'tokenFrontend', value: 'abcd-1234-efgh-5678' }],
      },
    },
    linkrotativo: '',
    montoProducto: '',
    nombreProducto: '',
    product: {
      country: 'CO',
      id: 'rotativo',
    },
  }

  const mockPresentacionVacios: IPresentacionClientes = {
    client: {
      documentClient: {
        expeditionCity: '16911001',
        expeditionDate: '15/12/2000',
        number: '1234567890',
        type: '01',
      },
      email: 'usuario@correo.com',
      name: 'Helena Maria Lopez Perez',
      phoneNumber: {
        countryId: '57',
        number: '3124451512',
      },
    },
    linkrotativo: '',
    montoProducto: '',
    nombreProducto: '',
    product: {
      country: 'CO',
      id: 'rotativo',
    },
  }

  const mockStepPayload = {}
  const mockStepPayloadAux = ''

  workflowService = new WorkflowService(
    logger,
    persistence,
    steps,
    crypto,
    auth
  )
  workflowServiceAux = new WorkflowService(
    logger,
    persistenceAux,
    steps,
    cryptoAux,
    auth
  )

  test('nextStep de paso valido', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const pasoSiguiente: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId
    mockmockWfData.sesion.app.llaveEncriptacion = encKey

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeTruthy()
      expect(nextStep.clientId).toEqual(clientId)
      expect(nextStep.stepId).toEqual(pasoSiguiente.stepId)
      expect(persistence.setData).toHaveBeenCalledTimes(1)
      const newMockWfData = mockmockWfData
      newMockWfData.sesion.workflow.pasoActual = nextStep.stepId
      expect(persistence.setData).toHaveBeenCalledWith(
        KIND.rotativo,
        clientId,
        newMockWfData
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('nextStep de paso válido, ingreso sin clientId', async (done) => {
    mockEncPayload = await encHelper({})

    const pasoActual: IStepData = {
      clientId: '',
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }

    const pasoSiguiente: IStepData = {
      clientId: 'CLIENTID-MOCK',
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }

    // mock de persistencia
    let wfData = {
      sesion: {
        tipo: '',
      },
    }

    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.app.llaveEncriptacion = encKey

    persistence.setData = jest.fn((kind: string, k: string, d: any) => {
      wfData = d
      return Promise.resolve(true)
    })

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeTruthy()
      expect(nextStep.stepId).toEqual(pasoSiguiente.stepId)
      const newMockWfData = mockmockWfData
      newMockWfData.sesion.workflow.pasoActual = nextStep.stepId
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('nextStep de paso valido y wfDataProcess como array', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const pasoSiguiente: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId
    mockmockWfData.sesion.app.llaveEncriptacion = encKey
    const arrayMockMockWfData = [mockmockWfData]

    // mock de respuesta de persistencia con datos de sesion
    persistenceAux.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(arrayMockMockWfData)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowServiceAux.getNextStep(pasoActual)
      expect(nextStep).toBeTruthy()
      expect(nextStep.clientId).toEqual(clientId)
      expect(nextStep.stepId).toEqual(pasoSiguiente.stepId)
      expect(persistenceAux.setData).toHaveBeenCalledTimes(1)
      const newMockWfData = mockmockWfData
      newMockWfData.sesion.workflow.pasoActual = nextStep.stepId
      expect(persistenceAux.setData).toHaveBeenCalledWith(
        KIND.rotativo,
        clientId,
        newMockWfData
      )
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('nextStep con clientId no encontrado en persistencia da error invalid_client_id', async (done) => {
    // Preparo datos mock
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(null)
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_client_id)
      expect(error.statusCode).toEqual(404)
      done()
    }
  })

  test('nextStep con problema en llamada a persistencia da error internal_server_error', async (done) => {
    // Preparo datos mock
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.reject(new Error('upsss'))
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('upsss')
      done()
    }
  })

  test('nextStep con payload invalido da error invalid_data_format', async (done) => {
    // Preparo datos mock
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.isRequestValid = jest.fn(() => false)
    pasoMock.getRequestValidationError = jest.fn(() => 'fake-error-message')

    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.invalid_data_format)
      expect(error.statusCode).toEqual(422)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('fake-error-message')
      done()
    }
  })

  test('nextStep con error interno al obtener proximo paso da error internal_server_error', async (done) => {
    // Preparo datos mock
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() =>
      Promise.reject(new Error('ups-interno'))
    )

    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('ups-interno')
      done()
    }
  })

  test('Sesion expirada por timeout retorna error', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }

    const pasoSiguiente: IStepData = {
      clientId,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }

    const presentacion: IPresentacionClientes = {
      client: {
        documentClient: {
          expeditionCity: '16911001',
          expeditionDate: '15/12/2000',
          number: '1234567890',
          type: '01',
        },
        email: 'usuario@correo.com',
        name: 'Helena Maria Lopez Perez',
        phoneNumber: {
          countryId: '57',
          number: '3124451512',
        },
      },
      consumer: {
        appConsumer: {
          canalId: '4',
          id: '1',
          sessionId: '2',
          terminalId: '5',
          transactionId: '3',
        },
        deviceConsumer: {
          id: 'a',
          inactiveInterval: '600000', // 1000 * 60 * 10  --> 10 minutos en milisegundos
          locale: 'c',
          sessionTimeout: '600000', // 1000 * 60 * 10  --> 10 minutos en milisegundos
          userAgent: 'b',
        },
        genericData: {
          dataItem: [{ key: 'tokenFrontend', value: 'abcd-1234-efgh-5678' }],
        },
      },
      partner: {
        callbackUrl: {
          error: '',
          success: '',
        },
        id: 'P1',
      },
      product: {
        country: 'CO',
        id: 'rotativo',
      },
    }

    // Mock de "ahora"
    jest
      .spyOn(global.Date, 'now')
      .mockImplementationOnce(() =>
        new Date('2019-06-15T11:05:02.003Z').valueOf()
      )

    // mock de workflow data
    const mockWfData = new WorkflowData(presentacion, '', 0)
    mockWfData.sesion.clientId = clientId
    mockWfData.sesion.app.llaveEncriptacion = encKey
    mockWfData.sesion.estado = ESTADO_SESION.EN_PROCESO
    mockWfData.sesion.ultimaAccion = '2019-06-15T11:00:02.003Z' // ultima acción fue hace 5 minutos respecto de "ahora"
    mockWfData.sesion.expiracionSesion = '2019-06-15T11:04:02.003Z' // sesion expiro hace 1 minuto respecto de "ahora"

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de auth service para cerrar sesion
    auth.endSession = jest
      .fn()
      .mockImplementationOnce((c: string) => Promise.resolve(true))

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // mock de respuesta de crypto con encriptacion de datos de payload
    crypto.encryptJwe = jest.fn((encryptKey: string, payload: any) =>
      Promise.resolve(mockStepPayloadAux)
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeTruthy()
      expect(nextStep.clientId).toEqual(clientId)
      expect(nextStep.stepId).toEqual(STEP_ID.rotativo00001)
      expect(nextStep.status).toEqual(STATUS_ID.MENSAJE_CALLBACK)
      expect(mockWfData.sesion.estado).toEqual(ESTADO_SESION.EXPIRADO)
      expect(auth.endSession).toHaveBeenCalledTimes(1)
      expect(auth.endSession).toHaveBeenCalledWith(clientId)
      done()
    } catch (error) {
      expect(error).toBeFalsy()
    }
  })

  test('nextStep con problema en llamada a set de persistencia da error internal_server_error', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const pasoSiguiente: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const mockmockWfData = new WorkflowData(mockPresentacion, '', 0)
    mockmockWfData.sesion.clientId = clientId
    mockmockWfData.sesion.app.llaveEncriptacion = encKey

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // mock de respuesta de persistencia al setear los datos de sesion
    persistence.setData = jest.fn((kind: string, k: string) =>
      Promise.reject(new Error('upsss'))
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('upsss')
      done()
    }
  })

  test('nextStep con problema en llamada a set de persistencia da error internal_server_error', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const clientId = 'mock-id'
    const pasoActual: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }
    const pasoSiguiente: IStepData = {
      clientId,
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const mockmockWfData = new WorkflowData(mockPresentacionVacios, '', 0)
    mockmockWfData.sesion.clientId = clientId
    mockmockWfData.sesion.app.llaveEncriptacion = encKey

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // mock de respuesta de persistencia al setear los datos de sesion
    persistence.setData = jest.fn((kind: string, k: string) =>
      Promise.reject(new Error('upsss'))
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('upsss')
      done()
    }
  })

  test('nextStep con problema en llamada a set de persistencia da error internal_server_error', async (done) => {
    // Preparo datos mock
    mockEncPayload = await encHelper({})
    const pasoActual: IStepData = {
      clientId: '',
      module: PRODUCTO.rotativo,
      payload: mockEncPayload,
      stepId: STEP_ID.rotativo000,
    }

    const pasoSiguiente: IStepData = {
      clientId: 'CLIENTID-MOCK',
      module: PRODUCTO.rotativo,
      payload: {},
      stepId: STEP_ID.rotativo010,
    }
    const mockmockWfData = new WorkflowData(mockPresentacionVacios, '', 0)
    mockmockWfData.sesion.app.llaveEncriptacion = encKey

    // mock de respuesta de persistencia con datos de sesion
    persistence.getData = jest.fn((kind: string, k: string) =>
      Promise.resolve(mockmockWfData)
    )

    // mock de respuesta de crypto con desencriptacion de datos de payload
    crypto.decryptJwe = jest.fn((jweToken: string) =>
      Promise.resolve(mockStepPayload)
    )

    // mock de paso y factory
    const pasoMock = new MockStep(pasoActual, mockmockWfData, config, logger)
    pasoMock.getNextStep = jest.fn(() => Promise.resolve(pasoSiguiente))
    steps.get = jest.fn(
      (stepData: IStepData, sessionData: WorkflowData) => pasoMock
    )

    // mock de respuesta de persistencia al setear los datos de sesion
    persistence.setData = jest.fn((kind: string, k: string) =>
      Promise.reject(new Error('upsss'))
    )

    // probar obtener próximo paso
    try {
      const nextStep = await workflowService.getNextStep(pasoActual)
      expect(nextStep).toBeFalsy()
    } catch (error) {
      expect(error).toBeTruthy()
      expect(error).toBeInstanceOf(ServiceError)
      expect(error.code).toEqual(MBAAS_ERRORS.internal_server_error)
      expect(error.statusCode).toEqual(500)
      expect(error.internalError).toBeTruthy()
      expect(error.internalError.message).toEqual('upsss')
      done()
    }
  })
})
