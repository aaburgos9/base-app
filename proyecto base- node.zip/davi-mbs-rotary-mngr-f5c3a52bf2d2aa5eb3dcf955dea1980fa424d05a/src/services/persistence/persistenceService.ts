//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { ILogger } from '@services/loggerService'
import axios from 'axios'
import { inject } from 'inversify'
import { IPersistenceService } from '.'

@provide(TYPES.IPersistenceService)
export class PersistenceService implements IPersistenceService {
  constructor(
    @inject(TYPES.IConfig) private config: IConfig,
    @inject(TYPES.ILogger) private logger: ILogger
  ) {}

  /**
   * Obtiene el valor de los datos que se han almacenado.
   * @async
   * @param {string} kind
   * @param {string} key
   * @returns {any} rotativo correspondiendo al clientID o null si no encuentra
   * @memberof PersistenceService
   */
  public getData = async (kind: string, key: string) => {
    const endpointUrl = `${this.config.getVars().back.persistenceServiceUrl}/data`
    const queryUrl = `${endpointUrl}/${kind}/${key}`
    let callResponse: any
    try {
      callResponse = await axios.get(queryUrl)
    } catch (err) {
      if (err.response && err.response.status === 404) {
        return null
      }
      this.logger.error(`PersistenceService:getData - kind: ${kind} - key: ${key} - error: ${err}`)
      throw err
    }
    if (callResponse.status === 200) {
      return callResponse.data.data
    }
    if (callResponse.status === 404) {
      return null
    }
    throw new Error(`${callResponse.status} - ${JSON.stringify(callResponse.data)}`)
  }

  /**
   * Guarda el valor de una clave kind:key.
   * @async
   * @param {string} kind
   * @param {string} key
   * @param {any} data
   * @returns {boolean} true si almaceno correctamente
   * @memberof PersistenceService
   */
  public setData = async (kind: string, key: string, data: any) => {
    const endpointUrl = `${this.config.getVars().back.persistenceServiceUrl}/data`
    const queryUrl = `${endpointUrl}/${kind}/${key}`
    const body = {
      data,
      key,
      kind,
    }
    let callResponse: any
    try {
      callResponse = await axios.put(queryUrl, body)
    } catch (err) {
      this.logger.error(`PersistenceService:setData - kind: ${kind} - key: ${key} - error: ${err}`)
      throw err
    }
    if (callResponse.status !== 200) {
      this.logger.error(`PersistenceService:setData - kind: ${kind} - key: ${key} - status: ${callResponse.status} - data: ${callResponse.data}`)
      throw new Error(`${callResponse.status} - ${JSON.stringify(callResponse.data)}`)
    }
    return true
  }
}
