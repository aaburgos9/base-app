//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import joi from 'joi'

export interface INuevaSesion {
  clientId: string
  linkrotativo: string
  appUrl: string
}

export interface IPresentacionRequest {
  data: string
}

// Esquema de validación para requests de Presentacion de Clientes
export const presentacionRequestSchema = joi
  .object()
  .keys({
    client: joi
      .object()
      .keys({
        documentClient: joi
          .object()
          .keys({
            number: joi.string().allow('').optional(),
            type: joi.string().allow('').optional(),
          })
          .optional(),
        phoneNumber: joi
          .object()
          .keys({
            countryId: joi.string().allow('').optional(),
            number: joi.string().allow('').optional(),
          })
          .optional(),
      })
      .optional(),
    consumer: joi
      .object()
      .keys({
        appConsumer: joi
          .object()
          .keys({
            appVersion: joi.string().allow('').optional(),
            canalId: joi.string().allow('').optional(),
            id: joi.string().allow('').optional(),
            sessionId: joi.string().allow('').optional(),
            soVersion: joi.string().allow('').optional(),
            terminalId: joi.string().allow('').optional(),
            transactionId: joi.string().allow('').optional(),
          })
          .optional(),
        deviceConsumer: joi
          .object()
          .keys({
            id: joi.string().allow('').optional(),
            inactiveInterval: joi.string().allow('').optional(),
            locale: joi.string().allow('').optional(),
            phoneNumber: joi.string().allow('').optional(),
            resolution: joi.string().allow('').optional(),
            sessionTimeout: joi.string().allow('').optional(),
            userAgent: joi.string().allow('').optional(),
            viewPort: joi.string().allow('').optional(),
          })
          .optional(),
        genericData: joi
          .object()
          .keys({
            dataItem: joi.array().items(
              joi
                .object()
                .keys({
                  key: joi.string().allow('').optional(),
                  value: joi.string().allow('').optional(),
                })
                .optional()
            ),
          })
          .optional(),
      })
      .optional(),
    linkrotativo: joi.string().allow('').optional(),
    montoProducto: joi.string().allow('').optional(),
    nombreProducto: joi.string().allow('').optional(),
    partner: joi
      .object()
      .keys({
        callbackUrl: joi
          .object()
          .keys({
            denial: joi.string().allow('').optional(),
            error: joi.string().allow('').optional(),
            success: joi.string().allow('').optional(),
          })
          .optional(),
        id: joi.string().allow('').optional(),
      })
      .optional(),
    product: joi
      .object()
      .keys({
        country: joi.string().allow('').optional(),
        id: joi.string().allow('').optional(),
      })
      .optional(),
  })
  .optional()
