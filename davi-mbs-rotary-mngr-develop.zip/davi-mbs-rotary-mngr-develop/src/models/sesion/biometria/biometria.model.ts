//
// Copyright (C) 2022 - Banco Davivienda S.A. y sus filiales.
//

import { RetoOtpData } from './otp/otp.model'

export class BiometriaData {
  /*
   * Atributos
   */
  public contingencia: boolean = false
  public estatus: boolean = false
  public retoOtp: RetoOtpData
  public idAutenticacion: string = ''
  public idTransaccion: string = ''
  public tipoReto: string = ''
  public fecha: string = ''
  public hora: string = ''
  public semilla: string = ''
  public tipoUsuario: string = ''
  public esRiesgoBajo: boolean = false

  /*
   * Metodo constructor (inicialización) de la clase BiometriaData
   */
  constructor(
    contingencia: boolean,
    estatus: boolean,
    idAutenticacion: string,
    idTransaccion: string,
    tipoReto: string,
    fecha: string,
    hora: string,
    semilla: string,
    tipoUsuario: string,
    esRiesgoBajo: boolean
  ) {
    this.contingencia = contingencia
    this.estatus = estatus
    this.idAutenticacion = idAutenticacion
    this.idTransaccion = idTransaccion
    this.tipoReto = tipoReto
    this.fecha = fecha
    this.hora = hora
    this.semilla = semilla
    this.retoOtp = new RetoOtpData('', '', '', '', false, '')
    this.tipoUsuario = tipoUsuario
    this.esRiesgoBajo = esRiesgoBajo
  }
}
