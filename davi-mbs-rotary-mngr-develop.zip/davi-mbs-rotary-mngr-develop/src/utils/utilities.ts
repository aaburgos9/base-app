import moment from 'moment'
import { IGenericDataItem } from '~/models/sesion/presentacionClientes.model'
import { WorkflowData } from '~/models/workflowData.model'

const horaHHMMSS = () => {
  const fecha = new Date()
  const h = fecha.getHours().toString()
  let m = fecha.getMinutes().toString()
  let s = fecha.getSeconds().toString()
  if (s.length === 1) {
    s = `0${s}`
  }
  if (m.length === 1) {
    m = `0${m}`
  }
  return h + m + s
}

const fechaYYYYMMDD = () => {
  const fecha = new Date()
  const y = fecha.getFullYear().toString()
  const m = validarTiempo((fecha.getMonth() + 1).toString())
  const d = validarTiempo(fecha.getDate().toString())
  return `${y}${m}${d}`
}

const horaDatehmma = (fechaActual: Date) => {
  try {
    const momentLocale = moment(fechaActual)
    momentLocale.locale('es-mx')

    const time = momentLocale.format('h:mm a')
    return time
  } catch (err) {
    return ''
  }
}
const fechaDDDMMYYYY = () => {
  const fecha = new Date()
  const y = fecha.getFullYear().toString()
  let m = (fecha.getMonth() + 1).toString()
  let d = fecha.getDate().toString()
  if (d.length === 1) {
    d = `0${d}`
  }
  if (m.length === 1) {
    m = `0${m}`
  }
  return `${d}/${m}/${y}`
}

const fechaYYYYMMDDTHHMMSS = () => {
  const fecha = new Date()
  const y = fecha.getFullYear().toString()
  const m = validarTiempo((fecha.getMonth() + 1).toString())
  const d = validarTiempo(fecha.getDate().toString())
  const h = validarTiempo(fecha.getHours().toString())
  const min = validarTiempo(fecha.getMinutes().toString())
  const seg = validarTiempo(fecha.getSeconds().toString())
  return `${y}-${m}-${d} ${h}:${min}:${seg}`
}

const fechaYYYYMMDDSeparadores = (separador: string) => {
  const fecha = new Date()
  const y = fecha.getFullYear().toString()
  const m = validarTiempo((fecha.getMonth() + 1).toString())
  const d = validarTiempo(fecha.getDate().toString())
  return `${y}${separador}${m}${separador}${d}`
}

const horaHHMMSSSeparador = () => {
  const fecha = new Date()
  const h = fecha.getHours().toString()
  let m = fecha.getMinutes().toString()
  let s = fecha.getSeconds().toString()
  if (s.length === 1) {
    s = `0${s}`
  }
  if (m.length === 1) {
    m = `0${m}`
  }
  return `${h}:${m}:${s}`
}

const validarTiempo = (tiempo: string) => {
  let respuesta = tiempo
  if (respuesta.length === 1) {
    respuesta = `0${respuesta}`
  }
  return respuesta
}

const buscarIngresosPN = (ingresos: any[], primerRegistro: boolean) => {
  let ingresoSel
  for (const ingreso of ingresos) {
    if (ingreso.principalIN === 'Y') {
      ingresoSel = ingreso
      break
    }
  }

  if (!ingresoSel && primerRegistro) {
    ingresoSel = ingresos[0]
  }
  return ingresoSel
}

const buscarDireccion = (direcciones: any[]) => {
  let direccionSel
  for (const direccion of direcciones) {
    if (direccion.direccionPrincipalDI === 'Y') {
      direccionSel = direccion
      break
    }
  }
  return direccionSel
}

const buscarEmailPn = (emails: any[]) => {
  let emailSel
  for (const email of emails) {
    if (email.correoPrincipalEM === 'Y') {
      emailSel = email
      break
    }
  }
  return emailSel
}

const buscarCelularPn = (celulares: any[]) => {
  let celularesSel
  for (const celular of celulares) {
    if (celular.celularPrincipalCL === 'Y') {
      celularesSel = celular
      break
    }
  }
  return celularesSel
}

const obtenerEdad = (fecha: any) => {
  let edad
  try {
    if (fecha) {
      const y = fecha.substring(0, 4)
      const yActual = new Date().getFullYear().toString()
      const m = new Date().getMonth() - fecha.substring(5, 7)
      edad = Number(yActual) - Number(y)
      if (m < 0 || (m === 0 && new Date().getDate() < fecha.substring(8, 10))) {
        // tslint:disable-next-line: no-increment-decrement
        edad--
      }
    }
  } catch (err) {
    return edad
  }
  return edad
}

export const UTILITIES = {
  buscarCelularPn,
  buscarDireccion,
  buscarEmailPn,
  buscarIngresosPN,
  fechaDDDMMYYYY,
  fechaYYYYMMDD,
  fechaYYYYMMDDSeparadores,
  fechaYYYYMMDDTHHMMSS,
  horaDatehmma,
  horaHHMMSS,
  horaHHMMSSSeparador,
  obtenerEdad,
  validarTiempo,
}
