//
// Copyright (C) 2023 - Banco Davivienda S.A. y sus filiales.
//

export class ProductoData {
  /*
   * Atributos
   */
  public numeroDocumento: string = ''
  public tipoDocumento: string = ''
  public urlProducto: string = ''
  public tokenFrontend: string = ''
  public total: number = 0
  public codigoSubProducto: string = ''
  public numeroCuenta: string = ''
  public sesionIdCanal: string = ''
  public primerNombre: string = ''
  public primerApellido: string = ''
  public segundoApellido: string = ''
  public segundoNombre: string = ''
  public numeroCelular: string = ''
  public indicativoCelular: string = ''
  public nombreCompleto: string = ''
  public email: string = ''
  public tipoUsuario: string = ''
  public canalId: string = ''
  public appConsumerId: string = ''
  public deviceConsumerId: string = ''
  public terminalId: string = ''
  public transactionId: string = ''
  public userAgent: string = ''
  public moduloId: string = ''
  public country: string = ''
  public inactiveInterval: string = ''
  public locale: string = ''
  public sessionTimeout: string = ''
  public codIdioma: string = ''
  public userId: string = ''

  /*
   * Metodo constructor (inicialización) de la clase ProductoData
   */
  constructor(
    numeroDocumento: string,
    tipoDocumento: string,
    urlProducto: string,
    tokenFrontend: string,
    total: number,
    codigoSubProducto: string,
    numeroCuenta: string,
    sesionIdCanal: string,
    primerNombre: string,
    primerApellido: string,
    segundoApellido: string,
    segundoNombre: string,
    numeroCelular: string,
    indicativoCelular: string,
    nombreCompleto: string,
    email: string,
    tipoUsuario: string,
    canalId: string,
    appConsumerId: string,
    deviceConsumerId: string,
    terminalId: string,
    transactionId: string,
    userAgent: string,
    moduloId: string,
    country: string,
    inactiveInterval: string,
    locale: string,
    sessionTimeout: string,
    codIdioma: string,
    userId: string
  ) {
    this.numeroDocumento = numeroDocumento
    this.tipoDocumento = tipoDocumento
    this.urlProducto = urlProducto
    this.tokenFrontend = tokenFrontend
    this.total = total
    this.codigoSubProducto = codigoSubProducto
    this.numeroCuenta = numeroCuenta
    this.sesionIdCanal = sesionIdCanal
    this.primerNombre = primerNombre
    this.primerApellido = primerApellido
    this.segundoApellido = segundoApellido
    this.segundoNombre = segundoNombre
    this.numeroCelular = numeroCelular
    this.indicativoCelular = indicativoCelular
    this.nombreCompleto = nombreCompleto
    this.email = email
    this.tipoUsuario = tipoUsuario
    this.canalId = canalId
    this.appConsumerId = appConsumerId
    this.deviceConsumerId = deviceConsumerId
    this.terminalId = terminalId
    this.transactionId = transactionId
    this.userAgent = userAgent
    this.moduloId = moduloId
    this.country = country
    this.inactiveInterval = inactiveInterval
    this.locale = locale
    this.sessionTimeout = sessionTimeout
    this.codIdioma = codIdioma
    this.userId = userId
  }
}
