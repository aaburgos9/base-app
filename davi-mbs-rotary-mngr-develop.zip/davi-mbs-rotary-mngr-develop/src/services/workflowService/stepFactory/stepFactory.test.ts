//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { IPresentacionClientes } from '@models/sesion/presentacionClientes.model'
import { WorkflowData } from '@models/workflowData.model'
import { LoggerStub } from '@services/loggerService/loggerStub'
import { PersistenceService } from '@services/persistence/persistenceService'
import { IStepData } from '@services/workflowService/steps/stepData.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { BYC0000 } from '~/services/workflowService/steps/Rotatitvo/BYC0000/BYC0000'
import { BYC0010 } from '~/services/workflowService/steps/Rotatitvo/BYC0010/BYC0010'
import { INFO0010 } from '~/services/workflowService/steps/Rotatitvo/INFO0010/INFO0010'

// Importar implementaciones de pasos
import { IStepFactory } from '.'
import { StepFactory } from './stepFactory'

jest.mock('@services/persistence/persistenceService')

// Mock de config y datos de sesion
class MockConfig implements IConfig {
  public getVars = () => {
    return {
      back: {},
    }
  }
}

const mockPresentacion: IPresentacionClientes = {
  client: {
    documentClient: {
      number: '1234567890',
      type: '01',
    },
    email: 'usuario@correo.com',
    name: 'Helena Maria Lopez Perez',
  },
  consumer: {
    appConsumer: {
      canalId: '48',
      id: 'BUNDLE-1',
      sessionId: '12345678-abcd-1234-abcd-1234567890ab',
      transactionId: 't123456',
    },
    deviceConsumer: {
      id: 'device-11111122222',
      userAgent:
        'Mozilla/5.0 (iPhone; CPU iPhone OS 8_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko)',
    },
    genericData: {
      dataItem: [
        {
          key: 'tokenFrontend',
          value: 'xxxxxxxxxxxx',
        },
      ],
    },
  },
  module: {
    country: 'CO',
    id: 'rotativo',
  },
  partner: {
    callbackUrl: {
      error: '',
      success: '',
    },
    id: '',
  },
}

const mockWfData = new WorkflowData(mockPresentacion)
const config = new MockConfig()
const logger = new LoggerStub('info')
const persistence = new PersistenceService(config, logger)

describe('StepFactory', () => {
  let steps: IStepFactory

  test('Factory instancia correctamente', () => {
    steps = new StepFactory(config, logger, persistence)
    expect(steps).toBeDefined()
  })

  test('BYC0010 instancia correctamente', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.BYC0010,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(BYC0010)
  })

  test('Paso desconocido instancia BYC0000', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.PENDIENTE,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(BYC0000)
  })

  test('INFO0010 instancia correctamente', () => {
    const stepData: IStepData = {
      clientId: 'abc123',
      payload: {},
      stepId: STEP_ID.INFO0010,
    }
    const step = steps.get(stepData, mockWfData)
    expect(step).toBeInstanceOf(INFO0010)
  })
})
