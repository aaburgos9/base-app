//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import joi from 'joi'
import { IConfig } from '.'

export class ConfigService implements IConfig {
  private vars: any

  constructor() {
    this.vars = undefined
  }

  /**
   * Retorna las variables de ambientes cargadas
   * @returns {any} Objeto con variables de ambiente
   */
  public getVars = () => {
    return this.vars
  }

  /**
   * Lee las variables de ambientes, valida su contenido y las carga en servicio de configuracion.
   *
   * @returns {string} Error - En caso de ocurrir errores de validación, devuelve un mensaje de error, caso contrario retorna null.
   */
  public load = () => {
    const envVarsSchema = joi
      .object({
        POD_NAME: joi.string().optional(),

        NODE_ENV: joi
          .string()
          .valid('development', 'testing', 'production')
          .required(),

        // HTTP Server
        PORT: joi.number().default(8080),
        ROOT_PATH: joi.string().required(),

        // Logger
        LOGGER_LEVEL: joi
          .string()
          .valid(['error', 'warn', 'info', 'verbose', 'debug', 'silly'])
          .default('info'),

        // Backend services
        AUTENTICACION_LIVIANA_ELIMINAR_PERSISTENCIA: joi.string().required(),
        AUTENTICACION_LIVIANA_ROOT_PATH: joi.string().required(),
        AUTH_SERVICE_URL: joi.string().required(),
        CONSUMO_EVALUADOR: joi.string().required(),
        CREDITO2_NEGOCIO_SERVICE: joi.string().required(),
        GESTIONDOCUMENTOS_SERVICE: joi.string().required(),
        LOGGER_DEVA_SERVICE: joi.string().required(),
        PARMS_SERVICE_URL: joi.string().required(),
        PERSISTENCE_SERVICE_URL: joi.string().required(),
        PREVALIDACION_SERVICE_URL: joi.string().required(),
        SOAP_WEB_SERVICE: joi.string().required(),
        SRVSCN_GENERACION_REPORTE: joi.string().required(),
        VALIDACION_PREVIA_SERVICE_URL: joi.string().required(),
        WORKFLOW_PROCESO_BIOMETRIA_INTERNA_URL: joi.string().required(),

        // Front info
        ROTATIVO_FRONT_URL: joi.string().required(),
      })
      .unknown()
      .required()

    const { error, value: envVars } = joi.validate(process.env, envVarsSchema)
    if (error) {
      this.vars = undefined
      return `Config validation error: ${error.message}`
    }
    this.vars = {
      env: envVars.NODE_ENV,
      isDev: envVars.NODE_ENV === 'development',
      isProd: envVars.NODE_ENV === 'production',
      isTest: envVars.NODE_ENV === 'testing',
      podName: envVars.POD_NAME || '',

      server: {
        port: Number(envVars.PORT),
        rootPath: envVars.ROOT_PATH,
      },

      logger: {
        level: envVars.LOGGER_LEVEL,
      },

      back: {
        autLivianaEliminarPersistencia:
          envVars.AUTENTICACION_LIVIANA_ELIMINAR_PERSISTENCIA,
        autLivianaRootPath: envVars.AUTENTICACION_LIVIANA_ROOT_PATH,
        authServiceUrl: envVars.AUTH_SERVICE_URL,
        consumoEvaluador: envVars.CONSUMO_EVALUADOR,
        crearActualizarCliente: envVars.CREAR_ACTUALIZAR_CLIENTE,
        credito2NegocioService: envVars.CREDITO2_NEGOCIO_SERVICE,
        gestionDocumentosService: envVars.GESTIONDOCUMENTOS_SERVICE,
        loggerDevaService: envVars.LOGGER_DEVA_SERVICE,
        parmsServiceUrl: envVars.PARMS_SERVICE_URL,
        persistenceServiceUrl: envVars.PERSISTENCE_SERVICE_URL,
        prevalidacionServiceUrl: envVars.PREVALIDACION_SERVICE_URL,
        procesoBiometriaInternaWorkflowServiceUrl:
          envVars.WORKFLOW_PROCESO_BIOMETRIA_INTERNA_URL,
        soapWebService: envVars.SOAP_WEB_SERVICE,
        srvScnGenercionReporte: envVars.SRVSCN_GENERACION_REPORTE,
        validacionPreviaServiceUrl: envVars.VALIDACION_PREVIA_SERVICE_URL,
      },
      front: {
        url: envVars.ROTATIVO_FRONT_URL,
      },
    }
    return null
  }
}
