//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import 'reflect-metadata'

import { IConfig } from '@config/vars'
import { Log4jsLogger } from '@services/loggerService/loggerLog4js'

class MockConfig implements IConfig {
  public getVars = () => {
    return {
      logger: {
        // ALL para ver los logs, OFF para ocultarlos
        level: 'OFF',
      },
    }
  }
}

describe('LoggerLog4js', () => {
  const config = new MockConfig()
  const logger = new Log4jsLogger(config)

  test('Trace es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'trace')

    logger.trace('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Debug es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'debug')

    logger.debug('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Info es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'info')

    logger.info('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Warn es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'warn')

    logger.warn('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Error es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'error')

    logger.error('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Fatal es invocado correctamente', () => {
    const spy = jest.spyOn(logger.defaultLogger, 'fatal')

    logger.fatal('Logger test')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Info en logstream loguea correctamente', () => {
    const spy = jest.spyOn(logger.expressLogger, 'info')

    logger.logStream(':method :url HTTP/:http-version | 200 | :response-time ms | :res[content-length] | :remote-addr | :remote-user')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })

  test('Error en logstream loguea correctamente', () => {
    const spy = jest.spyOn(logger.expressLogger, 'error')

    logger.getExpressLogger()
    logger.logStream(':method :url HTTP/:http-version | 500 | :response-time ms | :res[content-length] | :remote-addr | :remote-user')

    expect(spy).toHaveBeenCalled()
    spy.mockReset()
    spy.mockRestore()
  })
})
