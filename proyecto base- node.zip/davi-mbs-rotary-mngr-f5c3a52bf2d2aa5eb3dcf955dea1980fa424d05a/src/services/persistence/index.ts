//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface IPersistenceService {
  getData(kind: string, key: string): Promise<any>
  setData(kind: string, key: string, data: any): Promise<boolean>
}
