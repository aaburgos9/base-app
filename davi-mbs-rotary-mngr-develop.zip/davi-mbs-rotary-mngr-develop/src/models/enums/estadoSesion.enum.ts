//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export enum ESTADO_SESION {
  NUEVO = 0,
  EN_PROCESO = 1,
  FINALIZADO = 2,
  EXPIRADO = 3,
}
