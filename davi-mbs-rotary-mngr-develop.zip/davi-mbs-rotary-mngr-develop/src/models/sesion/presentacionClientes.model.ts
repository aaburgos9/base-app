//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

export interface IPresentacionClientes {
  client?: {
    authenticationType?: string
    name?: string
    email?: string
    userId?: string
    documentClient?: {
      type?: string
      number?: string
    }
  }
  consumer?: {
    appConsumer?: {
      id?: string
      sessionId?: string
      transactionId?: string
      canalId?: string
      platformType?: string
    }
    deviceConsumer?: {
      id?: string
      userAgent?: string
      inactiveInterval?: string
    }
    genericData?: {
      dataItem?: IGenericDataItem[]
    }
  }
  module?: {
    id?: string
    country?: string
    language?: string
  }
  partner?: {
    id?: string
    callbackUrl?: {
      denial?: string
      error?: string
      success?: string
    }
  }
}

export interface IGenericDataItem {
  key?: string
  value?: string
}
