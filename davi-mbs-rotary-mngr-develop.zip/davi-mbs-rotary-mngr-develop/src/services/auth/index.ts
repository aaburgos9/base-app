//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { JWK } from 'node-jose'

export interface IAuthService {
  createOtp(clientId: string, product: string): Promise<string>
  getKey(kid: string, use: string): Promise<JWK.Key>
  endSession(clientId: string): Promise<boolean>
  getCertificate(certificateId: string): Promise<string>
}
