//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { provide } from '@config/ioc/inversify.config'
import { TYPES } from '@config/ioc/types'
import { IConfig } from '@config/vars'
import { KIND } from '@models/enums/kind.enum'
import { MBAAS_ERRORS, ServiceError } from '@models/serviceError.model'
import { TipoSesion } from '@models/sesion/sesion.model'
import { WorkflowData } from '@models/workflowData.model'
import { IAuthService } from '@services/auth'
import { ICryptoService } from '@services/crypto'
import { ILogger } from '@services/loggerService'
import { IPersistenceService } from '@services/persistence/'
import {
  INuevaSesion,
  IPresentacionRequest,
  presentacionRequestSchema,
} from '@services/presentacion/presentacion.model'
import { STEP_ID } from '@services/workflowService/steps/stepId.enum'
import { inject } from 'inversify'
import joi from 'joi'
import uuid = require('uuid')
import { IPresentacionService } from '.'

@provide(TYPES.IPresentacionService)
export class PresentacionService implements IPresentacionService {
  constructor(
    @inject(TYPES.IConfig) private config: IConfig,
    @inject(TYPES.ILogger) private logger: ILogger,
    @inject(TYPES.IPersistenceService) private persistence: IPersistenceService,
    @inject(TYPES.IAuthService) private auth: IAuthService,
    @inject(TYPES.ICrypto) private crypto: ICryptoService
  ) {}

  public crear = async (presentacionEncriptada: IPresentacionRequest) => {
    this.logger.debug(
      `Presentacion: rotativo > Inicio - presentacion data: ${presentacionEncriptada.data}`
    )

    // Desencriptar parametro y extraer datos de presentacion de cliente
    let presentacion
    try {
      presentacion = await this.crypto.decryptJwe(presentacionEncriptada.data)
    } catch (error) {
      this.logger.debug(error)
      throw new ServiceError(MBAAS_ERRORS.invalid_data_format, error)
    }

    // Validar formato de payload desencriptado
    const validationResult = joi.validate(
      presentacion,
      presentacionRequestSchema
    )

    if (validationResult.error) {
      throw new ServiceError(
        MBAAS_ERRORS.invalid_data_format,
        new Error(validationResult.error.message)
      )
    }

    // Crear datos de sesión
    const wfData = new WorkflowData(presentacion, '', 0)
    wfData.sesion.workflow.pasoActual = STEP_ID.rotativo000
    wfData.sesion.tipo = TipoSesion.PRODUCTO

    this.logger.debug(
      `Presentacion: rotativo > Inicio - clientId generado: ${wfData.sesion.clientId}`
    )
    this.logger.debug(`Presentacion: rotativo > wfData: ${JSON.stringify(wfData)}`)

    // Persistir datos de la solicitud
    try {
      await this.persistence.setData(KIND.rotativo, wfData.sesion.clientId, wfData)
    } catch (error) {
      throw new ServiceError(MBAAS_ERRORS.internal_server_error, error)
    }

    // Validación de existencia de link de rotativo desde la presentación o generación random
    let linkrotativoGenerado: string = ''
    if (
      wfData.sesion.presentacion.linkrotativo &&
      wfData.sesion.presentacion.linkrotativo !== ''
    ) {
      linkrotativoGenerado = wfData.sesion.presentacion.linkrotativo
    } else {
      linkrotativoGenerado = uuid.v1()
    }

    // Determinar URL del producto a lanzar
    const appUrlAux: string = `${
      this.config.getVars().front.url
    }?paymentlink=${linkrotativoGenerado}&idSesion=${wfData.sesion.clientId}`

    const respuesta: INuevaSesion = {
      appUrl: appUrlAux,
      clientId: wfData.sesion.clientId,
      linkrotativo: linkrotativoGenerado,
    }

    return respuesta
  }
}
