//
// Copyright (C) 2023 - Banco Daviplata S.A. y sus filiales.
//

import { IStepFactory } from '..'
import { IConfig } from '../../../../config/vars'
import { WorkflowData } from '../../../../models/workflowData.model'
import { ILogger } from '../../../loggerService'
import { IStepData } from '../../steps/stepData.model'
import { STEP_ID } from '../../steps/stepId.enum'
import { MockStep } from './mockStep'

const mockStep: IStepData = {
  clientId: 'abc123',
  payload: {},
  stepId: STEP_ID.rotativo000,
}

export class StepFactory implements IStepFactory {
  public get = jest.fn((stepData: IStepData, sessionData: WorkflowData) =>
    new MockStep(mockStep, sessionData, this.config, this.logger)
  )

  constructor(private config: IConfig, private logger: ILogger) {}
}
